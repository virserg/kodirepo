# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from resources.libs import plugin

if __name__ == '__main__':
    plugin.run()
