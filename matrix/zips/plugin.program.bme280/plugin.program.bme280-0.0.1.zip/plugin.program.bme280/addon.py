"""
    Plugin for Launching programs
"""

# -*- coding: UTF-8 -*-
# main imports
import sys
import os
import xbmc
import xbmcgui
import xbmcaddon

# plugin constants
__plugin__ = "BME280"
__author__ = "virserg"
__url__ = "http://"
__git_url__ = "https://github.com/"
__credits__ = "virserg"
__version__ = "0.0.1"

dialog = xbmcgui.Dialog()
addon = xbmcaddon.Addon(id='plugin.program.bme280')

output=os.popen("sudo python /home/osmc/.kodi/addons/plugin.program.bme280/weather.py").read()
dialog.ok("Starting BME280",output)
print(output)

