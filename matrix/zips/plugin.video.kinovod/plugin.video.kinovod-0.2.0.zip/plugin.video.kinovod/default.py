# -*- coding: utf-8 -*-

import os, sys
PY2 = sys.version_info.major == 2
sys.path.append(os.path.join(os.path.dirname(__file__)))
sys.path.append(os.path.join(os.path.dirname(__file__), 'xbmcup'))
import xbmc, xbmcplugin, xbmcgui

from xbmcup.app import Link, Handler, Plugin, _setting
import kinovod
from history import History, HistoryAdd

if not PY2:
	unicode = str
	basestring = str

_view_ = _setting['view']


class Menu(Handler):
	def handle(self):
		d = kinovod.startpage()
		self.item(Link('catalog',{'search': True}), title='[Поиск]')
		self.item(Link('history'), title='[История поиска]')
		self.item(Link('genre',{'data': d['category']}), title='Раздел')
		self.item(Link('genre',{'data': d['genres']}), title='Жанр')
		self.item(Link('genre',{'data': d['country']}), title='Страна')
		self.item(Link('genre',{'data': d['years']}), title='Год')
		for i in range(len(d['gpt'])):
			title = u'[COLOR green]' + d['gpt'][i][0] + u':[/COLOR]'
			self.item(Link('catalog', {'url': d['gpt'][i][1]}), title=title)
			for j in d['data'][i]:
				popup =  []
				popup.extend(self.popup)
				title = j['info']['title']
				popup.insert(1, (Link('catalog', {'search': True, 'textsearch': title}, True), 'Поиск') )
				if j['info'].get('plotoutline'):
					title = title + u' (' + j['yq'] + u', ' + j['info']['plotoutline'] + u')'
				elif j.get('yq'):
					title = title + u' (' + j['yq'] + u')'
				if j['info'].get('rating'):
					title = title + u' [' + str(j['info']['rating']) + u']'
				self.item(Link('video', {'url': j['url']}), title=title, media='video', info=j['info'], thumb=j['thumb'], popup=popup, popup_replace=True)
		self.render(nextmode=_view_)


class Catalog(Handler):
	def handle(self):
		search = self.argv.get('search', self.argv.get('keyword'))
		url = self.argv.get('url')
		s_kbd = self.argv.get('s_kbd', False)
		sort = self.argv.get('sort')
		if sort:
			index = xbmcgui.Dialog().select('Киновод', [x[0] for x in sort])
			if index < 0:
				return True
			else:
				url = sort[index][1]
		if search:
			if isinstance(search, bool):
				textsearch = self.argv.get('textsearch', '')
				search = self.kbdinput('Поиск', textsearch)
				if search is None: return True
				s_kbd = True
				HistoryAdd(search)
			s1, data = kinovod.search(search)
		elif url == 0:
			return True
		else:
			data = kinovod.catalog(url)
		if (data['data']==[]) and s_kbd and (data['podbor'] ==[]):
			xbmcgui.Dialog().ok('Киновод', 'Ничего не найдено')
		if data.get('filter'):
			for i in data['filter']:
				self.item(Link('catalog', {'sort': i['sort']}), title=i['name'], media='video', popup=self.popup, popup_replace=True)
		for i in data['data']:
			popup = []
			popup.extend(self.popup)
			title = i['info']['title']
			popup.insert(1, (Link('catalog', {'search': True, 'textsearch': title}, True), 'Поиск') )
			if i['info'].get('plotoutline'):
				title = title + u' (' + i['yq'] + u', ' + i['info']['plotoutline'] + u')'
			elif i.get('yq'):
				title = title + u' (' + i['yq'] + u')'
			if i['info'].get('rating'):
				title = title + u' [' + str(i['info']['rating']) + u']'
			self.item(Link('video', {'url': i['url']}), title=title, media='video', info=i['info'], thumb=i['thumb'], popup=popup, popup_replace=True)
		for i in data['podbor']:
			self.item(Link('catalog', {'url': i['url']}), title=i['info']['title'], media='video', info=i['info'], thumb=i['thumb'], popup=self.popup, popup_replace=True)
		if data['page']['next']:
			titlepage = 'Следующая страница '+ str(data['page']['current']+1)+ ' из ' + str(data['page']['max']) + ' >>'
			self.item(Link('catalog',{'url':data['page']['next']}), title=titlepage)
		self.render(nextmode=_view_)


class Genres(Handler):
	def handle(self):
		data = self.argv.get('data')
		for i in data:
			self.item(Link('catalog',{'url': i[1]}), title=i[0])
		self.render(nextmode=_view_)


class VideoInfo(Handler):
	def handle(self):
		perevod = self.argv.get('perevod')
		url = self.argv.get('url')
		if url == 0:
			return True
		d = kinovod.videoinfo(url)
		data = d['data'][0]
		title = title2 = data['info']['title']
		info = data['info']
		if d.get('comments'): self.popupadd(Link('comments', d['comments']), 'Комментарии ('+str(len(d['comments'])) + ')')
		elif d.get('count_comments'): self.popupadd(Link(Comments, {'movie_id':d['movie_id']}), 'Комментарии ('+ str(d['count_comments']) + ')')
		if isinstance(d['url'], basestring):
			self.item(Link('play',{'url': data['url']}), title=title, media='video', info=info, thumb=data['thumb'], popup=True, popup_replace=True, property=[('IsPlayable','true')], folder=False)
		else:
			if perevod:
				title2 = title + u' | ' + perevod
			self.item(Link('video', {'url': data['url'] }), title=title2, media='video', info=data['info'], thumb=data['thumb'], popup=True, popup_replace=True)
			for name, durl, surl, index in d['url']:
				info['title'] = title + u' / ' + name
				if isinstance(durl, dict):
					if perevod:
						if durl.get(perevod):
							self.item(Link('play',{'url': data['url'], 'index': index, 'perevod': perevod }), title=name, media='video', info=info, thumb=data['thumb'], popup=True, popup_replace=True, property=[('IsPlayable','true')], folder=False)
					else:
						for i in durl:
							self.item(Link('video', {'url': url, 'perevod':i}), title=i, media='video', info=info, thumb=data['thumb'], popup=True, popup_replace=True)
						break
				else:
					self.item(Link('play',{'url': data['url'], 'index': index }), title=name, media='video', info=info, thumb=data['thumb'], popup=True, popup_replace=True, property=[('IsPlayable','true')], folder=False)
		for i in d['podbor2']:
			self.item(Link('video', {'url': i['url']}), title=i['info']['title'], media='video', info=i['info'], thumb=i['thumb'], popup=self.popup, popup_replace=True)
		self.render(nextmode=_view_)


class Play(Handler):
	def handle(self):
		url = self.argv.get('url')
		durl = self.argv.get('durl')
		index = self.argv.get('index')
		perevod = self.argv.get('perevod')
		if url:
			link, error = kinovod.play_link(url, index, perevod)
		elif durl: link = [durl, None]
		if link and link[0]:
			#xbmc.Player().play(link)
			#from urllib import urlencode
			#link = link + '|' + urlencode( {'Referer': link} )
			item = xbmcgui.ListItem(path=link[0])
			if link[1]:
				item.setSubtitles(link[1])
			xbmcplugin.setResolvedUrl(int(sys.argv[1]),True, item)
		else:
			xbmcgui.Dialog().ok('Киновод', *error)


class Comments(Handler):
	def handle(self):
		d = self.argv
		if isinstance(d, dict):
			d = kinovod.comments(d['movie_id'])
		text = u''
		for a, c in d:
			text += a + u'\n' + c + u'\n\n'
		if self.kodi_ver > 18:
			xbmcgui.Dialog().textviewer('Последние комментарии', text)
			return True
		gui = GuiTextViewer('DialogTextViewer.xml', sys.argv[0], descript=text, title='Последние комментарии')
		gui.doModal()
		del gui
		return True

class GuiTextViewer(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.descript = kwargs['descript']
        self.title = kwargs['title']
        xbmcgui.WindowXMLDialog.__init__(self, *args, **kwargs)
    
    def onInit(self):
        #lang = Lang()
        self.getControl(1).setLabel(self.title)
        self.getControl(5).setText(self.descript)
    
    def onFocus(self, control):
        pass


def main():
	plugin = Plugin(Menu)
	plugin.route('catalog', Catalog)
	plugin.route('usearch', Catalog)
	plugin.route('genre', Genres)
	plugin.route('video', VideoInfo)
	plugin.route('play', Play)
	plugin.route('history', History)
	plugin.rcls(Comments)
	plugin.run()


if __name__ == '__main__':

	main()
