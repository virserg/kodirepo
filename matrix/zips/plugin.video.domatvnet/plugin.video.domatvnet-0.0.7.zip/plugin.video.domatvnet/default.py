# -*- coding: utf-8 -*-

import os, sys
PY2 = sys.version_info.major == 2
sys.path.append(os.path.join(os.path.dirname(__file__)))
sys.path.append(os.path.join(os.path.dirname(__file__), 'xbmcup'))
import xbmc, xbmcplugin, xbmcgui

from xbmcup.app import Link, Handler, Plugin, _setting
import domatv
from history import History, HistoryAdd

if not PY2:
	unicode = str
	basestring = str

_view_ = _setting['view']

plugin = Plugin()

@plugin.radd()
class Menu(Handler):
	def handle(self):
		#self.item(Link('catalog',{'search': True}), title='[Поиск]')
		#self.item(Link('history'), title='[История поиска]')
		d = domatv.catalog()
		self.item(Link(Genres, {'data':d['category']}), title='Категории')
		self.item(Link(Genres, {'data':d['country']}), title='Страны')
		Catalog(argv={'data':d}).handle()
		#self.render(nextmode=_view_)


@plugin.radd()
class Genres(Handler):
	def handle(self):
		data = self.argv.get('data')
		for i in data:
			self.item(Link('catalog',{'url': i[1]}), title=i[0])
		self.render(nextmode=_view_)

@plugin.radd('userch')
@plugin.radd()
class Catalog(Handler):
	def handle(self):
		search = self.argv.get('search', self.argv.get('keyword'))
		url = self.argv.get('url')
		s_kbd = self.argv.get('s_kbd', False)
		sort = self.argv.get('sort')
		data = self.argv.get('data', None)
		page = self.argv.get('page')
		if sort:
			index = xbmcgui.Dialog().select(self.nameaddon, [x[0] for x in sort])
			if index < 0:
				return True
			else:
				url = sort[index][1]
		if page and search:
			s1, data = domatv.nextsearch(search, page)
		elif search:
			if isinstance(search, bool):
				textsearch = self.argv.get('textsearch', '')
				search = self.kbdinput('Поиск', textsearch)
				if search is None: return True
				s_kbd = True
				HistoryAdd(search)
			s1, data = domatv.search(search)
		elif url == 0:
			return True
		elif data is None:
			data = domatv.catalog(url)
		if (data['data']==[]) and s_kbd and (data['podbor'] ==[]):
			xbmcgui.Dialog().ok(self.nameaddon, 'Ничего не найдено')
		if data.get('filter'):
			for i in data['filter']:
				self.item(Link('catalog', {'sort': i['sort']}), title=i['name'], media='video', popup=self.popup, popup_replace=True)
		for i in data['data']:
			popup = []
			popup.extend(self.popup)
			title = i['info']['title']
			#popup.insert(1, (Link('catalog', {'search': True, 'textsearch': title}, True), 'Поиск') )
			if i['info'].get('plotoutline'):
				title = title + u' (' + i['yq'] + u', ' + i['info']['plotoutline'] + u')'
			elif i.get('yq'):
				title = title + u' (' + i['yq'] + u')'
			if i['info'].get('rating'):
				title = title + u' [' + unicode(i['info']['rating']) + u']'
			self.item(Link('play', {'url': i['url']}), title=title, media='video', info=i['info'], thumb=i['thumb'], popup=popup, popup_replace=True, playable=True)
		for i in data['podbor']:
			self.item(Link('catalog', {'url': i['url']}), title=i['info']['title'], media='video', info=i['info'], thumb=i['thumb'], popup=self.popup, popup_replace=True)
		if data['page']['next']:
			titlepage = 'Следующая страница '+ str(data['page']['current']+1)+ ' из ' + str(data['page']['max']) + ' >>'
			if data['page']['next'] == '#':
				self.item(Link('catalog',{'page':data['page']['snext'], 'search': search}), title=titlepage)
			else:
				self.item(Link('catalog',{'url':data['page']['next']}), title=titlepage)
		self.render(nextmode=_view_)


@plugin.radd()
class Video(Handler):
	def handle(self):
		url = self.argv.get('url')
		if url == 0:
			return True
		d = domatv.videoinfo(url)
		data = d['data'][0]
		title = data['info']['title']
		info = data['info']
		if data.get('screenshot'): self.popupadd(Link('screenshot', data['screenshot']), 'Скриншоты' + ' (' + str(len(data['screenshot'])) + ')')
		self.popupadd(Link('catalog', {'search': True, 'textsearch': title}, True), 'Поиск')
		if isinstance(d['url'], basestring):
			self.item(Link('play',{'url': data['url']}), title=title, media='video', info=info, thumb=data['thumb'], popup=True, popup_replace=True, property=[('IsPlayable','true')], cast=data['cast'], folder=False)
		else:
			self.item(Link('video', {'url': data['url'] }), title=title, media='video', info=data['info'], thumb=data['thumb'], popup=True, popup_replace=True, cast=data['cast'])
			for i in d['url']:
				info['title'] = title + u' / ' + i['title']
				#info['tracknumber'] = i['index'] + 1
				self.item(Link('play',{'url': data['url'], 'index': i['index'] }), title=i['title'], media='video', info=info, thumb=data['thumb'], popup=True, popup_replace=True, property=[('IsPlayable','true')], cast=data['cast'], folder=False)
		for i in d['podbor2']:
			self.item(Link('video', {'url': i['url']}), title=i['info']['title'], media='video', info=i['info'], thumb=i['thumb'], popup=self.popup, popup_replace=True)
		self.render(nextmode=_view_)

@plugin.radd()
class Play(Handler):
	def handle(self):
		url = self.argv.get('url')
		durl = self.argv.get('durl')
		index = self.argv.get('index')
		if url:
			link, error = domatv.play_link(url, index)
		elif durl: link = durl
		if link and link == '': error = ['Нет ссылки на видео.']
		if link:
			#xbmc.Player().play(link)
			item = xbmcgui.ListItem(path=link)
			if self.setting['is_adaptive'] == 'true' and xbmc.getInfoLabel('System.BuildVersion')[:2] > '17':
				if xbmc.getInfoLabel('System.BuildVersion')[:2] >= '19':
					item.setProperty('inputstream','inputstream.adaptive')
				else:
					item.setProperty('inputstreamaddon','inputstream.adaptive')
				item.setProperty('inputstream.adaptive.manifest_type','hls')
				if '|' in link:
					item.setProperty('inputstream.adaptive.stream_headers', link.split('|')[1])
				#item.setMimeType('application/vnd.apple.mpegurl')
				#item.setContentLookup(False)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]),True, item)
			xbmc.sleep(100)
		else:
			xbmcgui.Dialog().ok(self.nameaddon, *error)

@plugin.radd()
class ScreenShot(Handler):
	def handle(self):
		from xbmcup import slideshow
		slideshow.open(self.argv, 0)
		return True


def main():
	plugin.route('history', History)
	plugin.run()


if __name__ == '__main__':

	main()
