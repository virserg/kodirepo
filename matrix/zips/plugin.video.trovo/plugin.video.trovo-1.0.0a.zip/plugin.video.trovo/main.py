import kodi_trovo

if __name__ == '__main__':
    kodi_trovo.plugin.run()
