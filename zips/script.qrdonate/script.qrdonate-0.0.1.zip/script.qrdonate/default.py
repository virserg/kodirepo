# -*- coding: utf8 -*-
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'lib'))

import pyqrcode
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

import errors

ADDON = xbmcaddon.Addon()
ADDONID = ADDON.getAddonInfo('id')
ADDONNAME = ADDON.getAddonInfo('name')
ADDONVERSION = ADDON.getAddonInfo('version')
CWD = ADDON.getAddonInfo('path').decode('utf-8')
PROFILE = ADDON.getAddonInfo('profile').decode('utf-8')
LANGUAGE = ADDON.getLocalizedString
TEMP = xbmc.translatePath('special://temp')

class QRCode(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.image = kwargs["image"]
        self.text = kwargs["text"]
	self.label = kwargs["title"]

    def onInit(self):
        self.imagecontrol = 501
        self.textbox = 502
        self.okbutton = 503
        self.labelcontrol = 504
        self.showdialog()

    def showdialog(self):
        self.getControl(self.imagecontrol).setImage(self.image)
        self.getControl(self.textbox).setText(self.text)
        self.getControl(self.labelcontrol).setLabel(self.label)
        self.setFocus(self.getControl(self.okbutton))

    def onClick(self, controlId):
        if (controlId == self.okbutton):
            self.close()

class donateView(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.name = kwargs["name"]
        self.content = kwargs["content"]

    def onInit(self):
        self.header = 501
        self.textbox = 502
        self.showdialog()

    def showdialog(self):
        self.getControl(self.header).setLabel(self.name)
        self.getControl(self.textbox).setText(self.content)
        self.setFocusId(503)

class Main:
    def __init__(self):
            self.showQRcode(LANGUAGE(32002),'https://qiwi.com/n/AUTER419')
#                    dv = donateView( "script-donate-view.xml" , CWD, "default", title='test', content='test333')
#                    dv.doModal()
#                    del dv


    def showQRcode(self, message, qrtext=None):
        if qrtext:
            if isinstance(qrtext, str): qrtext = qrtext.decode('utf8')
            imagefile = os.path.join(xbmc.translatePath(CWD),'resources','skins','default','media','qrdonate.png')
            qrIMG = pyqrcode.create(qrtext)
            qrIMG.png(imagefile, scale=10)
            qr = QRCode( "script-qrdonate-main.xml" , CWD, "default", image=imagefile, text=message, title=LANGUAGE(32001))
            qr.doModal()
            del qr
            xbmcvfs.delete(imagefile)
        else:
            dialog = xbmcgui.Dialog()
            confirm = dialog.ok(ADDONNAME, message)

if __name__ == '__main__':
	try:
		Main()
	except BaseException as e:
		errors.log(e)
