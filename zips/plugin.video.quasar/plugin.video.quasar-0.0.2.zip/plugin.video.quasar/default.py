import os, sys, urllib
import xbmc, xbmcaddon

if __name__ == "__main__":
	#for arg in sys.argv:
	#	xbmc.log(arg)

	if sys.argv[0] == 'plugin://plugin.video.quasar/playuri' and len(sys.argv) >= 2:
		magnet = sys.argv[2].replace('?uri=', '')
		addon = xbmcaddon.Addon(id='plugin.video.quasar')
		engine =  addon.getSetting('engine')
		if engine == '0':
			url = 'plugin://plugin.video.torrenter/?action=playSTRM&url='
		elif engine == '1':
			url = 'plugin://plugin.video.tam/?mode=play&url='
		elif engine == '2':
			url = 'plugin://plugin.video.tam/?mode=open&url='
		elif engine == '3':
			url = 'plugin://plugin.video.torrserve/?action=play_now&isKlay=True&isYatse=True&selFile=0&magnet='
		url += magnet

		xbmc.log(url)

		if engine =='2':
			xbmc.executebuiltin('ActivateWindow(videos,' + url + ',return)')
		else:
			xbmc.executebuiltin('xbmc.PlayMedia(' + url + ')')

