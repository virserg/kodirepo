# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os, urllib, sys, urllib2, time
import socket
socket.setdefaulttimeout(5)

PLUGIN_NAME   = 'Animevost.org'
handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.animevost')
__settings__ = xbmcaddon.Addon(id='plugin.video.animevost')

__resolvedurl__ = bool(__settings__.getSetting('Resolvedurl')=='true')
__url__ = __settings__.getSetting('Url').strip()
__https__ = bool(__settings__.getSetting('Https')=='true')
__proto__ = 'https://' if __https__ else 'http://'
__autourl__ = bool(__settings__.getSetting('AutoUrl')=='true')

def getURL2(url,Referer = 'https://m.vk.com/'):
	try:
		opener = urllib2.build_opener()
		urllib2.install_opener(opener)
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
		req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
		req.add_header('Accept-Language', 'ru,en;q=0.9')
		req.add_header('Referer', Referer)
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except:
		return ''


def getDomain():
	import re
	data = getURL2('https://m.vk.com/animevostorg').decode('windows-1251')
	#print data
	r = re.compile(u'>http([^<]+?)</a> - для тех кто в России', re.S).search(data)
	if r:
              domain = r.group(1).replace('/','').replace('s:','').replace(':','').strip()
	      #xbmcgui.Dialog().ok('AnimeVost.org', 'Текущий адрес:',domain)
	      if domain != __url__ :
				__settings__.setSetting('Url', domain)
				return domain
	return None

if __autourl__ :
	try: at = float(__settings__.getSetting('auto_time'))
	except: at = 0
        if time.time() - at > 3600*8 :
		temp_domain = getDomain()
                if temp_domain: __url__ = temp_domain
		__settings__.setSetting('auto_time', str(time.time()))


site_url = __proto__ + __url__ if __url__ else 'https://animevost.org' #'https://a6.agorov.org'

__proxy__ = int(__settings__.getSetting('Proxy'))
__proxy_host__ = __settings__.getSetting('Proxy_host')
__proxy_port__ = __settings__.getSetting('Proxy_port')
__socks_host__ = __settings__.getSetting('Socks_host')
__socks_port__ = __settings__.getSetting('Socks_port')


Pdir = addon.getAddonInfo('path')
icon = xbmc.translatePath(os.path.join(addon.getAddonInfo('path'), 'icon.png'))
xbmcplugin.setContent(int(sys.argv[1]), 'movies')


zhanr={
	"Боевые искусства":site_url+"/zhanr/boyevyye-iskusstva/",
	"Война":site_url+"/zhanr/voyna/",
	"Драма":site_url+"/zhanr/drama/",
	"Детектив":site_url+"/zhanr/detektiv/",
	"История":site_url+"/zhanr/istoriya/",
	"Комедия":site_url+"/zhanr/komediya/",
	"Меха":site_url+"/zhanr/mekha/",
	"Мистика":site_url+"/zhanr/mistika/",
	"Махо-сёдзё":site_url+"/zhanr/makho-sedze/",
	"Музыкальный":site_url+"/zhanr/muzykalnyy/",
	"Повседневность":site_url+"/zhanr/povsednevnost/",
	"Приключения":site_url+"/zhanr/priklyucheniya/",
	"Пародия":site_url+"/zhanr/parodiya/",
	"Романтика":site_url+"/zhanr/romantika/",
	"Сёнэн":site_url+"/zhanr/senen/",
	"Сёдзё":site_url+"/zhanr/sedze/",
	"Спорт":site_url+"/zhanr/sport/",
	"Сказка":site_url+"/zhanr/skazka/",
	"Сёдзё-ай":site_url+"/zhanr/sedze-ay/",
	"Сёнэн-ай":site_url+"/zhanr/senen-ay/",
	"Самураи":site_url+"/zhanr/samurai/",
	"Триллер":site_url+"/zhanr/triller/",
	"Ужасы":site_url+"/zhanr/uzhasy/",
	"Фантастика":site_url+"/zhanr/fantastika/",
	"Фэнтези":site_url+"/zhanr/fentezi/",
	"Школа":site_url+"/zhanr/shkola/",
	"Этти":site_url+"/zhanr/etti/",
}

tip={
	"ТВ":site_url+"/tip/tv/",
	"ТВ-спэшл":site_url+"/tip/tv-speshl/",
	"OVA":site_url+"/tip/ova/",
	"ONA":site_url+"/tip/ona/",
	"Полнометражный фильм":site_url+"/tip/polnometrazhnyy-film/",
	"Короткометражный фильм":site_url+"/tip/korotnometrazhnyy-film/",
}

god={
	"1971":site_url+"/god/1971/",
	"1977":site_url+"/god/1977/",
	"1980":site_url+"/god/1980/",
	"1984":site_url+"/god/1984/",
	"1991":site_url+"/god/1991/",
	"1992":site_url+"/god/1992/",
	"1993":site_url+"/god/1993/",
	"1994":site_url+"/god/1994/",
	"1995":site_url+"/god/1995/",
	"1996":site_url+"/god/1996/",
	"1997":site_url+"/god/1997/",
	"1998":site_url+"/god/1998/",
	"1999":site_url+"/god/1999/",
	"2000":site_url+"/god/2000/",
	"2001":site_url+"/god/2001/",
	"2002":site_url+"/god/2002/",
	"2003":site_url+"/god/2003/",
	"2004":site_url+"/god/2004/",
	"2005":site_url+"/god/2005/",
	"2006":site_url+"/god/2006/",
	"2007":site_url+"/god/2007/",
	"2008":site_url+"/god/2008/",
	"2009":site_url+"/god/2009/",
	"2010":site_url+"/god/2010/",
	"2011":site_url+"/god/2011/",
	"2012":site_url+"/god/2012/",
	"2013":site_url+"/god/2013/",
	"2014":site_url+"/god/2014/",
	"2015":site_url+"/god/2015/",
	"2016":site_url+"/god/2016/",
	"2017":site_url+"/god/2017/",
	"2018":site_url+"/god/2018/",
	"2019":site_url+"/god/2019/",
	"2020":site_url+"/god/2020/",
}


def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):return xbmc.translatePath(x)
def rt(x):#('&#39;','’'), ('&#145;','‘')
	L=[('&quot;','"'),('&amp;',"&"),('&#133;','…'),('&#38;','&'),('&#34;','"'), ('&#39;','"'), ('&#145;','"'), ('&#146;','"'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y'), ('&laquo;','"'), ('&raquo;','"'), ('&nbsp;',' ')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x

def fs_enc(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode('utf-8').encode(sys_enc)

def fs_dec(path):
    sys_enc = sys.getfilesystemencoding() if sys.getfilesystemencoding() else 'utf-8'
    return path.decode(sys_enc).encode('utf-8')

def GetProxyList():
	import httplib, re
	conn = httplib.HTTPConnection("antizapret.prostovpn.org")
	conn.request("GET", "/proxy.pac", headers={"User-Agent": 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)'})
	r1 = conn.getresponse()
	data = r1.read()
	conn.close()
	proxylist = re.compile('PROXY (.+?); DIRECT').findall(data)
	return proxylist


def proxy_update():
	proxy=GetProxyList()[0]
	__settings__.setSetting("proxy_serv", proxy)
	__settings__.setSetting("proxy_time", str(time.time()))


build = []
if __proxy__ == 1:
			try:pt=float(__settings__.getSetting("proxy_time"))
			except:pt=0
			if time.time()-pt > 36000: proxy_update()
			proxy1=__settings__.getSetting("proxy_serv")
			build.append(urllib2.ProxyHandler({'http': proxy1, 'https': proxy1}))
elif (__proxy__ == 2) and __proxy_host__ and __proxy_port__: build.append(urllib2.ProxyHandler({'http': str(__proxy_host__) + ':' + str(__proxy_port__), 'https': str(__proxy_host__) + ':' + str(__proxy_port__)}))
elif (__proxy__ == 3) and __socks_host__ and __socks_port__:
		import socks
		from sockshandler import SocksiPyHandler
		build.append(SocksiPyHandler(socks.PROXY_TYPE_SOCKS5, str(__socks_host__), int(__socks_port__)))

if __proxy__ > 0:
    opener = urllib2.build_opener(*build)
    urllib2.install_opener(opener)


def url_replace(url):
	if '://' in url:
		url = url.replace('https://','').replace('http://','')
		s= url.find('/')
		return site_url + url[s:]
	else:
		return url


def save_strm(name, epd, url):
		if '.strm' not in epd: epd=epd+'.strm'
		name=name.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',"")
		epd=epd.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',"")
		if isinstance(name, unicode): name=name.encode('utf-8')
		if isinstance(epd, unicode): epd=epd.encode('utf-8')
		
		try:Directory= __settings__.getSetting("SaveDirectory")
		except: Directory=os.path.join(addon.getAddonInfo('path'), 'strm')
		if Directory=="":Directory=os.path.join(addon.getAddonInfo('path'), 'strm')
		
		SaveDirectory = os.path.join(Directory, name)
		
		if os.path.isdir(fs_enc(SaveDirectory))==0: os.mkdir(fs_enc(SaveDirectory))
		
		fl = open(fs_enc(os.path.join(SaveDirectory, epd)), "w")
		fl.write(url)
		fl.close()

def save_tvshow_nfo(name, info={}):
		name=name.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',"")
		try:title=info['title'].encode('utf-8')
		except:title=info['title']
			
		if 'сезон)' in title: title=title[:title.find(' (')]
		
		
		try:Directory= __settings__.getSetting("SaveDirectory")
		except: Directory=os.path.join(addon.getAddonInfo('path'), 'strm')
		if Directory=="":Directory=os.path.join(addon.getAddonInfo('path'), 'strm')
		
		if isinstance(Directory, unicode): Directory=Directory.encode('utf-8')
			
		SaveDirectory = os.path.join(Directory, name)
		if os.path.isdir(fs_enc(SaveDirectory))==0: os.mkdir(fs_enc(SaveDirectory))
		
		try:year=info['year']
		except:year=0
		try:plot=info['plot']
		except:plot=''
		try:cover=info['cover']
		except:cover=''
		try:fanart=info['fanart']
		except:fanart=cover

		nfo='<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>'+chr(10)
		nfo='<tvshow>'+chr(10)
		
		nfo+="	<title>"+title+"</title>"+chr(10)
		nfo+="	<showtitle>"+title+"</showtitle>"+chr(10)
		nfo+="	<year>"+str(year)+"</year>"+chr(10)
		nfo+="	<genre>Animation</genre>"+chr(10)
		nfo+="	<season>-1</season>"+chr(10)
		nfo+="	<plot>"+plot+"</plot>"+chr(10)
		nfo+="	<fanart><thumb>"+fanart+"</thumb></fanart>"+chr(10)
		nfo+="	<thumb>"+cover+"</thumb>"+chr(10)
		nfo+="</tvshow>"+chr(10)
		
		fl = open(fs_enc(os.path.join(SaveDirectory, "tvshow.nfo")), "w")
		fl.write(nfo)
		fl.close()


def save_nfo(name, s, e, info={}):
		epd=name+'.s'+s+'.e'+e
		name=name.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',"")
		epd=epd.replace("/"," ").replace("\\"," ").replace("?","").replace(":","").replace('"',"").replace('*',"").replace('|',"").replace('>',"").replace('<',"")
		try: s=s.encode('utf-8')
		except: pass
		try: e=e.encode('utf-8')
		except: pass

		title=e+" серия"
		#title=title.encode('utf-8')
		try: title=title.encode('utf-8')
		except: pass
		if 'сезон)' in title: title=title[:title.find(' (')]
		
		cn=name.find(" (")
		if cn>0: name=name[:cn]
		
		try:title=xt(info['title'])
		except:pass
		
		try:plot=info['plot']
		except:plot=""
		if plot=="":plot="Сезон "+s+" Серия "+e
		try:cover=info['cover']
		except:cover=''
		try:fanart=info['fanart']
		except:fanart=cover

		try:Directory= __settings__.getSetting("SaveDirectory")
		except: Directory=os.path.join(addon.getAddonInfo('path'), 'strm')
		if Directory=="":Directory=os.path.join(addon.getAddonInfo('path'), 'strm')
		SaveDirectory = os.path.join(Directory, name)
		if os.path.isdir(fs_enc(SaveDirectory))==0: os.mkdir(fs_enc(SaveDirectory))
		
		nfo="<episodedetails>"+chr(10)
		nfo+="	<title>"+title+"</title>"+chr(10)
		nfo+="	<season>"+str(s)+"</season>"+chr(10)
		nfo+="	<episode>"+str(e)+"</episode>"+chr(10)
		nfo+="	<plot>"+plot+"</plot>"+chr(10)
		nfo+="	<fanart>"+fanart+"</fanart>"+chr(10)
		nfo+="	<thumb>"+fanart+"</thumb>"+chr(10)
		nfo+="</episodedetails>"+chr(10)
		
		fl = open(fs_enc(os.path.join(SaveDirectory, epd+".nfo")), "w")
		fl.write(nfo)
		fl.close()


def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		#sn=http[s:]
		e=http.find(es)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def inputbox(t=''):
	skbd = xbmc.Keyboard(t, 'Название:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return t


def add_item (name, mode="", path = Pdir, ind="0", cover=icon, funart=None, info={}):
	#print name
	#print path
	if   path.find("720p")>0: qual="[COLOR FFA900EF][ 720p ] [/COLOR]"
	elif path.find("480p")>0: qual="[COLOR FFFF0090][ 480p ] [/COLOR]"
	elif path.find("400p")>0: qual="[COLOR FF70F020][ 400p ] [/COLOR]"
	elif path.find("1080p")>0:qual="[COLOR FF50FF50][1080p] [/COLOR]"
	else: qual=''#"[ ???? ] "
	if funart==None: funart=cover
	if cover==None:	listitem = xbmcgui.ListItem(qual+"[B]"+name+"[/B]")
	else:		listitem = xbmcgui.ListItem(qual+"[B]"+name+"[/B]", iconImage=cover, thumbnailImage=cover)
	listitem.setInfo(type = "Video", infoLabels = info)
	listitem.setProperty('fanart_image', funart)
	try: listitem.setArt({'poster': cover})
	except: pass
	uri = sys.argv[0] + '?mode='+mode
	uri += '&url='  + urllib.quote_plus(path.encode('utf-8'))
	uri += '&name='  + urllib.quote_plus(xt(name))
	uri += '&ind='  + urllib.quote_plus(ind)
	if cover!=None:uri += '&cover='  + urllib.quote_plus(cover)
	if funart!=None and funart!="":uri += '&funart='  + urllib.quote_plus(funart)
	
	if mode=="play": 
		fld=False
		if __resolvedurl__: listitem.setProperty('IsPlayable','true')
		else: uri=path
	else: fld=True
	
	if mode=="epd_lst":
		if 'сезон)' in name: name=name[:name.find(' (')]
		listitem.addContextMenuItems([('[B]Сохранить сериал[/B]', 'Container.Update("plugin://plugin.video.animevost/?mode=save&url='+urllib.quote_plus(path)+'&info='+urllib.quote_plus(repr(info))+'")'), ('[B]Другие сезоны[/B]', 'Container.Update("plugin://plugin.video.animevost/?mode=serch_s&name='+urllib.quote_plus(name)+'")') ])
	xbmcplugin.addDirectoryItem(handle, uri, listitem, fld)


def playvideo(url):
	item = xbmcgui.ListItem(path=url)
	xbmcplugin.setResolvedUrl(handle, True, item)


def getURL(url,Referer = site_url): #'http://coldfilm.ru/'):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
		req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
		req.add_header('Accept-Language', 'ru,en;q=0.9')
		req.add_header('Referer', Referer)
		response = urllib2.urlopen(req)
		link=response.read()
		response.close()
		return link
	except Exception, e:
		import errors
		errors.log(e,'Ошибка:')
		return ''

def POST(target, post=None, referer= site_url): #'http://tvfeed.in'):
	#print target
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		req.add_header('X-Requested-With', 'XMLHttpRequest')
		resp = urllib2.urlopen(req)
		http = resp.read()
		resp.close()
		return http
	except Exception, e:
		print e
		return ''




def pars(url):
	r=getURL(url)
	L=mfindal(r, '<div class="shortstory">', '<span><strong>')
	L2=[]
	for k in L:
		curl=''
		cover=''
		title=''
		originaltitle=''
		year=''
		genre=''
		type=''
		total=''
		rating=''
		plot=''
		for i in k.splitlines():
			if '>Смотреть<' in i: 		curl=mfind(i, '<a href="', '">')
			if 'imgRadius' in i: 		cover=mfind(i, 'src="', '" alt=')
			if 'imgRadius' in i: 		title=rt(mfind(i, 'title="', ' / '))
			if 'imgRadius' in i: 		originaltitle=mfind(mfind(i, 'title="', '"'), ' / ','/>')
			if 'Год выхода:' in i: 		year=mfind(i, '</strong>', '</p>')
			if 'Жанр:' in i: 			genre=mfind(i, '</strong>', '</p>')
			if 'Тип:' in i: 			type=mfind(i, '</strong>', '</p>')
			if 'Количество серий:' in i: total=mfind(i, '</strong>', '</p>')
			if 'current-rating' in i: 	rating=int(mfind(i, ';">', '</li>'))/20
			if 'Описание:' in i: 		plot=mfind(i, '</strong>', '<br />')
		if '://' not in cover: cover = site_url + cover
		info={
			'url':curl,
			'cover':cover,
			'title':title,
			'originaltitle':originaltitle,
			'year':year,
			'genre':genre,
			'type':type,
			'total':total,
			'rating':rating,
			'plot':plot
			}
		L2.append(info)
	return L2

def pars2(r):
	L=mfindal(r, '<div class="shortstory">', '<span><strong>')
	L2=[]
	for k in L:
		curl=''
		cover=''
		title=''
		originaltitle=''
		year=''
		genre=''
		type=''
		total=''
		rating=''
		plot=''
		for i in k.splitlines():
			if '>Смотреть<' in i: 		curl=mfind(i, '<a href="', '">')
			if 'imgRadius' in i: 		cover=mfind(i, 'src="', '" alt=')
			if 'imgRadius' in i: 		title=rt(mfind(i, 'title="', ' / '))
			if 'imgRadius' in i: 		originaltitle=mfind(mfind(i, 'title="', '"'), ' / ','/>')
			if 'Год выхода:' in i: 		year=mfind(i, '</strong>', '</p>')
			if 'Жанр:' in i: 			genre=mfind(i, '</strong>', '</p>')
			if 'Тип:' in i: 			type=mfind(i, '</strong>', '</p>')
			if 'Количество серий:' in i: total=mfind(i, '</strong>', '</p>')
			if 'current-rating' in i: 	rating=int(mfind(i, ';">', '</li>'))/20
			if 'Описание:' in i: 		plot=mfind(i, '</strong>', '<br />')
		if '://' not in cover: cover = site_url + cover
		info={
			'url':curl,
			'cover':cover,
			'title':title,
			'originaltitle':originaltitle,
			'year':year,
			'genre':genre,
			'type':type,
			'total':total,
			'rating':rating,
			'plot':plot
			}
		L2.append(info)
	return L2

def epd_lst(url):
	j=getURL(url_replace(url))
	L=eval('[['+mfind(j,'var data = {', '}').replace('","','"],["').replace('":"','","')+']]')
	#L=dict.keys()
	#L.sort()
	for i in L:
		if __settings__.getSetting("qual")=='1':qual='720/'
		else:qual=''
		add_item (i[0], 'play', 'http://video.aniland.org/'+qual+i[1]+'.mp4', '0', 'http://media.aniland.org/img/'+i[1]+'.jpg')
		
	xbmcplugin.endOfDirectory(handle)
	SetViewMode("SeriesView")

def root():
	add_item ('Поиск', 'serch')
	add_item ('Онгоинги', 'ongoing')
	add_item ('Жанр', 'genres')
	add_item ('Тип', 'types')
	add_item ('Год', 'years')
	xbmcplugin.endOfDirectory(handle)

def list(url):
	L=pars(url)
	for i in L:
		name  = i['title']
		url   = i['url']
		cover = i['cover']
		add_item (name, 'epd_lst', url, '0',cover, info=i)

def ongoing():
	for i in range(1,10):
		list(site_url+'/ongoing/page/'+str(i)+'/')
	xbmcplugin.endOfDirectory(handle)
	SetViewMode("ListView")

def genres():
	L=zhanr.keys()
	L.sort()
	for i in L:
		add_item (i, 'genre', zhanr[i])
	xbmcplugin.endOfDirectory(handle)

def genre(url):
	for i in range(1,11):
		list(url+'page/'+str(i)+'/')
	xbmcplugin.endOfDirectory(handle)
	SetViewMode("ListView")

def types():
	L=tip.keys()
	L.sort()
	for i in L:
		add_item (i, 'type', tip[i])
	xbmcplugin.endOfDirectory(handle)

def type(url):
	for i in range(1,20):
		list(url+'page/'+str(i)+'/')
	xbmcplugin.endOfDirectory(handle)
	SetViewMode("ListView")

def years():
	L=god.keys()
	L.sort()
	for i in L:
		add_item (i, 'year', god[i])
	xbmcplugin.endOfDirectory(handle)

def year(url):
	for i in range(1,20):
		list(url+'page/'+str(i)+'/')
	xbmcplugin.endOfDirectory(handle)
	SetViewMode("ListView")

def serch(s=''):
	print s
	if s=='': s=urllib.quote_plus(inputbox())
	else: s=urllib.quote_plus(s)
	for p in range(1,11):
		post='do=search&subaction=search&search_start='+str(p)+'&story='+s+'&x=0&y=0'#+'&result_from=21'
		r = POST(site_url+'/index.php?do=search', post)
		L=pars2(r)
		for i in L:
			add_item (i['title'], 'epd_lst', i['url'], '0', i['cover'], info=i)
	xbmcplugin.endOfDirectory(handle)

def save(url, info):
	title=info['title']
	if 'сезон)' in title: 
		season=to_num(mfind(title, ' (', 'сезон)'))
	else: 
		season='1'
	name=info['originaltitle']
	j=getURL(url)
	L=eval('[['+mfind(j,'var data = {', '}').replace('","','"],["').replace('":"','","')+']]')
	fanart='http://media.aniland.org/img/'+L[0][1]+'.jpg'
	if getURL(fanart)!='':info['fanart']=fanart
	else:info['fanart']=info['cover']
	for i in L:
		if __settings__.getSetting("qual")=='1':qual='720/'
		else:qual=''
		curl='http://video.aniland.org/'+qual+i[1]+'.mp4'
		thumb='http://media.aniland.org/img/'+i[1]+'.jpg'
		episode=i[0]
		if ' серия' in episode: episode=episode.replace(' серия','')
		epd=name+'.s'+season+'.e'+episode
		save_strm(name, epd, curl)
		#-------- nfo -------
		if __settings__.getSetting("NFO")=='true': 
			epd_info={}
			epd_info['title']=title
			epd_info['fanart']=thumb
			epd_info['plot']=''
			save_nfo(name, season, episode, epd_info)
	
	#-------- nfo -------
	if __settings__.getSetting("NFO")=='true': save_tvshow_nfo(name, info)
	xbmc.sleep(1000)
	xbmc.executebuiltin('UpdateLibrary("video", "", "false")')


def to_num(s):
	n='1'
	if 'второй' 	in s: n='2'
	if 'третий' 	in s: n='3'
	if 'четрертый' 	in s: n='4'
	if 'пятый' 		in s: n='5'
	if 'шестой' 	in s: n='6'
	if 'седьмой' 	in s: n='7'
	if 'восьмой' 	in s: n='8'
	if 'девятый' 	in s: n='9'
	if 'десятый' 	in s: n='10'
	if 'одинадцатый' 	in s: n='11'
	if 'двенадцатый' 	in s: n='12'
	if 'тринадцатый' 	in s: n='13'
	if 'четырнадцатый' 	in s: n='14'
	if 'пятнадцатый' 	in s: n='15'
	if 'шестнадцатый' 	in s: n='16'
	if 'семнадцатый' 	in s: n='17'
	if 'восемнадцатый' 	in s: n='18'
	if 'девятнадцатый' 	in s: n='19'
	return n

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param


def SetViewMode(lm):
	n = int(__settings__.getSetting(lm))
	if n>0:
		xbmc.sleep(200)
		xbmc.executebuiltin("Container.SetViewMode(0)")
		for i in range(1,n):
			xbmc.executebuiltin("Container.NextViewMode")

params = get_params()

try:mode = urllib.unquote_plus(params["mode"])
except:mode =""
try:name = urllib.unquote_plus(params["name"])
except:name =""
try:url = urllib.unquote_plus(params["url"])
except:url =""
try:ind = urllib.unquote_plus(params["ind"])
except:ind ="0"
try:info = eval(urllib.unquote_plus(params["info"]))
except:info = {}


if mode==""         : root()

if mode=="ongoing"  : ongoing()
if mode=="genres"   : genres()
if mode=="genre"    : genre(url)
if mode=="types"    : types()
if mode=="type"     : type(url)
if mode=="years"    : years()
if mode=="year"     : year(url)
if mode=="serch"    : serch()
if mode=="serch_s"  : serch(name)
if mode=="epd_lst"  : epd_lst(url)
if mode=="save"     : save(url, info)
if mode=="play"	    : playvideo(url)
if mode=="domain"   : getDomain()
