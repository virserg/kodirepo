# -*- coding: utf-8 -*-
import json
import socket
import urllib2
import threading

from urllib import urlencode
from config import TORRSERVED_HOST


class closing(object):
    def __init__(self, thing):
        self.thing = thing

    def __enter__(self):
        return self.thing

    def __exit__(self, *exc_info):
        self.thing.close()


class NoRedirectHandler(urllib2.HTTPRedirectHandler):
    def http_error_302(self, req, fp, code, msg, headers):
        import urllib
        infourl = urllib.addinfourl(fp, headers, headers["Location"])
        infourl.status = code
        infourl.code = code
        return infourl

    http_error_300 = http_error_302
    http_error_301 = http_error_302
    http_error_303 = http_error_302
    http_error_307 = http_error_302


def client(url, post_data=None, get_data=None, raw=False, host=None):
    socket.setdefaulttimeout(30)
    if get_data:
        url += '?' + urlencode(get_data)
    if post_data and raw:
        post_data = post_data
    elif post_data:
        try:
            post_data = json.dumps(post_data)
        except:
            post_data = {"": ""}
    if host:
        url = host + url
    else:
        url = TORRSERVED_HOST+url
    req = urllib2.Request(url, post_data)
    req.add_header('Content-Type', 'application/json')
    req.add_header('Accept-Charset', 'utf-8')
    req.add_header('User-Agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.8; rv:21.0) Gecko/20100101 Firefox/21.0')

    try:
        with closing(urllib2.urlopen(req)) as response:
            payload = response.read()

            try:
                if payload:
                    return json.loads(payload.decode('utf-8', 'replace'))
            except:
                return payload
    except urllib2.URLError as e:
	print e
        return None
    except Exception as e:
	print e
        return None

class MyHandler(urllib2.HTTPHandler):
    def http_response(self, req, response):
        return response


def touch(url):
    o = urllib2.build_opener(MyHandler())
    t = threading.Thread(target=o.open, args=(url,))
    t.start()
