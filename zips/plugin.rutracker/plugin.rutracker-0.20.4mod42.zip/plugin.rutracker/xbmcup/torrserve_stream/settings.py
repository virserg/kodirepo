import xbmcaddon, xbmc
import sys

_addon = xbmcaddon.Addon(id=sys.argv[0].replace('plugin://','').replace('/',''))
class Settings(object):
	def __init__(self):
		self.load()

	def load(self):
		self.host = _addon.getSetting('torrserver_host')
		self.port = int(_addon.getSetting('torrserver_port'))

if __name__ == '__main__':
	xbmc.log('open settings')
	_addon.openSettings()
