# -*- coding: utf-8 -*-
import xbmc
import os, sys
from pprint import pformat
from platform import uname
import inspect, traceback


def _format_vars(variables):
    """
    Format variables dictionary

    :param variables: variables dict
    :type variables: dict
    :return: formatted string with sorted ``var = val`` pairs
    :rtype: str
    """
    var_list = [(var, val) for var, val in variables.iteritems()]
    lines = []
    for var, val in sorted(var_list, key=lambda i: i[0]):
        if not (var.startswith('__') or var.endswith('__')):
            lines.append('{0} = {1}'.format(var, pformat(val)))
    return '\n'.join(lines)


def log(e, msgerror=None):
    #def logger(s):
	#print(s)
    if isinstance(e, BaseException):
	logger = lambda msg: xbmc.log(msg.encode('utf8'), xbmc.LOGERROR)
        frame_info = inspect.trace(5)[-1]
        logger('Unhandled exception detected!')
        logger('*** Start diagnostic info ***')
        logger('System info: {0}'.format(uname()))
        logger(u'OS info: {0}'.format(xbmc.getInfoLabel('System.OSVersionInfo').decode('utf8')))
        logger('Kodi version: {0}'.format(xbmc.getInfoLabel('System.BuildVersion')))
        logger('File: {0}'.format(frame_info[1]))
        context = ''
        if frame_info[4] is not None:
            for i, line in enumerate(frame_info[4], frame_info[2] - frame_info[5]):
                if i == frame_info[2]:
                    context += '{0}:>{1}'.format(str(i).rjust(5), line)
                else:
                    context += '{0}: {1}'.format(str(i).rjust(5), line)
        logger('Code context:\n' + context)
        logger('Global variables:\n' + _format_vars(frame_info[0].f_globals))
        logger('Local variables:\n' + _format_vars(frame_info[0].f_locals))
        logger('**** End diagnostic info ****')
	logger('**** Start traceback info ****')
	exc_type, exc_val, exc_tb = sys.exc_info()
	lines = traceback.format_exception(exc_type, exc_val, exc_tb, limit=30)
	for line in lines:
			logger('{0}'.format(line))
	logger('**** End traceback info ****')
        if msgerror:
		logger(msgerror)
	else:
		raise
    else:
	xbmc.log (u'RuTracker: {0}'.format(e).encode('utf8'))

