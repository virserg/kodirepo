import os
import sys

TORRSERVED_HOST = "http://127.0.0.1:8090"
TORRSERVED_SAVE = False
TORRSERVED_SUBS = False

def init():
    global TORRSERVED_HOST, TORRSERVED_SAVE, TORRSERVED_SUBS

    try:
        import xbmcaddon
        ADDON = xbmcaddon.Addon()

        if ADDON.getSetting("torrserver_host") and ADDON.getSetting("torrserver_port"):
           TORRSERVED_HOST = "http://"+ADDON.getSetting("torrserver_host")+":"+ADDON.getSetting("torrserver_port")

        if ADDON.getSetting("torrserver_save_in_db") == "true": TORRSERVED_SAVE = True
        if ADDON.getSetting("torrserver_subtitles") == "true": TORRSERVED_SUBS = True
    except:
        pass


init()
