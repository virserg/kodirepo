[COLOR red]Ru[/COLOR][COLOR green]Tracker[/COLOR] — навигатор по сайту RuTracker.org c возможностью онлайн просмотра (прослушивания) и скачивания контента.
[COLOR orange]Поддерживает просмотр через:[/COLOR]
[COLOR gold]Torrserver[/COLOR] при наличии установленной службы [COLOR pink]TorrServer[/COLOR] от [COLOR green]YouROK, Nemiroff[/COLOR].
[COLOR gold]Elementum[/COLOR] при наличии установленного видео дополнения [COLOR pink]Elementum[/COLOR] от [COLOR green]elgatito[/COLOR].
[COLOR gold]TAM[/COLOR] при наличии установленного видео дополнения [COLOR pink]TAM[/COLOR] от [COLOR green]TDW1980[/COLOR].
[COLOR gold]Torrenter[/COLOR] при наличии установленного видео дополнения [COLOR pink]Torrenter[/COLOR] от [COLOR green]inpos[/COLOR].
[COLOR gold]LibTorrent[/COLOR] при наличии установленного программного дополнения [COLOR pink]python-libtorrent[/COLOR] от [COLOR green]DiMartino, srg70, RussakHH, aisman, inpos[/COLOR].
[COLOR gold]TorrentStream[/COLOR] при наличии установленного и настроенного программного дополнения [COLOR pink]AceStream client[/COLOR] от [COLOR green]1orgar[/COLOR].
[COLOR gold]DelugeStream[/COLOR] при наличии установленного программного дополнения [COLOR pink]DelugeStream[/COLOR] от [COLOR green]HAL9000[/COLOR] и установленного торрент-клиента Deluge.
[COLOR orange]Позволяет скачивать через торрент-клиенты:[/COLOR]
Transmission (linux) 
uTorrent (windows) 

Если нужен поиск контента из дополнения [COLOR pink]KinoPoisk[/COLOR] от [COLOR green]TDW1980[/COLOR], то поставьте видео дополнение [COLOR pink]RuTracker Search[/COLOR] от [COLOR green]virserg[/COLOR].

[COLOR orange]Функционал, доступный из контекстного меню:[/COLOR]
[COLOR yellow]Информация[/COLOR] — откроется окно с информацией о фильме.
Такое же окно открывается для видеофайлов по которым «прошелся» скрапер.
[COLOR yellow]Описание[/COLOR] — просмотр описания раздачи на сайте.
[COLOR yellow]Расширенная информация[/COLOR] — если контент найден в базе TheMovieDB.org, то вызывается дополнение [COLOR pink]ExtendedInfo Script[/COLOR], в котором отображается информация о фильме (работает только для разделов Фильмы, Сериалы, Мультипликация).
[COLOR yellow]Скриншоты[/COLOR] — просмотр скринов раздачи с сайта (если эта раздача - видео).
Показывает полноразмерные скрины только с хостингов: fastpic.ru, imageban.ru, lostpic.net, vfl.ru, funkyimg.com, yapx.ru, postpic4.me и миниатюры с radikal.ru
В режиме слайд-шоу работают кнопки: стрелка влево(предыдущий скрин), стрелка вправо(следующий скрин), Home(первый скрин), End(последний скрин), ESC(выход), X(выход), Backspace(выход).
[COLOR yellow]Комментарии[/COLOR] — просмотр комментариев к раздаче с сайта.
[COLOR yellow]Статус раздачи[/COLOR] — показывает количество раздающих (сидов), качающих (личей), скачиваний.
[COLOR yellow]Поиск[/COLOR] — ищет раздачи  в разделе(например Фильмы) после редактирования строки поиска. 
[COLOR yellow]Поиск похожих раздач[/COLOR] — ищет другие раздачи этого же контента (с другим качеством).
[COLOR yellow]Добавить в закладки[/COLOR] — добавляет контент в раздел "Закладки" (для последующего скачивания и просмотра).
[COLOR yellow]Обновить описание в кэше[/COLOR] — берет текущие описание и информацию по выбранному контенту с сайтов RuTracker.org и TheMovieDB.org(если в настройках выбран Tmdb).
[COLOR yellow]Перейти на страницу[/COLOR] — переход на страницу по её номеру.


[COLOR orange]Функционал, доступный через настройки дополнения:[/COLOR]
[COLOR yellow]Создавать поддиректорию для скрапера[/COLOR] — если вы отметите этот пункт, то при передаче раздачи в торрент-клиент, будет создана подпапка с наименованием, максимально подходящим для скрапера.
