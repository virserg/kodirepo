# -*- encoding: utf-8 -*-
import re, base64, urllib, json
from .net import HTTP

# ################################
#
#   TORRENT
#
# ################################

class Torrent:
    def __init__(self, client, **kwargs):
        if client == 'utorrent':
            self.client = UTorrent()
        
        elif client == 'transmission':
            self.client = Transmission()
        
        self.client.config(login=kwargs.get('login'), password=kwargs.get('password'), host=kwargs.get('host'), port=kwargs.get('port'), url=kwargs.get('url'))
    
    def list(self):
        return self.client.list()
    
    def add(self, torrent, dirname):
        return self.client.add(torrent, dirname)
    
    def delete(self, id):
        return self.client.delete(id)



class UTorrent:
    def config(self, login, password, host, port, url=None):
        self.login = login
        self.password = password
        
        self.url = 'http://' + host
        if port:
            self.url += ':' + str(port)
        self.url += '/gui/'
            
        self.http = HTTP()
        
        self.re = {
            'cookie': re.compile('GUID=([^;]+);'),
            'token': re.compile("<div[^>]+id='token'[^>]*>([^<]+)</div>")
        }
        
        
    
    def list(self):
        obj = self.action('list=1')
        if not obj:
            return None
        
        res = []
        for r in obj.get('torrents', []):
            res.append({
                'id': r[0],
                'status': self.get_status(r[1], r[4]/10),
                'name': r[2],
                'size': r[3],
                'progress': r[4]/10,
                'download': r[5],
                'upload': r[6],
                'ratio': r[7],
                'upspeed': r[8],
                'downspeed': r[9],
                'eta': r[10],
                'peer': r[12] + r[14],
                'leach': r[12],
                'seed': r[14],
                'add': r[23],
                'finish': r[24],
                'dir': r[26]
            })
        
        return res
        
    
    def add(self, torrent, dirname):
        obj = self.action('action=getsettings')
        if not obj:
            return None
        
        old_dir = None
        setting = [x[2] for x in obj['settings'] if x[0] == 'dir_active_download']
        if setting:
            old_dir = setting[0]
        
        if isinstance(dirname, unicode):
            dirname = dirname.encode('windows-1251')
        
        obj = self.action('action=setsetting&s=dir_active_download&v=' + urllib.quote(dirname, ''))
        if not obj:
            return None
        
        res = self.action('action=add-file', {'name': 'torrent_file', 'content-type': 'application/x-bittorrent', 'body': torrent})
        
        if old_dir:
            self.action('action=setsetting&s=dir_active_download&v=' + urllib.quote(old_dir.encode('windows-1251'), ''))
        
        return True if res else None
        
        
    def delete(self, id):
        pass
    
    def action(self, uri, upload=None):
        cookie, token = self.get_token()
        if not cookie:
            return None
        
        req = HTTPRequest(self.url + '?' + uri + '&token=' + token, headers={'Cookie': cookie}, auth_username=self.login, auth_password=self.password)
        if upload:
            req.upload = upload
        
        response = self.http.fetch(req)
        if response.error:
            return None
        else:
            try:
                obj = json.loads(response.body)
            except:
                return None
            else:
                return obj
    
    def get_token(self):
        response = self.http.fetch(self.url + 'token.html', auth_username=self.login, auth_password=self.password)
        if response.error:
            return None, None
        
        r = self.re['cookie'].search(response.headers.get('set-cookie', ''))
        if r:
            cookie = r.group(1).strip()
            r = self.re['token'].search(response.body)
            if r:
                token = r.group(1).strip()
                if cookie and token:
                    return 'GUID=' + cookie, token
                    
        return None, None
    
    def get_status(self, status, progress):
        mapping = {
            'error':            'stopped',
            'paused':           'stopped',
            'forcepaused':      'stopped',
            'notloaded':        'check_pending',
            'checked':          'checking',
            'queued':           'download_pending',
            'downloading':      'downloading',
            'forcedownloading': 'downloading',
            'finished':         'seed_pending',
            'queuedseed':       'seed_pending',
            'seeding':          'seeding',
            'forceseeding':     'seeding'
        }
        return mapping[self.get_status_raw(status, progress)]
        
    
    def get_status_raw(self, status, progress):
        """
            Return status: notloaded, error, checked,
                           paused, forcepaused,
                           queued,
                           downloading, 
                           finished, forcedownloading
                           queuedseed, seeding, forceseeding
        """
        
        
        started = bool( status & 1 )
        checking = bool( status & 2 )
        start_after_check = bool( status & 4 )
        checked = bool( status & 8 )
        error = bool( status & 16 )
        paused = bool( status & 32 )
        queued = bool( status & 64 )
        loaded = bool( status & 128 )
        
        if not loaded:
            return 'notloaded'
        
        if error:
            return 'error'
        
        if checking:
            return 'checked'
        
        if paused:
            if queued:
                return 'paused'
            else:
                return 'forcepaused'
            
        if progress == 100:
            
            if queued:
                if started:
                    return 'seeding'
                else:
                    return 'queuedseed'
                
            else:
                if started:
                    return 'forceseeding'
                else:
                    return 'finished'
        else:
            
            if queued:
                if started:
                    return 'downloading'
                else:
                    return 'queued'
                
            else:
                if started:
                    return 'forcedownloading'
                
        return 'stopped'


class Transmission:
    def config(self, login, password, host, port, url):
        self.login = login
        self.password = password
        
        self.url = 'http://' + host
        if port:
            self.url += ':' + str(port)
        
        if url[0] != '/':
            url = '/' + url
        if url[-1] != '/':
            url += '/'
        
        self.url += url
            
        self.http = HTTP()
        
        self.token = '0'
    
    def list(self):
        obj = self.action({'method': 'torrent-get', 'arguments': {'fields': ['id', 'status', 'name', 'totalSize', 'sizeWhenDone', 'leftUntilDone', 'downloadedEver', 'uploadedEver', 'uploadRatio', 'rateUpload', 'rateDownload', 'eta', 'peersConnected', 'peersFrom', 'addedDate', 'doneDate', 'downloadDir', 'peersConnected', 'peersGettingFromUs', 'peersSendingToUs']}})
        if obj is None:
            return None
        
        res = []
        for r in obj['arguments'].get('torrents', []):
            res.append({
                'id': str(r['id']),
                'status': self.get_status(r['status']),
                'name': r['name'],
                'size': r['totalSize'],
                'progress': 0 if not r['sizeWhenDone'] else int(100.0 * float(r['sizeWhenDone'] - r['leftUntilDone']) / float(r['sizeWhenDone'])),
                'download': r['downloadedEver'],
                'upload': r['uploadedEver'],
                'upspeed': r['rateUpload'],
                'downspeed': r['rateDownload'],
                'ratio': float(r['uploadRatio']),
                'eta': r['eta'],
                'peer': r['peersConnected'],
                'seed': r['peersSendingToUs'],
                'leech': r['peersGettingFromUs'],
                'add': r['addedDate'],
                'finish': r['doneDate'],
                'dir': r['downloadDir']
            })
            
        return res
    
    def add(self, torrent, dirname):
        if self.action({'method': 'torrent-add', 'arguments': {'download-dir': dirname, 'metainfo': base64.b64encode(torrent)}}) is None:
            return None
        return True
    
    def delete(self, id):
        pass
    
    def action(self, request):
        try:
            jsobj = json.dumps(request)
        except:
            return None
        else:
            
            while True:
                # пробуем сделать запрос
                if self.login:
                    response = self.http.fetch(self.url+'rpc/', method='POST', params=jsobj, headers={'x-transmission-session-id': self.token}, auth_username=self.login, auth_password=self.password)
                else:
                    response = self.http.fetch(self.url+'rpc/', method='POST', params=jsobj, headers={'x-transmission-session-id': self.token})
                if response.error:
                    
                    # требуется авторизация?
                    if response.code == 401:
                        if not self.get_auth():
                            return None
                    
                    # требуется новый токен?
                    elif response.code == 409:
                        if not self.get_token(response.error):
                            return None
                    
                    else:
                        return None
                
                else:
                    try:
                        obj = json.loads(response.body)
                    except:
                        return None
                    else:
                        return obj
    
    def get_auth(self):
        response = self.http.fetch(self.url, auth_username=self.login, auth_password=self.password)
        if response.error:
            if response.code == 409:
                return self.get_token(response.error)
        return False
    
    def get_token(self, error):
        token = error.headers.get('x-transmission-session-id')
        if not token:
            return False
        self.token = token
        return True
    
    def get_status(self, code):
        mapping = {
            0: 'stopped',
            1: 'check_pending',
            2: 'checking',
            3: 'download_pending',
            4: 'downloading',
            5: 'seed_pending',
            6: 'seeding'
        }
        return mapping[code]
