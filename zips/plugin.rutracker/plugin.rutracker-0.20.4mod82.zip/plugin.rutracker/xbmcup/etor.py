# -*- encoding: utf-8 -*-
import os, sys, time, base64, urllib, thread
import xbmc, xbmcgui, xbmcaddon, xbmcplugin


try:
    import libtorrent
except ImportError, e:
    try:
        from python_libtorrent import get_libtorrent
        libtorrent=get_libtorrent()
    except Exception, e:
        _IS_LIBTORRENT = False
    else:
        if libtorrent is None:
             _IS_LIBTORRENT = False
        else:
             _IS_LIBTORRENT = True
else:
    _IS_LIBTORRENT = True

try:
    from TSCore import TSengine
except ImportError:
    _IS_TORRENTSTREAM = False
else:
    _IS_TORRENTSTREAM = True



# ################################
#
#   LIBTORRENT
#
# ################################


class LibTorrentInfo(object):
    def __init__(self):

        self.lang = self._language()

        self.is_show = False
        self.window = xbmcgui.Window(12005)

        # get resolution
        # https://github.com/steeve/xbmctorrent/blob/master/resources/site-packages/xbmctorrent/player.py#L90
        import xml.etree.ElementTree as ET
        res = ET.parse(os.path.join(xbmc.translatePath('special://skin/'), 'addon.xml')).findall('./extension/res')[0]
        self._width = int(res.attrib['width'])
        self._height = int(res.attrib['height'])

        black = os.path.normpath(os.path.join(os.path.dirname(__file__), '../resources/media/black.jpg'))
        white = os.path.normpath(os.path.join(os.path.dirname(__file__), '../resources/media/white.jpg'))

        self.label = xbmcgui.ControlLabel(self.width(40), self.height(23) + 4, self.width(55), self.height(6), ' ', textColor='0xAAFFFFFF', alignment=5)

        self.controls = [
            xbmcgui.ControlImage(0, self.height(20), self.width(100), self.height(37), black, colorDiffuse='0xDD000000'),
            xbmcgui.ControlImage(0, self.height(31), self.width(100), 1, white, colorDiffuse='0x22FFFFFF'),
            xbmcgui.ControlLabel(self.width(5), self.height(23), self.width(25), self.height(6), '[B]LibTorrent Player[/B]', font='font16', textColor='0xAAFFFFFF'),
            self.label
        ]

        self.progress = {}
        self.percent = {}
        self.bytes = {}

        for i, tag in enumerate(('file', 'total')):
            self.controls.append(xbmcgui.ControlLabel(self.width(5), self.height(34) + self.height(11)*i, self.width(25), self.height(6), self.lang['label_' + tag], textColor='0xAAFFFFFF', alignment=4))
            self.controls.append(xbmcgui.ControlImage(self.width(5), self.height(40) + self.height(11)*i, self.width(90), self.height(2), white, colorDiffuse='0x22FFFFFF'))

            self.bytes[tag] = xbmcgui.ControlLabel(self.width(37), self.height(34) + self.height(11)*i, self.width(50), self.height(6), ' ', textColor='0xAAFFFFFF', alignment=5)
            self.controls.append(self.bytes[tag])

            self.percent[tag] = xbmcgui.ControlLabel(self.width(88), self.height(34) + self.height(11)*i, self.width(7), self.height(6), '[B]0%[/B]', font='font16', textColor='0xAAFFFFFF', alignment=5)
            self.controls.append(self.percent[tag])

            self.progress[tag] = xbmcgui.ControlImage(self.width(5), self.height(40) + self.height(11)*i, 0, self.height(2), white, colorDiffuse='0x77FFFFFF')
            self.controls.append(self.progress[tag])


    def show(self):
        if self.width and not self.is_show:
            self.window.addControls(self.controls)
            self.is_show = True


    def hide(self):
        if self.is_show:
            try:
                self.window.removeControls(self.controls)
            except RuntimeError:
                pass
            self.is_show = False


    def update(self, state, peers, seeds, down_speed, up_speed, download, size, total_download, total_size):
        if state in ('init', 'stop'):
            self.label.setLabel(self.lang[state])
        else:
            speed = self.human(up_speed if state == 'seed' else down_speed, True)
            self.label.setLabel(self.lang['status'] % (seeds, peers, speed, self.lang[state]))

            for tag, b, s in (('file', download, size), ('total', total_download, total_size)):
                percent = self.calc_percent(b, s)
                self.bytes[tag].setLabel(u' / '.join([self.human(b, False), self.human(s, False)]))
                self.percent[tag].setLabel(u'[B]' + str(percent) + u'%[/B]')
                self.progress[tag].setWidth(self.width(0.85*float(percent)))


    def human(self, bytes, is_bit):
        tags = ('kbit', 'mbit', 'gbit', 'tbit') if is_bit else ('kb', 'mb', 'gb', 'tb')
        human = None
        for h, f in ((tags[0], 1024), (tags[1], 1024*1024), (tags[2], 1024*1024*1024), (tags[3], 1024*1024*1024*1024)):
            if bytes/f > 0:
                human = h
                factor = f
            else:
                break
        if human is None:
            return (u'%10.1f %s' % (bytes, self.lang[tags[0]])).replace(u'.0', u'').strip()
        else:
            return (u'%10.2f %s' % (float(bytes)/float(factor), self.lang[human])).strip()


    def calc_percent(self, num, total):
        if not total:
            return 0
        if num == total:
            return 100
        r = int(float(num)*100.0/float(total))
        return 100 if r > 100 else r

    def width(self, percent):
        return int(self._width*(float(percent)/100.0))

    def height(self, percent):
        return int(self._height*(float(percent)/100.0))

    def _language(self):
        tags = dict(
            status = 100000,

            init   = 100001,
            buffer = 100002,
            down   = 100003,
            up     = 100004,
            seed   = 100005,
            stop   = 100006,
            copy   = 100007,

            label_buffer = 100031,
            label_file   = 100032,
            label_total  = 100033,

            b  = 100100,
            kb = 100101,
            mb = 100102,
            gb = 100103,
            tb = 100104,

            bit  = 100200,
            kbit = 100201,
            mbit = 100202,
            gbit = 100203,
            tbit = 100204
        )
        addon = xbmcaddon.Addon(id=sys.argv[0].replace('plugin://','').replace('/',''))
        lang = {}
        for tag, key in tags.iteritems():
            lang[tag] = addon.getLocalizedString(key)
        return lang



class LibTorrent:
    def __init__(self):
        self.is_install = _IS_LIBTORRENT    
    
    def list(self, torrent, reverse=False, sortfile=False, pathfile=False, sortpath=False, onlyvideo=False, onlyaudio=False):
        file_storage = self._torrent_info(torrent)
        #files = [{'id': i, 'name': file_storage.file_path(i).split(os.sep)[-1], 'size': file_storage.file_size(i)} for i in range(file_storage.num_files())]
        files = list()
        for i, f in enumerate(file_storage.files()):
           if pathfile:
                files.append({'id': int(i), 'name': f.path, 'size': f.size, 'fullname': f.path})
           else:
                files.append({'id': int(i), 'name': f.path.split(os.sep)[-1], 'size': f.size, 'fullname': f.path})
        if sortfile:
            if sortpath:
                files.sort(cmp=lambda f1, f2: cmp(f1['fullname'], f2['fullname']))
            else:
                    files.sort(cmp=lambda f1, f2: cmp(f1['name'], f2['name']))
        if reverse:
            files.reverse()
        file_ext= []
        if onlyvideo:
                video_file_ext = ['3gp', 'avi', 'mkv', 'mp4', 'mov', 'wmv', 'm2ts', 'ts', 'divx', 'ogm', 'm4v',
                                      'flv', 'm2v', 'mpeg', 'mpg', 'mts', 'vob', 'bdmv']
                file_ext.extend(video_file_ext)
        if onlyaudio:
                audio_file_ext = ['mp3', 'flac', 'ape', 'ogg', 'ac3', 'dts', 'wma', 'wav', 'aac', 'mp2', 'mka',
                                        'midi', 'aiff', 'it', 's3m', 'mod']
                file_ext.extend(audio_file_ext)
        if onlyvideo or onlyaudio:
                files_temp = list()
                for i in files:
                        if i['name'].split('.')[-1] in file_ext:
                                files_temp.append(i)
                files = files_temp
        return files
        
    
    def play(self, torrent, file_id, dirname, seed=None, info=None, notice=False, buffer=45):
        torrent_info = self._torrent_info(torrent)
        
        # length
        file_storage = torrent_info.files()
        #size = file_storage.file_size(file_id)
        #self._filename = os.path.join(dirname, file_storage.file_path(file_id).decode('utf8'))
        for i, f in enumerate(file_storage):
                if file_id == int(i):
                        size = f.size
                        self._filename = os.path.join(dirname, f.path.decode('utf8'))
                        file_offset = f.offset
        self._fname = self._filename.split(os.sep.decode('utf8'))[-1].encode('utf8')
        offset = (buffer+20)*1024*1024 / torrent_info.piece_length()
        start = file_offset / torrent_info.piece_length()
        end = (file_offset + size) / torrent_info.piece_length()
        buffer = buffer*1024*1024
        
        # start session
        self._session = libtorrent.session()
        
        # start DHT
        self._session.start_dht()
        self._session.add_dht_router('router.bittorrent.com', 6881)
        self._session.add_dht_router('router.utorrent.com', 6881)
        self._session.add_dht_router('router.bitcomet.com', 6881)
        self._session.listen_on(6881, 6891)
        
        # events
        self._session.set_alert_mask(libtorrent.alert.category_t.storage_notification)
        
        # add torrent
        if seed is not None:
            if seed:
                self._session.set_upload_rate_limit(seed)
            #self._handle = self._session.add_torrent({'ti': torrent_info, 'save_path': dirname.encode('utf8'), 'paused': False, 'auto_managed': False, 'seed_mode': True})
            self._handle = self._session.add_torrent({'ti': torrent_info, 'save_path': dirname.encode('utf8')})
        else:
            self._handle = self._session.add_torrent({'ti': torrent_info, 'save_path': dirname.encode('utf8')})
        
        # low priority
        for i in range(torrent_info.num_pieces()):
            self._handle.piece_priority(i, 0)
        
        # high priority
        for i in range(start, start + offset):
            if i <= end:
                self._handle.piece_priority(i, 7)
        
        # sequential
        self._handle.set_sequential_download(True)
        
        self._stop = False
        self._complete = False
        
        thread.start_new_thread(self._download, (start, end))
        
        percent = 0
        firstsize = size if size < buffer else buffer
        persize = firstsize/100
        
        progress = xbmcgui.DialogProgress()
        progress.create(u'Please Wait')
        progress.update(0, self._fname, u'Size: ' + self._human(firstsize) + u' / ' + self._human(size).strip(), u'Load: ' + self._human(0))
        
        while percent < 100:
            time.sleep(1)
            load = self._handle.file_progress()[file_id]
            percent = int(load/persize)
            progress.update(percent, self._fname, u'Size: ' + self._human(firstsize) + u' / ' + self._human(size).strip(), u'Load: ' + self._human(load))
            if progress.iscanceled():
                progress.close()
                return self._end()
        progress.close()

        if info:
            info['size'] = size
            xbmc.Player().play(self._filename.encode('utf8'), info)
        else:
            #xbmc.Player().play(self._filename.encode('utf8'))
            list_item = xbmcgui.ListItem(path=self._filename.encode('utf8'))
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

        window_info = LibTorrentInfo()

        while xbmc.Player().isPlaying():

            if xbmc.getCondVisibility('Player.Paused'):
                window_info.show()
                window_info.update(**self._get_state(file_id, size))
            else:
                window_info.hide()


            if not self._complete:
                priorities = self._handle.piece_priorities()
                status = self._handle.status()

                download = 0
                
                if len(status.pieces):
                    
                    for i in range(start, end + 1):
                        if priorities[i] != 0 and not status.pieces[i]:
                            download += 1
                            
                    for i in range(start, end + 1):
                        if priorities[i] == 0 and download < offset:
                            self._handle.piece_priority(i, 1)
                            download += 1
                    
                    for i in range(start, end + 1):
                        if not status.pieces[i]:
                            break
                    else:
                        self._complete = True
                        
                        if notice:
                            if not isinstance(notice, basestring):
                                notice = xbmcaddon.Addon(id=sys.argv[0].replace('plugin://', '').replace('/', '')).getAddonInfo('icon')
                            if notice:
                                xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % ('Download complete', self._fname, 5000, notice))
                            else:
                                xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s)' % ('Download complete', self._fname, 5000))
            
            time.sleep(1)

        window_info.hide()

        return self._end()


    def _get_state(self, fid, size):
        res = dict(
            state='init',
            peers=0,
            seeds=0,
            down_speed=0,
            up_speed=0,
            total_download=0,
            total_size=0
        )

        try:
            info = self._handle.get_torrent_info()
        except RuntimeError:
            pass
        else:
            states = {
                'queued_for_checking': 'init',
                'checking_files': 'init',
                'downloading_metadata': 'down',
                'downloading': 'down',
                'seeding': 'seed',
                'allocating': 'init',
                'checking_resume_data': 'init'
            }

            progress = self._handle.file_progress()
            status = self._handle.status()
            state = str(status.state)

            if state == 'finished':
                res['state'] = 'seed' if status.is_seeding else 'down'
            else:
                res['state'] = states.get(state, 'init')

            res['peers'] = status.num_peers
            res['seeds'] = status.num_seeds
            res['down_speed'] = 8*status.download_payload_rate  # 8*byte
            res['up_speed'] = 8*status.upload_payload_rate  # 8*byte

            res['download'] = progress[fid]
            res['size'] = size

            res['total_download'] = sum(progress)
            res['total_size'] = info.total_size() if self._handle.has_metadata else 0

        return res
    
    
    def _end(self):
        self._stop = True
        
        try:
            self._session.remove_torrent(self._handle)
        except:
            pass
        
        return self._filename if self._complete else None
        
        
    def _download(self, start, end):
        cache = {}
        
        for i in range(start, end + 1):
            
            if i in cache:
                del cache[i]
                continue
            
            while True:
                status = self._handle.status()
                if not status.pieces or status.pieces[i]:
                    break
                time.sleep(0.5)
                if self._stop:
                    return
                
            self._handle.read_piece(i)
            
            while True:
                part = self._session.pop_alert()
                if isinstance(part, libtorrent.read_piece_alert):
                    if part.piece == i:
                        break
                    else:
                        cache[part.piece] = part.buffer
                    break
                time.sleep(0.5)
                if self._stop:
                    return
            
            time.sleep(0.1)
            if self._stop:
                return
    
    
    def _torrent_info(self, torrent):
        filename = os.tempnam()
        file(filename, 'wb').write(torrent)
        torrent_info = libtorrent.torrent_info(filename)
        os.unlink(filename)
        return torrent_info
    
    def _human(self, size):
        human, factor = None, 1
        for h, f in (('KB', 1024), ('MB', 1024*1024), ('GB', 1024*1024*1024), ('TB', 1024*1024*1024*1024)):
            if size/f > 0:
                human = h
                factor = f
            else:
                break
        if human is None:
            return (u'%10.1f %s' % (size, u'byte')).replace(u'.0', u'')
        else:
            return u'%10.2f %s' % (float(size)/float(factor), human)
    

# ################################
#
#   TORRENT STREAM
#
# ################################

class TorrentStream:
    def __init__(self, portfile=None):
        self.is_install = _IS_TORRENTSTREAM
        self._portfile = portfile
    
    def list(self, torrent, reverse=False):
        ts = TSengine()
        if str(ts.load_torrent(base64.b64encode(torrent), 'RAW', port=self._get_port())).upper() != 'OK':
            ts.end()
            return None
        
        if not ts.files or not isinstance(ts.files, dict):
            ts.end()
            return None
        
        files = [{'id': v, 'name': urllib.unquote(k)} for k, v in ts.files.iteritems()]
        ts.end()
        files.sort(cmp=lambda f1, f2: cmp(f1['name'], f2['name']))
        if reverse:
            files.reverse()
        return files
        
    
    def play(self, torrent, file_id, title=None, icon=None, cover=None):
        if not title:
            title = ''
        if not icon:
            icon = ''
        if not cover:
            cover = ''
            
        ts = TSengine()
        if str(ts.load_torrent(base64.b64encode(torrent), 'RAW', port=self._get_port())).upper() != 'OK':
            ts.end()
            return
        
        ts.play_url_ind(int(file_id), title, icon, cover, True)
        ts.end()

    def _get_port(self):
        port = None
        if self._portfile:
            try:
                port = int(file(self._portfile, 'rb').read())
            except:
                pass
        if not port:
            try:
                port = int(file(os.path.normpath(os.path.join(os.path.expanduser('~'), 'AppData/Roaming/TorrentStream/engine', 'acestream.port')), 'rb').read())
            except:
                pass
        return port if port else 62062




