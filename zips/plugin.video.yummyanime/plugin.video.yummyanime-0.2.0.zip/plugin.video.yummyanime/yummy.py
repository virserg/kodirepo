# -*- coding: utf-8 -*-

import sys, os
import re


site_url = 'https://yummyanime.club'

try:
	from xbmcup.app import _setting
	_quality_ = _setting['quality']
except:
	_quality_ = '720'
       	sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'script.module.beautifulsoup4', 'lib'))

try:
	import xbmc
       	sys.path.insert(0, os.path.join(xbmc.translatePath('special://home/'), 'addons', 'script.module.requests', 'lib'))
       	sys.path.insert(0, os.path.join(xbmc.translatePath('special://home/'), 'addons', 'script.module.urllib3', 'lib'))
       	sys.path.insert(0, os.path.join(xbmc.translatePath('special://home/'), 'addons', 'script.module.certifi', 'lib'))
       	sys.path.insert(0, os.path.join(xbmc.translatePath('special://home/'), 'addons', 'script.module.idna', 'lib'))
       	sys.path.insert(0, os.path.join(xbmc.translatePath('special://home/'), 'addons', 'script.module.chardet', 'lib'))
except:
    try:
       	sys.path.insert(0 , os.path.join(os.path.dirname(__file__), '..', 'script.module.requests', 'lib'))
       	sys.path.insert(0 , os.path.join(os.path.dirname(__file__), '..', 'script.module.urllib3', 'lib'))
       	sys.path.insert(0 , os.path.join(os.path.dirname(__file__), '..', 'script.module.certifi', 'lib'))
       	sys.path.insert(0 , os.path.join(os.path.dirname(__file__), '..', 'script.module.idna', 'lib'))
       	sys.path.insert(0 , os.path.join(os.path.dirname(__file__), '..', 'script.module.chardet', 'lib'))
       	#sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'script.module.js2py', 'lib'))
	#print sys.path
    except:	pass

headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
            'Cache-Control': 'no-cache',
            'Referer': site_url
        }

Quality = (360, 480, 720, 1080)

class Error(Exception):
    def __init__(self, msg):
	self.msg = msg

    def __str__(self):
	return '{}'.format(self.msg)

def r_u(url):
	if url.startswith(site_url): return url.replace(site_url,'')
	else: return url

def n_u(url):
	if ('://' in url) or (url is None) or (url[0] != '/'): return url
	else: return site_url + url

def getUrl(url, rurl=False, rheaders=False, referer=None):
	from xbmcup.net import HTTP
	http = HTTP()
	if referer: headers['Referer'] = referer
	response = http.fetch(url, headers=headers, cookies='yummyanime.moz')
	if response.code == 200:
		if rurl:
			return response.url , response.body
		elif rheaders:
			return response.headers, response.body
		else:
			return response.body
	elif response.code == 503:
		try:
				from xbmcup.errors import message
				message('Ошибка '+str(response.code)+' HTTP:', response.error)
		except: pass

			#print ('test!')
		try:
                    	from cfscrape import CloudflareScraper
                    	scraper = CloudflareScraper()
                    	c = scraper.get(url)
			#print c
			if rurl:
				return c.url, c.content
			else:
				return c.content
		except BaseException as e:
			try:
				from xbmcup.errors import message, log
				message('Ошибка '+str(response.code)+' HTTP:', response.error)
				import xbmc
				xbmc.sleep(3000)
				log(e)
			except: pass
			return response.code
        else:
		try:
			from xbmcup.errors import message
			message('Ошибка '+str(response.code)+' HTTP:', response.error)
			import xbmc
			xbmc.sleep(3000)
		except: pass
		raise Error(response.error)
		return response.code


def pars(data):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	category_list = []
	c = soup.findAll('ul', 'category-list')
	for i in c:
		t = i.findAll('a')
		for j in t:
			category_list.append( (j.text, site_url + j['href']) )

	page = {'max': 1, 'current': 1, 'next': None, 'prev': None}
	p = soup.find('ul', 'pagination')
	if p:
		try:
			page['current'] = int(p('li', 'active')[0].span.text)
			page['max'] = int(p('a')[-2].text)
		except: pass
		try:
			next_p = p('a' , rel='next')[0]['href']
			if '://' not in next_p: next_p = site_url + next_p
			page['next'] = next_p
		except: pass
		try:
			prev_p = p('a' , rel='prev')[0]['href']
			if '://' not in prev_p: prev_p = site_url + prev_p
			page['prev'] = prev_p
		except: pass

	data_list = []
	d = soup.findAll('div', 'anime-column')
	for i in d:
		info = {}
		title = i.find('a', 'anime-title').text
		info['title'] = title
		type = i.find('p').text
		try:	info['rating'] = float(i.find('span', 'main-rating').text)
		except:	pass
		try:
			votefull = i.find('span', 'main-rating-info').text
			info['votes'] = re.compile(r'(\d+)').findall(votefull)[0]
		except: pass
		t = i('a', 'image-block')[0]
		url = t['href']
		if '://' not in url: url = site_url + url
        	img = t('img')[0]['src']
		if '://' not in img: img = site_url + img
		try:	year = t.text.strip().replace('\n',',')
		except: pass
		try: 	info['year'] = int(re.compile(r'(\d+)').findall(year)[0])
		except:	pass
		data_list.append({'url': url, 'type': type, 'thumb': img, 'info': info, 'year': year})
		#print url, title, type, info['year']

	u = soup.find('ul', 'update-list')
	if u:
		c = u.findAll('li')
		#i = c[0]
		for i in c:
		#if i:
			info = {}
			t = i.find('a')
			if t:
				url = n_u(t['href'])
			t = i.find('span', 'update-date')
			if t:
				year = t.text
				info['tagline'] = year
			t = i.find('img')
			if t:
				img = n_u(t['src'])
			t = i.find('span', 'update-title')
			if t:
				info['title'] = t.text
			t = i.find('span', 'update-info')
			if t:
				type = t.text
				info['plotoutline'] = type
			data_list.append({'url': url, 'type': type, 'thumb': img, 'info': info, 'year': year})

	return {'category': category_list, 'page': page, 'data': data_list}


def pars2(data):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data.replace('</iframe>">',''), 'html.parser')

	p = soup.find('div', 'content-page')
	info = {}
	img = p.find('div', 'poster-block')('img')[0]['src']
	if '://' not in img: img = site_url + img
	title = p.find('h1').text.strip()
	info['title'] = title
	try:	info['rating'] = float(p.find('span', 'main-rating').text)
	except:	pass
	try:
		votefull = p.find('span', 'main-rating-info').text
		info['votes'] = re.compile(r'(\d+)').findall(votefull)[0]
	except: pass
	titlealt = [i.text for i in p.find('ul').findAll('li') if i]
	info['originaltitle'] = titlealt[-1]
	info['plot'] =''.join(p.find('div', 'content-desc').findAll(text=True)).strip()
	c = p.find('ul', 'content-main-info')
	try:	year = c.findAll('li')[2].text
	except: pass
	try:	info['year'] = int(re.compile(r'(\d+)').findall(year)[0])
	except:	pass
	#print c.text
	r = re.compile(u'(Просмотров:\s*?[ \d]+?)\n').search(c.text)
	if r: info['writer'] = r.group(1).strip()
	r = re.compile(u'Возрастной рейтинг:\s*?(.+?)\n').search(c.text)
	if r:	info['mpaa'] = r.group(1).strip()
	r = re.compile(u'Статус:\s*?(.+?)\n').search(c.text)
	if r: info['status'] = r.group(1).strip()
	r = re.compile(u'Режиссер:\s*?(.+?)\n\n', re.U|re.S).search(c.text)
	if r: info['director'] = r.group(1).strip().replace('\n',', ')
	r = re.compile(u'Студия:\s*?(.+?)\n\n', re.U|re.S).search(c.text)
	if r: info['studio'] = r.group(1).strip().replace('\n',', ')
	r = re.compile(u'(Тип:\s*?.+?)\n').search(c.text)
	if r: info['tagline'] = r.group(1).strip()
	r = re.compile(u'(Серии:\s*?\d+?) ').search(c.text)
	if r: info['plotoutline'] = r.group(1).strip()
	r = re.compile(u'(Первоисточник:\s*?.+?)\n').search(c.text)
	if r:
		perv = r.group(1).strip()
		info['plot'] = '\n\n'.join([info['plot'], perv])
	r = re.compile(u'(Перевод:\s*?.+?)$').search(c.text)
	if r:
		perevod = r.group(1).strip().replace(u'Озвучка:',u'\nОзвучка:')
		info['plot'] = '\n\n'.join([info['plot'], perevod])
	info['genre'] = ', '.join(c.find('ul', 'categories-list').findAll(text=re.compile('[^\n]')))

	v = p.find('div', 'tabs-content')
	video = {}
	index = 1
	#print p
	for i in v.findAll('div', 'video-block'):
		try:	name = i.find('div', 'video-block-description').text.strip()
		except:	name = u'Плеер'
		video[str(index)] = {'name': name, 'serials': [] }

		videolist = i.findAll('div', 'video-button')
		#print i
		if videolist:
			for j in videolist:
				video[str(index)]['serials'].append( ( j.text.strip() , j['data-href'] ) )
		else: video[str(index)]['serials'].append( ( u'1' , i.find('iframe')['src'] ) )
		video[str(index)]['len'] = str( len(video[str(index)]['serials']) )
		index += 1

	#print video
	#print img, title, info, titlealt
	view_list = None
	s = p.find('div', 'view-list')
	if s:
		t = s.findAll('li')
		number = 1
		view_list =[ (u'[COLOR green]Порядок просмотра:[/COLOR]', 0) ]
		for i in t:
			u = i.find('a')
			if u:
				url_v = n_u(u['href'])
				vt = u'[COLOR pink]' + unicode(number) + u'. ' + i.text + u'[/COLOR]'
			else:
				url_v = 0
				vt = unicode(number) + u'. ' + i.text

			view_list.append( (vt, url_v) )
			number += 1
		#print view_list
	return {'info': info, 'thumb': img, 'alt': titlealt, 'video': video, 'view': view_list}


def pars3(data):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	p = soup.find('div', 'content-page')
	f = p.findAll('div', 'preview-block')
	olist = []
	#i = f[0]
	for i in f:
	#if i:
		info = {}
		img = i.find('a').find('img')['src']
		if '://' not in img: img = site_url + img
		t = i.find('a', 'preview-title')
		url = t['href']
		if '://' not in url: url = site_url + url
		info['title'] = t.text
		info['plot'] =''.join(i.find('div', 'desc').findAll(text=True)).strip()
		info['genre'] = ', '.join(i.find('ul', 'categories-list').findAll(text=re.compile('[^\n]')))
		try:	info['rating'] = float(i.find('span', 'main-rating').text)
		except:	pass
		try:
			votefull = i.find('span', 'main-rating-info').text
			info['votes'] = re.compile(r'(\d+)').findall(votefull)[0]
		except: pass
		try:
			perevod = i.find('li', 'animeVoices').text
			info['plot'] = '\n\n'.join([info['plot'], perevod])
		except: pass

		u = i.find('div', 'update-info')
		if u:
			update = u.text
			info['plotoutline'] = update
		else:	update = None

		m = i.find('ul', 'content-main-info')
		y = m.find('li')
		if y:
			t = y.text.split('|')
			info['year'] = int(t[0].strip())
			info['tagline'] = t[1].strip()
			year = ','.join([t[0].strip(), t[1].strip()])
		tmp = m.findAll(text=True)
		for n , text in enumerate(tmp):
			if u'рейтинг:' in text:
					info['mpaa'] = tmp[n+1].strip()
					break
		olist.append( {'url': url, 'thumb': img, 'year': year,'update': update, 'info': info} )
	return olist

def pars_google(data, quality=_quality_):
	r = re.compile('video:\s+?(\{.+?)\}\);',re.S).search(data)
	s = r.group(1).strip()
	#print s
	google_list = eval(s)
	gl = []
	for i in google_list:
		gl.append((int(i), google_list[i]['src']))
	gl.sort()
	#print gl
	qprev = 0
	for i in gl:
		#print i
		if int(i[0]) > int(quality):
					q = qprev
					break
		qprev = i[0]
		q = i[0]
	#print google_list
	return 	google_list[str(q)]['src']


def pars_sovet(data, quality=_quality_):
	#print data
	r = re.compile('source src="(http.+?)"',re.S).findall(data)
	#print r
	for i in r:
		if '.m3u8' in i: break
		#if '.mp4' in i: return i
	if '.m3u8' in i:
		data = getUrl(i)
		listurl = {}
		url = i[:1+i.rfind('/')]
		for d in data.splitlines():
			if (d[0] == '#') or (d[0] == ''): continue
			if '1080p' in d: listurl['1080'] = url + d
			if '720p' in d: listurl['720'] = url + d
			if '480p' in d: listurl['480'] = url + d
			if '360p' in d: listurl['360'] = url + d
		gl = []
		for i in listurl:
			gl.append((int(i), listurl[i]))
		gl.sort()
		qprev = 0
		for i in gl:
			if int(i[0]) > int(quality):
					q = qprev
					break
			qprev = i[0]
			q = i[0]
		return listurl[str(q)]
	return i

def pars_hdgo(data, quality=_quality_):
	d = data.split('media: [')[-1].split(']')[0]
	d = d.split('},{')
	listurls = {}
	hl = []
	i = len(d)
	index = 0
	if i == 2: index = 1
	for i, item in enumerate(d):
		url = item.split("url: '")[-1].split("'")[0]
		if 'http:' not in url: url = 'http:' + url
		url = url + '|Referer='+url
		hl.append( (Quality[index+i], url) )
		listurls[str(Quality[index+i])] = url
	qprev = 0
	for i in hl:
		if int(i[0]) > int(quality):
					q = qprev
					break
		qprev = i[0]
		q = i[0]
	return listurls[str(q)]

def pars_getvi(data, quality=_quality_):
	r = re.compile('file:\s*?"(.+?)",',re.S).search(data)
	if r:	urls = r.group(1)
	urls = urls.replace('[','').split('/,')
	for i, d in enumerate(urls):
		urls[i] = d.strip('/').split('p]')
	listurl = {}
	for i, d in enumerate(urls):
		listurl[d[0]] = d[1]
		urls[i][0] = int(d[0])
	urls.sort()
	qprev = 0
	for i in urls:
		if int(i[0]) > int(quality):
					q = qprev
					break
		qprev = i[0]
		q = i[0]
	return listurl[str(q)]

def pars_sibnet(data):
	r = re.compile("url:\s*?'(.+?)',",re.S).search(data)
	if r:	url = r.group(1)
	data = getUrl(url)
	r = re.compile('src:\s*?"([^\.]+?\.m3u8)",', re.S).search(data)
	if r:	url = 'https://video.sibnet.ru'+r.group(1)+'|Referer=https://video.sibnet.ru'
	return url

def pars_moonwalk(data, url, quality=_quality_):
		from xbmcup.errors import log
		import xbmc
        	sys.path.append(os.path.join(xbmc.translatePath('special://home/'), 'addons', 'script.module.videohosts', 'lib', 'videohosts'))
        	sys.path.append(os.path.join(xbmc.translatePath('special://home/'), 'addons', 'script.module.xbmc.helpers', 'lib'))
		from moonwalk import get_access_attrs
		values, attrs = get_access_attrs(data, url)
		#print values, attrs
		import urllib, urllib2, json
		USER_AGENT = "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0"
	        headers2 = {}
	        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor())
	        opener.addheaders = [("User-Agent", USER_AGENT)]
	        request = urllib2.Request(attrs["purl"], urllib.urlencode(values), headers2)
	        connection = opener.open(request)
	        response = connection.read()
	        data = json.loads(response.decode('unicode-escape'))
	        playlisturl = data["m3u8"]
		log(data,'data=')
		log(playlisturl,'listurl=')
		PLAYLIST_DOMAIN = 's9.cdnapponline.com'
	        headers2 = {
        	"Host": PLAYLIST_DOMAIN,
	        "Referer": url,
    	       	"Origin": "http://" + PLAYLIST_DOMAIN,
                "User-Agent": USER_AGENT,
                "X-Requested-With": "XMLHttpRequest"
                }
                request = urllib2.Request(playlisturl, "", headers2)
                request.get_method = lambda: 'GET'
                response = urllib2.urlopen(request).read()
		d = response.splitlines()
		log(d,'response=')
		listurls = {}
		for i in range(0, len(d)):
			if (d[i] !='') and (d[i][0] == '#') and ('RESOLUTION=' in d[i]):
				if ('x360' in d[i]) or ('640x' in d[i]): listurls['360'] = d[i+1]
				if ('x480' in d[i]) or ('854x' in d[i]): listurls['480'] = d[i+1]
				if ('x720' in d[i]) or ('1280x' in d[i]): listurls['720'] = d[i+1]
				if ('x1080' in d[i]) or ('1920x' in d[i]): listurls['1080'] = d[i+1]
		log(listurls,'listurls=')
		gl = []
		for i in listurls:
			gl.append((int(i), listurls[i]))
		gl.sort()
		qprev = 0
		for i in gl:
			if int(i[0]) > int(quality):
					q = qprev
					break
			qprev = i[0]
			q = i[0]
		return listurls[str(q)]

def pars_youtubedl(url, quality=_quality_): # -> docs.google.com
	try:
		from YoutubeDLWrapper import YoutubeDLWrapper as YoutubeDL
	except ImportError:
		from youtube_dl import YoutubeDL
	ydl = YoutubeDL()
	info = ydl.extract_info(url, download=False)
	from urllib import urlencode
	listurls = {}
	#print info['formats']
	for i in info['formats']:
		agent = i['http_headers']['User-Agent']
		cookie = i['http_headers']['Cookie']
		url = i['url'] + '|' + urlencode({'User-Agent': agent,'Cookie': cookie})
		if i['format_id'] != u'source': listurls[str(i['height'])] = url
		elif len(info['formats']) == 1: listurls['360'] = url
	#print listurls
	gl = []
	for i in listurls:
		gl.append((int(i), listurls[i]))
	gl.sort()
	qprev = 0
	for i in gl:
		if int(i[0]) > int(quality):
					q = qprev
					break
		qprev = i[0]
		q = i[0]
	return listurls[str(q)]

def pars_youtube(url):
	url = url.split('/')[-1].split('?origin')[0]
	return 'plugin://plugin.video.youtube/play/?video_id='+url


def pars_animedia(data, quality=_quality_):
	r = re.compile('file:\s*?"(.+?)",',re.S).search(data)
	if r:	url = r.group(1)
	url = 'https:'+url
	data = getUrl(url)
	listurl = {}
	d = data.splitlines()
	#print d
	for i in d:
		if (i !='') and (i[0] == '#') and ('RESOLUTION=' in i):
			if ('x360' in i) or ('640x' in i): qu = '360'
			if ('x480' in i) or ('854x' in i): qu = '480'
			if ('x720' in i) or ('1280x' in i): qu = '720'
			if ('x1080' in i) or ('1920x' in i): qu = '1080'
		if (i != '') and (i[0] != '#'):
			#print i
			listurl[qu] = i
	#print listurl
	gl = []
	for i in listurl:
			gl.append((int(i), listurl[i]))
	gl.sort()
	qprev = 0
	for i in gl:
			if int(i[0]) > int(quality):
					q = qprev
					break
			qprev = i[0]
			q = i[0]
	return listurl[str(q)]

def pars_zombie(data, quality=_quality_):
	r = re.compile('hlsList:\s*?(\{.+?\}),',re.S).search(data)
	if r:	listurl = eval(r.group(1))
	#print listurl
	gl = []
	for i in listurl:
			gl.append((int(i), listurl[i]))
	gl.sort()
	qprev = 0
	for i in gl:
			if int(i[0]) > int(quality):
					q = qprev
					break
			qprev = i[0]
			q = i[0]
	from urllib import urlencode
	return listurl[str(q)]+'|'+urlencode({ 'Referer': listurl[str(q)] })


def qurl(url, quality=_quality_):
			urls = url.split(',[')
			listurls = {}
			gl = []
			for i in urls:
				d = i.replace('[','').split('p]')
				listurls[str(d[0])] = d[1]
				gl.append( (int(d[0]), d[1]) )
			#print listurls
			gl.sort()
			#print gl
			qprev = 0
			for i in gl:
				if int(i[0]) > int(quality):
					q = qprev
					break
				qprev = i[0]
				q = i[0]
			url = listurls[str(q)]
			return url

def pars_onvi(data, quality=_quality_):
	r = re.compile(r',\s*?file:\s*?"(.+?)",',re.S).search(data)
	if r:
		url = r.group(1)
		if ',[' in url:
			url = qurl(url)
	from urllib import urlencode
	return url+'|'+urlencode({ 'Referer': url })

def pars_kodik(data, url, quality=_quality_):
	import urlparse
	import json
	r = re.compile(r'iframe.src\s*?=\s*?"(.+?)";',re.S).search(data)
	if r:
		isrc = r.group(1)
		video_type, video_id, video_hash = isrc.split('/')[4:7]
		params = dict(urlparse.parse_qsl(urlparse.urlsplit(isrc).query))
	data2 = getUrl('https:'+isrc, referer=url)
	#file('/home/osmc/'+isrc.split('/')[2]+'2.txt', 'wb').write( getUrl('https:'+isrc, referer=url) )
	r = re.compile(r'<script type="text/javascript" integrity="[^"]+?" src="([^"]+?)"></script>',re.S).search(data2)
	if r:
		jsurl = r.group(1)
		if '://' not in jsurl: jsurl = 'https://kodik.info'+ jsurl
	#print jsurl
	from xbmcup.net import HTTP
	http = HTTP()
	headers2 = headers
	headers2['Referer'] = 'https://kodik.info'
	#print headers2
	res = http.fetch( jsurl, headers=headers2 )
	#file('/home/osmc/'+isrc.split('/')[2]+'.2js.txt', 'wb').write( res.body )
	r = re.compile(r'hash2:"([^"]+?)"',re.S).search(res.body)
	if r: hash2 = r.group(1)
	#print hash2
	params.update({'type': video_type, 'id': video_id, 'hash': video_hash, 'hash2': hash2, 'bad_user': 'false'})
	#print params
	res = http.fetch('https://kodik.info/video-links', headers=headers2, method='POST', params=params)
	webpage = res.body
	#print res.body
	jsn = json.loads(webpage)
	if 'link' in jsn:
		return jsn['link'] if '://' in jsn['link'] else 'https:' + jsn['link']
	else:
		video_urls = jsn['links']
		listurl = {}
		gl = []
		for (k,v) in video_urls.items():
			purl = re.sub(r'^//', 'https://', v[0]['src'])
			listurl[str(k)] = purl
			gl.append( (int(k), purl) )
		#print listurl
		gl.sort()
		#print gl
		qprev = 0
		for i in gl:
				if int(i[0]) > int(quality):
					q = qprev
					break
				qprev = i[0]
				q = i[0]
		url = listurl[str(q)]
		return url


def catalog(url=None):
	if not url: url = site_url+'/catalog?page=1'
	data = getUrl(url)
	return pars(data)

def genre():
	data = getUrl(site_url+'/catalog')
	return pars(data)['category']

def videoinfo(url):
	data = getUrl(url)
	#file('/home/osmc/'+url.split('/')[2]+'.txt', 'wb').write(data)
	return pars2(data)


def random_anime():
	url, data = getUrl(site_url+'/random', rurl=True)
	return url, pars2(data)


def search(text):
	from urllib import quote_plus
	if isinstance(text, unicode): text = text.encode('utf8')
	return site_url+'/search?word='+quote_plus(text)


def top100(serial=True):
	if serial: return site_url+'/top?sort=serials'
	else: return site_url+'/top?sort=films'

def ongoing():
	data = getUrl(site_url+'/ongoing')
	return pars3(data)

def filter_god(start, end):
    return site_url+'/filter?status=-1&from_num_episodes=&to_num_episodes=&from_year='+str(start)+'&to_year='+str(end)+'&selected_age=0&sort=2&action=list'

def updates():
	data = getUrl(site_url+'/anime-updates')
	#file('/home/osmc/'+site_url.split('/')[2]+'.txt', 'wb').write(data)
	return pars(data)

def play_link(url):
	try:
		from xbmcup.errors import log
		log(url,'url=')
	except: pass
	if (url !=u'') and (url[:4] != u'http') : url = 'https:' + url
	if 'video.sibnet.ru' in url: url = url.replace(':///','://') # патч ошибки на сайте
	elif 'streamguard.cc'in url: # не работает
		return None, ['Выбранный плеер Moonwalk больше не работает.', 'Используйте другой источник видео.']
	elif 'vio.to'in url: # не работает
		return None, ['Выбранный плеер HDGO больше не работает.', 'Используйте другой источник видео.']
	data = getUrl(url)
	if site_url in url:
		return pars_google(data) , None
	elif 'sovetromantica.com' in url:
		return pars_sovet(data) , None
	elif 'vio.to/' in url:
		return pars_hdgo(data), None
	elif 'mediatoday.pro' in url:
		return pars_getvi(data), None
	elif 'video.sibnet.ru' in url:
		return pars_sibnet(data), None
	elif 'streamguard.cc' in url:
		return pars_moonwalk(data, url), None
	elif 'docs.google.com' in url:
		return pars_youtubedl(url), None
	elif 'youtube.com' in url:
		return pars_youtube(url), None
	elif 'animedia.tv' in url:
		return pars_animedia(data), None
	elif 'delivembed.cc' in url:
		return pars_zombie(data), None
	elif 'onvi.cc' in url:
		return pars_onvi(data), None
	elif 'embdvideo.com' in url:
		return pars_onvi(data), None
	elif 'kodik.info' in url:
		return pars_kodik(data, url), None
	#file('/home/osmc/'+url.split('/')[2]+'.txt', 'wb').write(data)
	#file('/home/osmc/'+url.split('/')[2]+'.url.txt', 'wb').write(url)
	return None , ['Выбранный плеер пока не поддерживается дополнением.', 'Кто знает JS и Python помогите добавить получение из плеера прямой ссылки на видеопоток в дополнение.', url]

if __name__ == '__main__':

	data = file('yummyanime.club.txt', 'rb').read()

	print 	pars(data)

	pass


