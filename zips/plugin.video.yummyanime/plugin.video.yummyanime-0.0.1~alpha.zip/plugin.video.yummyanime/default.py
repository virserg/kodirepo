# -*- encoding: utf-8 -*-

import os, sys

import xbmc, xbmcplugin, xbmcgui

from xbmcup.app import Link, Handler, Plugin
import yummy

class Menu(Handler):
	def handle(self):
		self.item(Link('catalog',{'search': True}), title='[Поиск]')
		self.item(Link('ongoing'), title='Онгоинги')
		self.item(Link('catalog'), title='Каталог по алфавиту')
		self.item(Link('genre'), title='Жанры')
		self.item(Link('video'), title='Случайное аниме')
		self.item(Link('catalog',{'top': '1'}), title='ТОП-100 сериалов')
		self.item(Link('catalog',{'top': '0'}), title='ТОП-100 фильмов')

class Ongoing(Handler):
	def handle(self):
		data = yummy.ongoing()
		for i in data:
			title = i['info']['title'] + ' (' + i['year'] + ')'
			self.item(Link('video', {'url': i['url']}), title=title, media='video', info=i['info'], thumb=i['thumb'])


class Catalog(Handler):
	def handle(self):
		search = self.argv.get('search')
		top100 = self.argv.get('top')
		url = self.argv.get('url')
		if search:
			searchurl = self.kbdinput('Поиск')
			if searchurl is None: return True
			url = yummy.search(searchurl)
		elif top100:
			url = yummy.top100(bool(int(top100)))
		data = yummy.catalog(url)
		for i in data['data']:
			title = i['info']['title'] +' (' + i['year'] +',' + i['type'] + ')'
			self.item(Link('video', {'url': i['url']}), title=title, media='video', info=i['info'], thumb=i['thumb'])
		if data['page']['next']:
			titlepage = 'Следующая страница '+ str(data['page']['current']+1)+ ' из ' + str(data['page']['max']) + ' >>'
			self.item(Link('catalog',{'url':data['page']['next']}), title=titlepage)


class Genres(Handler):
	def handle(self):
		data = yummy.genre()
		for n, l in data:
			self.item(Link('catalog', {'url': l}), title=n, media='video')


class VideoInfo(Handler):
	def handle(self):
		url = self.argv.get('url')
		if url:
			data = yummy.videoinfo(url)
			rand = u''
		else:
			data =yummy.random_anime()
			rand = u' {Случайное аниме}'
		self.item(Link('test'), title=data['info']['title']+rand, media='video', info=data['info'], thumb=data['thumb'])
		for j in range(1, len(data['video'])+1):
			i = str(j)
			self.item(Link('serials',{'slist': data['video'][i]['serials'], 'thumb': data['thumb']}), title=u'#'+i+u' '+data['video'][i]['name']+u' ('+data['video'][i]['len']+u')', media='video', info=data['info'], thumb=data['thumb'])

class Serials(Handler):
	def handle(self):
		slist = self.argv.get('slist')
		thumb = self.argv.get('thumb')
		info = {}
		for i, l in slist:
			info['title'] = i+ u' Серия'
			self.item(Link('play',{'url': l}), title=info['title'], media='video', info=info, thumb=thumb, property=[('IsPlayable','true')], folder=False)

class Play(Handler):
	def handle(self):
		url = self.argv.get('url')
		link, error = yummy.play_link(url)
		if link:
			#xbmc.Player().play(link)
			item = xbmcgui.ListItem(path=link)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]),True, item)
		else:
			xbmcgui.Dialog().ok('YummyAnime', *error)

def main():
	plugin = Plugin(Menu)
	plugin.route('catalog', Catalog)
	plugin.route('genre', Genres)
	plugin.route('video', VideoInfo)
	plugin.route('serials', Serials)
	plugin.route('play', Play)
	plugin.route('ongoing', Ongoing)
	plugin.run()


if __name__ == '__main__': main()
