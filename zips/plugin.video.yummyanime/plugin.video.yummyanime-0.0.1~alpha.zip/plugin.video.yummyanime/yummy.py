# -*- coding: utf-8 -*-

import re



site_url = 'https://yummyanime.club'

headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
            'Cache-Control': 'no-cache',
            'Referer': site_url
        }

Quality = (360, 480, 720, 1080)

def getUrl(url, referer=None):
	from xbmcup.net import HTTP
	http = HTTP()
	if referer: headers['Referer'] = referer
	response = http.fetch(url, headers=headers, cookies='yummyanime.moz')
	if response.code == 200: return response.body
        else:
		try:
			from xbmcup.errors import message
			message('Ошибка '+str(response.code)+' HTTP:', response.error)
		except: pass
		return response.code


def pars(data):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	category_list = []
	c = soup.findAll('ul', 'category-list')
	for i in c:
		t = i.findAll('a')
		for j in t:
			category_list.append( (j.text, site_url + j['href']) )

	page = {'max': 1, 'current': 1, 'next': None, 'prev': None}
	p = soup.find('ul', 'pagination')
	try:
		page['current'] = int(p('li', 'active')[0].span.text)
		page['max'] = int(p('a')[-2].text)
	except: pass
	try:page['next'] = site_url + p('a' , rel='next')[0]['href']
	except: pass
	try: page['prev'] = site_url + p('a' , rel='prev')[0]['href']
	except: pass

	data_list = []
	d = soup.findAll('div', 'anime-column')
	for i in d:
		info = {}
		title = i.find('a', 'anime-title').text
		info['title'] = title
		type = i.find('p').text
		try:	info['rating'] = float(i.find('span', 'main-rating').text)
		except:	pass
		try:
			votefull = i.find('span', 'main-rating-info').text
			info['votes'] = re.compile(r'(\d+)').findall(votefull)[0]
		except: pass
		t = i('a', 'image-block')[0]
		url = t['href']
		if '://' not in url: url = site_url + url
        	img = t('img')[0]['src']
		if '://' not in img: img = site_url + img
		try:	year = t.text.strip().replace('\n',',')
		except: pass
		try: 	info['year'] = int(re.compile(r'(\d+)').findall(year)[0])
		except:	pass
		data_list.append({'url': url, 'type': type, 'thumb': img, 'info': info, 'year': year})
		#print url, title, type, info['year']

	return {'category': category_list, 'page': page, 'data': data_list}


def pars2(data):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	p = soup.find('div', 'content-page')
	info = {}
	img = p.find('div', 'poster-block')('img')[0]['src']
	if '://' not in img: img = site_url + img
	title = p.find('h1').text.strip()
	info['title'] = title
	try:	info['rating'] = float(p.find('span', 'main-rating').text)
	except:	pass
	try:
		votefull = p.find('span', 'main-rating-info').text
		info['votes'] = re.compile(r'(\d+)').findall(votefull)[0]
	except: pass
	titlealt = [i.text for i in p.find('ul').findAll('li') if i]
	info['originaltitle'] = titlealt[-1]
	info['plot'] =''.join(p.find('div', 'content-desc').findAll(text=True)).strip()
	c = p.find('ul', 'content-main-info')
	try:	year = c.findAll('li')[2].text
	except: pass
	try:	info['year'] = int(re.compile(r'(\d+)').findall(year)[0])
	except:	pass
	#print c.text
	r = re.compile(u'(Просмотров:\s*?[ \d]+?)\n').search(c.text)
	if r: info['writer'] = r.group(1).strip()
	r = re.compile(u'Возрастной рейтинг:\s*?(.+?)\n').search(c.text)
	if r:	info['mpaa'] = r.group(1).strip()
	r = re.compile(u'Статус:\s*?(.+?)\n').search(c.text)
	if r: info['status'] = r.group(1).strip()
	r = re.compile(u'Режиссер:\s*?(.+?)\n\n', re.U|re.S).search(c.text)
	if r: info['director'] = r.group(1).strip().replace('\n',', ')
	r = re.compile(u'Студия:\s*?(.+?)\n\n', re.U|re.S).search(c.text)
	if r: info['studio'] = r.group(1).strip().replace('\n',', ')
	r = re.compile(u'(Тип:\s*?.+?)\n').search(c.text)
	if r: info['tagline'] = r.group(1).strip()
	r = re.compile(u'(Первоисточник:\s*?.+?)\n').search(c.text)
	if r:
		perv = r.group(1).strip()
		info['plot'] = '\n\n'.join([info['plot'], perv])
	r = re.compile(u'(Перевод:\s*?.+?)$').search(c.text)
	if r:
		perevod = r.group(1).strip().replace(u'Озвучка:',u'\nОзвучка:')
		info['plot'] = '\n\n'.join([info['plot'], perevod])
	info['genre'] = ', '.join(c.find('ul', 'categories-list').findAll(text=re.compile('[^\n]')))

	v = p.find('div', 'tabs-content')
	video = {}
	index = 1
	for i in v.findAll('div', 'video-block'):
		try:	name = i.find('div', 'video-block-description').text.strip()
		except:	name = u'Плеер'
		video[str(index)] = {'name': name, 'serials': [] }

		for j in i.findAll('div', 'video-button'):
			video[str(index)]['serials'].append( ( j.text.strip() , j['data-href'] ) )
		video[str(index)]['len'] = str( len(video[str(index)]['serials']) )
		index += 1

	#print video
	#print img, title, info, titlealt
	return {'info': info, 'thumb': img, 'alt': titlealt, 'video': video}


def pars3(data):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	p = soup.find('div', 'content-page')
	f = p.findAll('div', 'preview-block')
	olist = []
	#i = f[0]
	for i in f:
	#if i:
		info = {}
		img = i.find('a').find('img')['src']
		if '://' not in img: img = site_url + img
		t = i.find('a', 'preview-title')
		url = t['href']
		if '://' not in url: url = site_url + url
		info['title'] = t.text
		info['plot'] =''.join(i.find('div', 'desc').findAll(text=True)).strip()
		info['genre'] = ', '.join(i.find('ul', 'categories-list').findAll(text=re.compile('[^\n]')))
		try:	info['rating'] = float(i.find('span', 'main-rating').text)
		except:	pass
		try:
			votefull = i.find('span', 'main-rating-info').text
			info['votes'] = re.compile(r'(\d+)').findall(votefull)[0]
		except: pass
		try:
			perevod = i.find('li', 'animeVoices').text
			info['plot'] = '\n\n'.join([info['plot'], perevod])
		except: pass

		u = i.find('div', 'update-info')
		if u:
			update = u.text
			info['plotoutline'] = update
		else:	update = None

		m = i.find('ul', 'content-main-info')
		y = m.find('li')
		if y:
			t = y.text.split('|')
			info['year'] = int(t[0].strip())
			info['tagline'] = t[1].strip()
			year = ','.join([t[0].strip(), t[1].strip()])
		tmp = m.findAll(text=True)
		for n , text in enumerate(tmp):
			if u'рейтинг:' in text:
					info['mpaa'] = tmp[n+1].strip()
					break
		olist.append( {'url': url, 'thumb': img, 'year': year,'update': update, 'info': info} )
	return olist

def pars_google(data, quality='720'):
	r = re.compile('video:\s+?(\{.+?)\}\);',re.S).search(data)
	s = r.group(1).strip()
	#print s
	google_list = eval(s)
	gl = []
	for i in google_list:
		gl.append((int(i), google_list[i]['src']))
	#gl.append((1080, 'https'))
	#gl.append((480, 'https++'))
	gl.sort()
	#print gl
	qprev = 0
	for i in gl:
		#print i
		if int(i[0]) > int(quality):
					q = qprev
					break
		qprev = i[0]
		q = i[0]
	return 	google_list[str(q)]['src']


def pars_sovet(data):
	#print data
	r = re.compile('source src="(.+?)"',re.S).findall(data)
	for i in r:
		if '.mp4' in i: return i
	return i

def pars_hdgo(data):
	d = data.split('media: [')[-1].split(']')[0]
	d = d.split('},{')
	for i, item in enumerate(d):
		url = item.split("url: '")[-1].split("'")[0]
		if 'http:' not in url: url = 'http:' + url
		url = url + '|Referer='+url
		#print url
	return url

def catalog(url=None):
	if not url: url = site_url+'/catalog?page=1'
	data = getUrl(url)
	return pars(data)

def genre():
	data = getUrl(site_url+'/catalog')
	return pars(data)['category']

def videoinfo(url):
	data = getUrl(url)
	return pars2(data)


def random_anime():
	return videoinfo(site_url+'/random')


def search(text):
	from urllib import quote_plus
	return site_url+'/search?word='+quote_plus(text)


def top100(serial=True):
	if serial: return site_url+'/top?sort=serials'
	else: return site_url+'/top?sort=films'

def ongoing():
	data = getUrl(site_url+'/ongoing')
	return pars3(data)

def play_link(url):
	data = getUrl(url)
	if site_url in url:
		return pars_google(data) , None
	elif 'sovetromantica.com' in url:
		return pars_sovet(data) , None
	elif 'vio.to/' in url:
		return pars_hdgo(data), None
	return None , ['Выбранный плеер пока не поддерживается дополнением.', url]

if __name__ == '__main__':

	#file('anime.txt','wb').write(getUrl(site_url+'/catalog/item/5-santimetrov-v-sekundu'))

	#data = file('anime.txt', 'rb').read()

	#file('anime2.txt','wb').write(getUrl(site_url+'/catalog/item/12-let'))

	#data = file('anime2.txt', 'rb').read()

	#pars2(data)
	#print(pars2(data))
	#print catalog()
	#print catalog(site_url+'/catalog?page=2')
	#print(videoinfo(site_url+'/catalog/item/5-santimetrov-v-sekundu'))


	#url = pars2(data)['video']['1']['serials'][0][1]
	#print url
	#print play_link(url)
	#file('moonwalkanime.txt', 'wb').write(getUrl(url))
	#file('gogleanime.txt', 'wb').write(getUrl(url))

	#data = file('gogleanime.txt', 'rb').read()
	#print data
	#print pars_google(data)

	#print Quality
	#print random_anime()
	#print genre()
	#print catalog(search('астра')

	#print getUrl(site_url+'/ongoing')
	#file('anime3.txt','wb').write(getUrl(site_url+'/ongoing'))

	#data = file('anime3.txt', 'rb').read()

	#pars3(data)

	#print ongoing()

	#print videoinfo(catalog(search('астра'))['data'][1]['url'])['video']['1']['serials'][0][1]
	#file('sovietanime.txt', 'wb').write(getUrl(videoinfo(catalog(search('астра'))['data'][1]['url'])['video']['1']['serials'][0][1]))

	#data = file('sovietanime.txt', 'rb').read()

	#print pars_sovet(data)


	#file('hdgoanime.txt', 'wb').write(getUrl( videoinfo(catalog(search('бейблэйд'))['data'][0]['url'])['video']['1']['serials'][0][1] ))

	#data = file('hdgoanime.txt', 'rb').read()
	#pars_hdgo(data)
	
	pass

