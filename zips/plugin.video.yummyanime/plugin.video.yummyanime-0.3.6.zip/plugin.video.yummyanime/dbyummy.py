# -*- coding: utf-8 -*-

import os
import sys
import time

try:
    from sqlite3 import dbapi2 as sqlite
except:
    from pysqlite2 import dbapi2 as sqlite


class YummyDB:
    def __init__(self, filename):
        self.filename = filename

        if not os.path.exists(self.filename):
            self._connect()
            self.cur.execute('pragma auto_vacuum=1')
            self.cur.execute('create table yummylist(addtime integer, year varchar(4), name varchar(255), url varchar(255), poster varchar(255), type varchar(255), sname varchar(255))')
            self.cur.execute('create index time on yummylist(addtime desc)')
            self.db.commit()
            self._close()

    def getall(self):
        self._connect()
        self.cur.execute('select year,name,url,poster,type from yummylist order by addtime asc')
	res = [{'year':x[0], 'name': x[1], 'url': x[2], 'poster': x[3], 'type': x[4]} for x in self.cur.fetchall()]
        self._close()
        return res

    def getyears(self, yearstart, yearend):
        self._connect()
        self.cur.execute('select year,name,url,poster,type from yummylist where year>=? and year<=? order by year asc',(yearstart, yearend,))
	res = [{'year':x[0], 'name': x[1], 'url': x[2], 'poster': x[3], 'type': x[4]} for x in self.cur.fetchall()]
        self._close()
        return res

    def geturl(self, url):
        self._connect()
        self.cur.execute('select year,name,url,poster,type from yummylist where url=?',(url,))
	res = [{'year':x[0], 'name': x[1], 'url': x[2], 'poster': x[3], 'type': x[4]} for x in self.cur.fetchall()]
        self._close()
        return res

    def search(self, name):
	self._connect()
        self.cur.execute('select year,name,url,poster,type from yummylist where sname LIKE ?',('%'+name+'%', ))
	res = [{'year':x[0], 'name': x[1], 'url': x[2], 'poster': x[3], 'type': x[4]} for x in self.cur.fetchall()]
	self._close()
	return res

    def add(self, url, name='' , year='', poster='', typec=''):
	sname = name.lower()
        self.delete(url, name)
        self._connect()
        self.cur.execute('insert into yummylist(addtime,year,name,url,poster,type,sname) values(?,?,?,?,?,?,?)', (int(time.time()), year, name, url, poster, typec, sname))
        self.db.commit()
        self._close()

    def delete(self, url, name=''):
        self._connect()
        self.cur.execute('delete from yummylist where url=? and name=?', (url, name))
        self.db.commit()
        self._close()

    def _connect(self):
        self.db = sqlite.connect(self.filename)
        self.cur = self.db.cursor()

    def _close(self):
        self.cur.close()
        self.db.close()




if __name__ == '__main__':
#	d = YummyDB(os.path.join(os.path.dirname(__file__),'2anime.db'))

	db = YummyDB(os.path.join(os.path.dirname(__file__),'anime.db'))
#	db = YummyDB(os.path.join(os.path.dirname(__file__),'yummytest.db'))
#	db.add('/dddd/', 'test')
#	db.add('/dd12/', 'test2')
#	db.add('/yyyy/', u'Тест')
	print db.search(u'ящик')
	print
	print db.getyears('1950', '1970')
	print
	print db.geturl('https://yummyanime.club/catalog/item/transformery-viktori')
#	db.delete('/dddd/', 'test')


#	for i in db.getall():
#		d.add(i['url'], i['name'], i['year'], i['poster'], i['type'])

