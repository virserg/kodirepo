# -*- coding: utf-8 -*-
import xbmc
import os, sys
from pprint import pformat
from platform import uname
import inspect, traceback

__id_plugin__ = sys.argv[0].replace('plugin://','').replace('/','')
__plugin_name__ = xbmc.getInfoLabel('System.AddonTitle(%s)' % __id_plugin__).decode('utf8')
__plugin_version__ = xbmc.getInfoLabel('System.AddonVersion(%s)' % __id_plugin__).decode('utf8')

def _decode(s):
    try:
	return s.decode('utf8')
    except:
	return s

def _format_vars(variables):
    """
    Format variables dictionary

    :param variables: variables dict
    :type variables: dict
    :return: formatted string with sorted ``var = val`` pairs
    :rtype: str
    """
    var_list = [(var, val) for var, val in variables.iteritems()]
    lines = []
    for var, val in sorted(var_list, key=lambda i: i[0]):
        if not (var.startswith('__') or var.endswith('__')):
            lines.append('{0} = {1}'.format(var, pformat(val)))
    return '\n'.join(lines)

def message(title, msg, times=5000, icon=None):
	if isinstance(title, unicode):
            title = title.encode('utf8')
        if isinstance(msg, unicode):
            msg = msg.encode('utf8')
        if icon and isinstance(icon, unicode):
            icon = icon.encode('utf8')
        try:
            xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (title, msg, times, icon))
        except Exception, e:
            xbmc.log('Message: ' + str(e), xbmc.LOGERROR)


def log(e, msgerror=None, logger=None):
    #def logger(s):
	#print(s)
    if isinstance(e, BaseException):
	if logger is None:
		logger = lambda msg: xbmc.log(msg.encode('utf8'), xbmc.LOGERROR)
        frame_info = inspect.trace(5)[-1]
        logger('Unhandled exception detected!')
        logger('*** Start diagnostic info ***')
	logger(u'Plugin name: {0}'.format(__plugin_name__))
	logger(u'Plugin version: {0}'.format(__plugin_version__))
        logger('System info: {0}'.format(uname()))
        logger(u'OS info: {0}'.format(xbmc.getInfoLabel('System.OSVersionInfo').decode('utf8')))
        logger('Kodi version: {0}'.format(xbmc.getInfoLabel('System.BuildVersion')))
        logger('File: {0}'.format(frame_info[1]))
        context = ''
        if frame_info[4] is not None:
            for i, line in enumerate(frame_info[4], frame_info[2] - frame_info[5]):
                if i == frame_info[2]:
                    context += '{0}:>{1}'.format(str(i).rjust(5), line)
                else:
                    context += '{0}: {1}'.format(str(i).rjust(5), line)
        logger(u'Code context:\n' + context.decode('utf8'))
        logger('Global variables:\n' + _format_vars(frame_info[0].f_globals))
        logger('Local variables:\n' + _format_vars(frame_info[0].f_locals))
        logger('**** End diagnostic info ****')
	logger('**** Start traceback info ****')
	exc_type, exc_val, exc_tb = sys.exc_info()
	lines = traceback.format_exception(exc_type, exc_val, exc_tb, limit=30)
	for line in lines:
			logger(u'{0}'.format(line.decode('utf8')))
	logger('**** End traceback info ****')
        if msgerror:
		logger(_decode(msgerror))
		message(_decode(msgerror), str(e))
	else:
		raise
    else:
	if msgerror is None: msgerror = ''
	if logger:
		logger(u'{0}:{1} {2}'.format(__plugin_name__, _decode(msgerror), _decode(e)))
	else:
		try:
			xbmc.log(u'{0}:{1} {2}'.format(__plugin_name__, _decode(msgerror), _decode(e)).encode('utf8'))
		except:
			xbmc.log(u'{0}:{1} {2}'.format(__plugin_name__, _decode(msgerror), pformat(e)).encode('utf8'))

