#!/usr/bin/python
# -*- coding: utf-8 -*-
#
#   Writer (c) 23/06/2011, Khrysev D.A., E-mail: x86demon@gmail.com
#
#   This Program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2, or (at your option)
#   any later version.
#
#   This Program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; see the file COPYING.  If not, write to
#   the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#   http://www.gnu.org/licenses/gpl.html

import urllib
import urllib2
import re
import sys
import os
import cookielib
import time

import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmc

from BeautifulSoup import BeautifulSoup, BeautifulStoneSoup
import socket

from errors import log as _log
from html import Clear

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36'

socket.setdefaulttimeout(50)

icon = xbmc.translatePath(os.path.join(os.getcwd().replace(';', ''), 'icon.png'))

__settings__ = xbmcaddon.Addon(id='plugin.video.kino-live.org')
__addondir__ = xbmc.translatePath(__settings__.getAddonInfo('profile'))
__proxy__ = int(__settings__.getSetting('Proxy'))
__proxy_host__ = __settings__.getSetting('Proxy_host')
__proxy_port__ = __settings__.getSetting('Proxy_port')
__socks_host__ = __settings__.getSetting('Socks_host')
__socks_port__ = __settings__.getSetting('Socks_port')
__get_domain__ = bool(__settings__.getSetting('Get_domain') == 'true')
__view_yqr__ = bool(__settings__.getSetting('View_YQR') == 'true')

if not os.path.exists(__addondir__):
    os.mkdir(__addondir__)
cookiepath = os.path.join(__addondir__, 'plugin.video.kino-live.org.lwp')

h = int(sys.argv[1])

xbmcplugin.setContent(h, 'movies')
# siteUrl = 'kino-live1.life'
#siteUrl = 'kino-live2.xyz'
siteUrl = __settings__.getSetting("Site_Url").replace(' ','')
httpSiteUrl = 'http://' + siteUrl


def construct_request(params):
    return '%s?%s' % (sys.argv[0], urllib.urlencode(params))


def htmlEntitiesDecode(string):
    return BeautifulStoneSoup(string, convertEntities=BeautifulStoneSoup.HTML_ENTITIES).contents[0]


def showMessage(heading, message, times=3000):
    xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, icon))


headers = {
    'User-Agent': 'Opera/9.80 (X11; Linux i686; U; ru) Presto/2.7.62 Version/11.00',
    'Accept': ' text/html, application/xml, application/xhtml+xml, image/png, image/jpeg, image/gif, image/x-xbitmap, */*',
    'Accept-Language': 'ru-RU,ru;q=0.9,en;q=0.8',
    'Accept-Charset': 'utf-8, utf-16, *;q=0.1',
    'Accept-Encoding': 'identity, *;q=0'
}


def GetProxyList():
	import httplib
	conn = httplib.HTTPConnection("antizapret.prostovpn.org")
	conn.request("GET", "/proxy.pac", headers={"User-Agent": 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)'})
	r1 = conn.getresponse()
	data = r1.read()
	conn.close()
	proxylist = re.compile('PROXY (.+?); DIRECT').findall(data)
	return proxylist


def proxy_update():
	proxy=GetProxyList()[0]
	__settings__.setSetting("proxy_serv", proxy)
	__settings__.setSetting("proxy_time", str(time.time()))



def GET(url, referer, post_params=None, rurl=False):
    headers['Referer'] = referer

    if post_params is not None:
        post_params = urllib.urlencode(post_params)
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
    elif headers.has_key('Content-Type'):
        del headers['Content-Type']

    jar = cookielib.LWPCookieJar(cookiepath)
    if os.path.isfile(cookiepath):
        jar.load()

    build = []
    if __proxy__ == 1:
			try:pt=float(__settings__.getSetting("proxy_time"))
			except:pt=0
			if time.time()-pt > 36000: proxy_update()
			proxy1=__settings__.getSetting("proxy_serv")
			build.append(urllib2.ProxyHandler({'http': proxy1}))
    elif (__proxy__ == 2) and __proxy_host__ and __proxy_port__: build.append(urllib2.ProxyHandler({'http': str(__proxy_host__) + ':' + str(__proxy_port__)}))
    elif (__proxy__ == 3) and __socks_host__ and __socks_port__:
		import socks
		from sockshandler import SocksiPyHandler
		build.append(SocksiPyHandler(socks.PROXY_TYPE_SOCKS5, str(__socks_host__), int(__socks_port__)))
    build.append(urllib2.HTTPCookieProcessor(jar))
    opener = urllib2.build_opener(*build)
    urllib2.install_opener(opener)
    req = urllib2.Request(url, post_params, headers)

    response = opener.open(req)
    if rurl: return response.geturl()
    the_page = response.read()
    response.close()

    jar.save()

    return the_page

if __get_domain__:
	try:pt=float(__settings__.getSetting('domain_time'))
	except:pt=0
	if time.time()-pt > 86400:
		__settings__.setSetting('domain_time', str(time.time()))
		httpSiteUrl2 = GET('http://kino-live.org'.replace('e','e1'), '', rurl=True)
		if httpSiteUrl != httpSiteUrl2:
			httpSiteUrl = httpSiteUrl2
			__settings__.setSetting('Site_Url', httpSiteUrl2.split('/')[2])

def logout(params):
    GET(httpSiteUrl + '/index.php?action=logout', httpSiteUrl)
    __settings__.setSetting("Login", "")
    __settings__.setSetting("Password", "")


def check_login():
    login = __settings__.getSetting("Login")
    password = __settings__.getSetting("Password")

    if len(login) > 0:
        http = GET(httpSiteUrl, httpSiteUrl)
        if http is None:
            return None

        beautifulSoup = BeautifulSoup(http)
        userPanel = beautifulSoup.find('a', {"id": "loginlink"})

        if userPanel is None:
            os.remove(cookiepath)

            loginResponse = GET(httpSiteUrl, httpSiteUrl, {
                'login': 'submit',
                'login_name': login,
                'login_password': password,
                'submit': 'Вход'
            })

            loginSoup = BeautifulSoup(loginResponse)
            userPanel = loginSoup.find('a', {"id": "loginlink"})
            if userPanel is None:
                showMessage('Login', 'Check login and password', 3000)
            else:
                return userPanel.text.encode('utf-8', 'cp1251')
        else:
            return userPanel.text.encode('utf-8', 'cp1251')
    return None


def setviewmode():
	n = int(__settings__.getSetting("View"))
	if n>0:
		xbmc.sleep(200)
		xbmc.executebuiltin("Container.SetViewMode(0)")
		for i in range(1,n):
			xbmc.executebuiltin("Container.NextViewMode")


def mainScreen(params):
    login = check_login()
    if login is not None:
        li = xbmcgui.ListItem('[Закладки %s]' % login.replace('Привет, ', ''))
        uri = construct_request({
            'href': httpSiteUrl + '/favorites/',
            'mode': 'readCategory'
        })
        xbmcplugin.addDirectoryItem(h, uri, li, True)

    li = xbmcgui.ListItem('[Категории]')
    uri = construct_request({
        'href': httpSiteUrl,
        'mode': 'getCategories'
    })
    xbmcplugin.addDirectoryItem(h, uri, li, True)

    li = xbmcgui.ListItem('[По годам]')
    uri = construct_request({
        'mode': 'getTags'
    })
    xbmcplugin.addDirectoryItem(h, uri, li, True)

    li = xbmcgui.ListItem('[Поиск]')
    uri = construct_request({
        'mode': 'runSearch'
    })
    xbmcplugin.addDirectoryItem(h, uri, li, True)

    readCategory({
        'href': httpSiteUrl + '/lastnews/'
    })


def readCategory(params, postParams=None):
    categoryUrl = urllib.unquote_plus(params['href'])
    http = GET(categoryUrl, httpSiteUrl, postParams)
    if http is None:
        return False
    _log(http,'http=')
    beautifulSoup = BeautifulSoup(http)
    content = beautifulSoup.find('div', attrs={'id': 'dle-content'})
    dataRows = content.findAll('div', 'tezt')

    if len(dataRows) == 0:
        showMessage('ОШИБКА', 'Неверная страница', 3000)
        return False
    else:
        for data in dataRows:
            img = data.find('img')
            cover = None
            if img is not None:
                cover = img['src']
                if cover.find("://") < 0:
                    cover = httpSiteUrl + cover
            titleContainer = data.findPrevious('div', 'ah1')
            if titleContainer is None:
                titleContainer = data.findPrevious('h1')
            href = titleContainer.find('a')
            if href is None:
                titleText = titleContainer.text
            else:
                titleText = href.text
            titleText = titleText.encode('utf-8', 'cp1251')

            link = data.findNextSibling('div', 'more').find('a')
            href = link['href']
            plotEl = data.find('div', id=re.compile('news-id-\d+'))
            itemInfo = []
            for plotItemRow in plotEl.contents:
                try:
                    pl = plotItemRow.encode('utf-8', 'cp1251')
                    if 'colorstart:#' in pl: pass
                    elif '/colorend' in pl: pass
                    else: itemInfo.append(pl)
                except:
                    pass
            plot = Clear().text("\n".join(itemInfo).decode('utf-8'))
            info = {'title': titleText, 'plot': plot}
            genres = re.compile(u'(?:Жанр|Категория):(.+?)\n',re.S).search(plot)
            if genres:
                genres = genres.group(1).strip()
                info['genre'] = genres
	    else:
                try: genres = data.findPrevious('h2').findAll('a')
		except: pass
		if genres:
                      genre2 = u''
                      for i in genres:
                            genre2 += i.text+u', '
		      info['genre'] = genre2[:-2]
            year = re.compile(u'Год.*?:(.+?)\n',re.S).search(plot)
            if year:
                try:
                     year = int(year.group(1).strip().split('-')[-1])
                     info['year'] = year
                except: pass
	    origintitle = re.compile(u'Оригинальное название:(.+?)\n',re.S).search(plot)
	    if origintitle:
                   info['originaltitle'] = origintitle.group(1).strip()
	    duration = re.compile(u'Продолжительность:[ ~\dxх]*?((?:\d+?|\d\d\:\d\d\:\d\d))(?: м|\n)',re.S).search(plot)
	    if duration:
                   duration = duration.group(1).strip()
		   if ':' in duration:
			duration = duration.split(':')
			info['duration'] = (int(duration[0])*60+int(duration[1]))*60
                   else:
		        info['duration'] = int(duration)*60
            titleTextL = titleText
            if __view_yqr__ :
                   if info.get('year'): titleTextL += ' (' + str(info['year']) + ')'
                   r = re.compile(u'Качество:([^\n]+)\n',re.S).search(plot)
                   if r: titleTextL += ' | ' + r.group(1).strip().encode('utf8')
                   r = re.compile(u'(?:imdb|IMDb):[ ]*([\d.]+)',re.S).search(plot)
                   if r:
                         try:
                              titleTextL += ' [' + str(float(r.group(1).strip())).encode('utf8') + ']'
                              info['rating'] = float(r.group(1).strip())
                         except: pass
            li = xbmcgui.ListItem(titleTextL, iconImage=cover, thumbnailImage=cover)
            li.setProperty('IsPlayable', 'false')
            try: li.setArt({'poster': cover})
            except: pass
            li.setInfo(type='video', infoLabels=info)
            uri = construct_request({
                'mode': 'getFiles',
                'cover': cover,
                'title': titleText,
                'href': href
            })
            xbmcplugin.addDirectoryItem(h, uri, li, True)

    # TODO: Find a way to use pager in search results
    if postParams is None:
        try:
            pager = content.find('div', 'pages')
            pages = pager.findAll('a')
            nextPageLink = pages[len(pages) - 1]
            if nextPageLink is not None:
                li = xbmcgui.ListItem('[NEXT PAGE >]')
                li.setProperty('IsPlayable', 'false')
                uri = construct_request({
                    'href': nextPageLink['href'],
                    'mode': 'readCategory'
                })
                xbmcplugin.addDirectoryItem(h, uri, li, True)
        except:
            pass

    xbmcplugin.endOfDirectory(h)
    setviewmode()

def getCategories(params):
    categoryUrl = urllib.unquote_plus(params['href'])
    http = GET(categoryUrl, httpSiteUrl)
    if http is None:
        return False

    _log(http,'http=')
    beautifulSoup = BeautifulSoup(http)
    categoryContainer = beautifulSoup.findAll('ul', 'cats')[-1]
    categories = categoryContainer.findAll('a')
    if len(categories) == 0:
        showMessage('ОШИБКА', 'Неверная страница', 3000)
        return False
    else:
        for link in categories:
            if link is not None:
                title = link.string
                if title is None:
                    title = link.find("h2").string
                href = link['href']
                if href.find("://") < 0:
                    href = httpSiteUrl + href
                li = xbmcgui.ListItem('[%s]' % title)
                li.setProperty('IsPlayable', 'false')
                uri = construct_request({
                    'href': href,
                    'mode': 'readCategory'
                })
                xbmcplugin.addDirectoryItem(h, uri, li, True)

    xbmcplugin.endOfDirectory(h)
    setviewmode()


def getTags(params):
    http = GET(httpSiteUrl + '/tags/', httpSiteUrl)
    if http is None:
        return False

    beautifulSoup = BeautifulSoup(http)
    tagsContainer = beautifulSoup.find('td', 'news')
    tags = tagsContainer.findAll('a')
    if len(tags) == 0:
        showMessage('ОШИБКА', 'Неверная страница', 3000)
        return False
    else:
        tags.reverse()
        for link in tags:
            if link is not None:
                title = link.string
                href = link['href']
                if href.find("://") < 0:
                    href = httpSiteUrl + href
                li = xbmcgui.ListItem('[%s]' % title)
                li.setProperty('IsPlayable', 'false')
                uri = construct_request({
                    'href': href,
                    'mode': 'readCategory'
                })
                xbmcplugin.addDirectoryItem(h, uri, li, True)

    xbmcplugin.endOfDirectory(h)
    setviewmode()


def getFiles(params):
    folderUrl = urllib.unquote_plus(params['href'])
    cover = urllib.unquote_plus(params['cover'])
    itemName = urllib.unquote_plus(params['title'])

    http = GET(folderUrl, httpSiteUrl)
    if http is None:
        return False

    _log(http,'http=')
    playListRegexp = re.compile('(?:\?file|pl)=([^"]+)', re.IGNORECASE + re.DOTALL + re.MULTILINE)
    playlist = playListRegexp.findall(http)
    _log(playlist,'playlistAfterRegex=')

    if (len(playlist) > 0) and ('.txt' in playlist[0]):
        _log(playlist,'ifcase ok')
        streamtypeRegexp = re.compile('/player/\s*([^"]+)/', re.IGNORECASE + re.DOTALL + re.MULTILINE)
        commentRegexp = re.compile('"comment":"\s*([^"]+)', re.IGNORECASE + re.DOTALL + re.MULTILINE)
        glavRegexp = re.compile('"comment":"\s*([^"]+)","playlist"', re.IGNORECASE + re.DOTALL + re.MULTILINE)
        fileRegexp = re.compile('"file":"\s*([^"]+)', re.IGNORECASE + re.DOTALL + re.MULTILINE)
        streamTypeinFilePathRegexp = re.compile('{\s*([^"]+)}', re.IGNORECASE + re.DOTALL + re.MULTILINE)
        
        streamTypeInFilestreamTypeinFilePathRegexpFound = streamTypeinFilePathRegexp.findall(playlist[0])
        if (len(streamTypeInFilestreamTypeinFilePathRegexpFound) > 0):
            playlist[0]=playlist[0].replace('{'+streamTypeInFilestreamTypeinFilePathRegexpFound[0]+'}', 'ms4')
        _log(httpSiteUrl + playlist[0],'before get:')
        playlistJson = GET(httpSiteUrl + playlist[0], folderUrl)
        _log(httpSiteUrl + playlist[0],'after get:')
        _log(playlistJson,'playlistJson=')
        comments = commentRegexp.findall(playlistJson)
        files = fileRegexp.findall(playlistJson)
        streamTypeFound= streamtypeRegexp.findall(playlist[0])
        if (len(streamTypeFound) > 0) and (len(files) > 0):
            _log(streamTypeFound[0],'streamTypeFound=')
            iFile = 0
            for tempFile in files:
                streamTypeInFilestreamTypeinFilePathRegexpFound = streamTypeinFilePathRegexp.findall(files[iFile])
                if (len(streamTypeInFilestreamTypeinFilePathRegexpFound) > 0):
                    _log(streamTypeInFilestreamTypeinFilePathRegexpFound[0],'streamTypeInFileNameFound=')
                    files[iFile]=files[iFile].replace('{'+streamTypeInFilestreamTypeinFilePathRegexpFound[0]+'}', streamTypeFound[0])
                    _log(files[iFile],'streamTypeInFileNameReplaced=')
                else:
                    _log(streamTypeInFilestreamTypeinFilePathRegexpFound,'streamTypeInFileName_Not_Found=')
                iFile +=1
	glav = glavRegexp.findall(playlistJson)
	_log(glav,'glav=')
        i = 0
	j = 0
        for comment in comments:
	  if comment in glav:
            title = itemName + ' - ' + comment
            li = xbmcgui.ListItem('[COLOR green]'+comment+'[/COLOR]', iconImage=cover, thumbnailImage=cover)
            li.setProperty('IsPlayable', 'false')
            li.setInfo(type='video', infoLabels={'title': title})
            try:
                uri = construct_request({
                    'mode': 'None',
		    'file' : str(j)
                })
                xbmcplugin.addDirectoryItem(h, uri, li)
            except:
                pass
	    j += 1
	  else:
            title = itemName + ' - ' + comment
            li = xbmcgui.ListItem(comment, iconImage=cover, thumbnailImage=cover)
            li.setProperty('IsPlayable', 'true')
            try: li.setArt({'poster': cover})
            except: pass
            li.setInfo(type='video', infoLabels={'title': title})
            try:
                uri = construct_request({
                    'mode': 'play',
                    'file': files[i],
                    'referer': folderUrl,
                    'cover': cover,
                    'title': title
                })
                xbmcplugin.addDirectoryItem(h, uri, li)
            except:
                pass
            i += 1
        xbmcplugin.endOfDirectory(h)
    	setviewmode()
    else:
        fileRegexp = re.compile('file=([^"]+)', re.IGNORECASE + re.DOTALL + re.MULTILINE)
        files = fileRegexp.findall(http)

	_log(files[0])
        for k, v in (('v2', 'fhd'), ('v3','mhd'), ('v4','m1'), ('v5', 'ms4')):
                  files[0] = files[0].replace('{'+k+'}', v)
	_log(files[0])
	if not files[0].startswith('http'): files[0] = 'x|t|t|p://21|2;1|13;3|8;10|0/x|l|s/'.replace(';','.').replace('|','').replace('x','h') + files[0]
        li = xbmcgui.ListItem(itemName, iconImage=cover, thumbnailImage=cover)
        li.setProperty('IsPlayable', 'true')
        li.setInfo(type='video', infoLabels={'title': itemName})
        xbmc.Player().play(files[0] + '|User-agent=' + USER_AGENT, li)


def runSearch(params):
    skbd = xbmc.Keyboard()
    skbd.setHeading('Что ищем?')
    skbd.doModal()
    if skbd.isConfirmed():
        SearchStr = skbd.getText()
        params = {
            'href': httpSiteUrl
        }
        postParams = {
            'do': 'search',
            'subaction': 'search',
            'story': SearchStr.decode('utf-8').encode('cp1251')
        }
        return readCategory(params, postParams)


def usearch(params):
    if params['keyword']:
        SearchStr = urllib.unquote_plus(params['keyword'])
        params = {
            'href': httpSiteUrl
        }
        postParams = {
            'do': 'search',
            'subaction': 'search',
            'story': SearchStr.decode('utf-8').encode('cp1251')
        }
        return readCategory(params, postParams)


def play(params):
    referer = urllib.unquote_plus(params['referer'])
    file = urllib.unquote_plus(params['file'])
    cover = urllib.unquote_plus(params['cover'])
    title = urllib.unquote_plus(params['title'])
    headers['Referer'] = referer

    _log(file)
    li = xbmcgui.ListItem(path=file + '|User-agent=' + USER_AGENT, iconImage=cover, thumbnailImage=cover, label=title)
    li.setInfo(type='video', infoLabels={'title': title})
    xbmcplugin.setResolvedUrl(h, True, li)


def getFile(files):
    files = files.split(' or ')
    file = files[0]
    if len(files) == 2:
        fileTest = urllib.urlopen(files[1])
        fileUrl = fileTest.geturl()
        if fileUrl:
            file = fileUrl
    return file


def get_params(paramstring):
    param = []
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param


params = get_params(sys.argv[2])

mode = None
func = None


try:
    mode = urllib.unquote_plus(params['mode'])
except:
    if 'usearch' in params: usearch(params)
    else:
	try:
		mainScreen(params)
	except BaseException as e:
		_log(e)

if (mode is not None):
    try:
        func = globals()[mode]
    except:
        pass
    if func:
	try:
		func(params)
	except BaseException as e:
		_log(e)
