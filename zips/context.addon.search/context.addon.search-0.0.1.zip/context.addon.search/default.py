# -*- coding: utf-8 -*-
# Licence: GPL v.3: http://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import sys, os
import re
import urllib

import xbmc
import xbmcaddon
import xbmcgui

from totam import getKodiInfo
from findvideo import find_video
from errors import log


ADDON = xbmcaddon.Addon()

PATTERNS_FOR_DELETE = ADDON.getSetting('patterns_delete') if ADDON.getSetting('patterns_delete') else "[(].+?[)],[[][^\[\]]+?[]],[[].+?[]],SE\d\dEP\d\d[ |]+?,[|]"


def get_iddb():
    iddb = xbmc.getInfoLabel("ListItem.DBID")
    return iddb if iddb and (iddb != "-1") else ""


def get_id():
    iddb = get_iddb()
    id = xbmc.getInfoLabel("ListItem.Property(id)")
    return iddb if iddb else id


def decode_(s):
    try:
        return s.decode('utf-8')
    except:
        return s


def get_year(title):
    pattern = r"([12][90]\d\d)"
    match = re.compile(pattern).search(title)
    year = match.group(1) if match else ""
    return year if year != "1080" else ""

def clear_title(title, year=None):
    if year:
        title = title.split(' (%s' % year)[0].strip()
        title = title.split(' [%s' % year)[0].strip()
        if title.strip() != year: title = title.replace(year,'')
    patterns = PATTERNS_FOR_DELETE.split(",") if PATTERNS_FOR_DELETE else []
    for pattern in patterns:
        title = re.compile(decode_(pattern)).sub("", title).strip()
    return title


def main():
    info = getKodiInfo(True)
    label = decode_(xbmc.getInfoLabel("ListItem.Label"))
    year = get_year(label)
    name = info.get('title', label)
    cl_name = clear_title(name, year)
    title = cl_name.split(" / ") #[0].strip()
    find_video(title, info.get('originaltitle'), info.get('year', year), name=name, cl_name=cl_name )


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        log(e)
