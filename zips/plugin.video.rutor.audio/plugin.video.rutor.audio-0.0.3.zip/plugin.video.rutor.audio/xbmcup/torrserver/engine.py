# -*- coding: utf-8 -*-

import sys
import os
import time
import hashlib
import urllib
import urllib2
import threading
import bencode
import json
from config import TORRSERVED_HOST, TORRSERVED_SUBS, TORRSERVED_SAVE
from client import client, touch, MyHandler

try:
    import xbmcplugin
    import xbmc
except:
    class xbmc:
        @staticmethod
        def sleep(t):
            time.sleep(t/1000)

try:
    import xbmcgui
except:
    class xbmcgui:
        class DialogProgress:
            def __init__(self):
                self._is = False

            def create(self, *argvs):
              pass

            def update(self, *argvs):
              pass

            def iscanceled(self):
              return self._is

            def close(self):
              self._is = True




def no_log(s):
   pass


def humanizeSize(size):
        B = u"б"
        KB = u"Кб"
        MB = u"Мб"
        GB = u"Гб"
        TB = u"Тб"
        UNITS = [B, KB, MB, GB, TB]
        HUMANFMT = "%.2f %s"
        HUMANRADIX = 1024.

        for u in UNITS[:-1]:
                if size < HUMANRADIX : return HUMANFMT % (size, u)
                size /= HUMANRADIX

        return HUMANFMT % (size,  UNITS[-1])


class Engine(object):

    def __init__(self, path=None, index=None, data=None, host=None, port=None, subtitles=None, save=None, log=no_log):
        self.log = log
	self.log('---start---')
        self.magneturi = None
        self.hash = None
        self.metainfo = None
        self.filestats = None
        self.fileid = None
        self.files = None
        self.index = None
        self.subtitles = None
        self.findsubtitles = False
        self.save = None

        if index: self.fileid = int(index)
        else: self.fileid = 0
        self.index = self.fileid

        if save is None: self.save = TORRSERVED_SAVE
	else: self.save = save

        if path:
           data = file(path, 'rb').read()

        if data:
           self.metainfo = metainfo = bencode.bdecode(data)
           self.hash = infohash = hashlib.sha1(bencode.bencode(metainfo['info'])).hexdigest()
           tr = [metainfo['announce']]
           if 'announce-list' in metainfo:
                for t in metainfo['announce-list']:
                    tr.append(t.pop())
           params = {
             'dn': metainfo['info']['name'],
             'tr': tr,
           }
           self.magneturi = 'magnet:?xt=urn:btih:{0}&{1}'.format(str(infohash).upper(), urllib.urlencode(params, True))
	   self.log(self.magneturi)
           info = metainfo['info']
           def _decode(s):
               try:
                        return s.decode('utf8','replace')
               except:
                        return s

           if 'files' in info:
                            files = [dict(id=i, fullname=_decode(os.sep.join([info['name'], os.sep.join(x['path'])])), path=x['path'], name=_decode(x['path'][-1]), size=x['length']) for i, x in enumerate(info['files'])]
           else:
                            files = [dict(id=0, fullname=_decode(info['name']), path=[info['name']], name=_decode(info['name']), size=info['length'])]
           self.files = files
           #self.log(self.files)

        if subtitles:
           if subtitles == True:
                self.findsubtitles = True
           elif isinstance(subtitles, list):
                self.subtitles = subtitles
        else:
           self.findsubtitles = TORRSERVED_SUBS

#        try:
#            if xbmc.Player().isPlayingAudio():
#                tind = 0
#                while not xbmc.abortRequested and xbmc.Player().isPlayingAudio() and tind < 7:
#                    xbmc.sleep(1000)
#                    tind = tind + 1
#		xbmc.Player().stop()
#        except: pass

    def gotinfo(self):
        pDialog = xbmcgui.DialogProgress()
        pDialog.create("TorrServer", "Ждём получение информации о раздаче...")
        tInfo = []
        listing = []
        success = False
        i = 0
        while not pDialog.iscanceled() and not success:
            xbmc.sleep(500)
            stat = client("/torrent/play", get_data={"stat": "true", "link": self.magneturi})
	    self.log(stat)
	    self.log(' ')
            if stat is None or len(stat['FileStats']) == 0:
                xbmc.sleep(500)
                i += 1
                m = 0
                s = 0
                if i > 59:
                    m = i / 60
                s = i - (m*60)
                if i > 100:
                    if stat is None:
                        pDialog.update(i, 'Служба Torrserver не отвечает.', ' Проверьте её настройки.')
                    else:
                        pDialog.update(i, 'Информация о [B]{2}[/B] не получена за {0:02d} : {1:02d} с.'.format(m, s, stat.get('Name', u'раздаче').encode('utf8')), 'Видимо это мертвая раздача и отсутствуют пиры.')
                else:
                    pDialog.update(i, 'Пытаемся подключиться к раздаче [B]{0:02d} : {1:02d}[/B] с.'.format(m, s))
                continue
            elif stat and len(stat['FileStats']) > 0:
                tInfo = client("/torrent/stat", post_data={"Hash": stat['Hash']})
                self.log('---')
                self.log(tInfo)
                self.filestats = tInfo['FileStats']
                tsname = tInfo['FileStats'][self.fileid]['Path']
                dname = self.files[self.fileid]['fullname']
                self.log(tsname)
		self.log(dname)
                if dname == tsname: self.log('fileid ok!')
                else:
                    tsid = -1
                    index = 0
                    for i in tInfo['FileStats']:
                         self.log(i)
                         if dname == i['Path']:
                                 tsid = int(i['Id'])
                                 self.log('fileid found!')
                                 break
                         index += 1
                    if tsid >= 0:
                                 self.fileid = tsid
                                 self.index = index
                pDialog.close()
                success = True
        return success

    def makePreloadDialog(self, url, hash=None, fileId=None):

        if hash is None: hash = self.hash
        if fileId is None: fileId = self.fileid

        def preload(url):
            o = urllib2.build_opener(MyHandler())
            o.open(url)
            self.log('--preloaded stop--')

        t = threading.Thread(target=preload, args=(url, ))
        t.start()

        pDialog = xbmcgui.DialogProgress()
        pDialog.create("TorrServer", "Ждём получение информации о раздаче...", "Подключено: {0} | Активных: {1} | Всего: {2}".format(0, 0, 0))
        success = False
        counter = 0
        name = ""
        while not pDialog.iscanceled() and not success:
            if pDialog.iscanceled():
                pDialog.close()
                client("/torrent/drop", post_data={"Hash": hash})
                break
            time.sleep(0.5)
            stat = client("/torrent/stat", post_data={"Hash": hash})
	    self.log('--preload start--')
            #self.log(stat)
            if stat is None:
                counter += 1
                if counter < 60:
                    time.sleep(0.5)
                    continue
                else:
                    #notify("Time is over")
                    pDialog.close()
                    break
            else:
                if name == "":
                    if stat['FileStats']:
                        for f in stat['FileStats']:
                            if int(f['Id']) == int(fileId):
                                name = f['Path'][f['Path'].rfind('/')+1:]
                    else:
                         name = stat['Name']
                self.log('--calculate preload--')
                downSpeed = humanizeSize(stat['DownloadSpeed'])
                preloadedBytes = stat['PreloadedBytes']
                preloadSize = stat['PreloadSize']
		self.log(preloadedBytes)
                line2 = "Подключено: {0} | Активных: {1} | Всего: {2}".format(stat['ConnectedSeeders'], stat['ActivePeers'], stat['TotalPeers'])
                line3 = u"D: {0}/сек [{1}/{2}]".format(downSpeed, humanizeSize(preloadedBytes), humanizeSize(preloadSize))
                if preloadSize > 0 and preloadedBytes < preloadSize:
                    prc = preloadedBytes * 100 / preloadSize
                    if prc > 100:
                        prc = 100
                    pDialog.update(prc, name, line2, line3)
                elif preloadedBytes > preloadSize:
                    success = True
                    pDialog.close()
                    break
        #t.join()
        return success

    def loadsubtitles(self):
        if self.findsubtitles and self.filestats:
		self.log('-- loadsubtitles start --')
		success = True
		self.prev_name = ''
		self.rus = ''
		def cfname(name, rus=''):
			if '/' in name: name = name.split('/')[-1]
			if (name == self.prev_name) and (rus == self.rus): name = name[:name.rfind('.')] + u'_2_' + name[name.rfind('.'):]
			self.prev_name = name
			self.rus = rus
			if rus and (rus.lower() not in name.lower()): name = name[:name.rfind('.')] + rus + name[name.rfind('.'):]
			elif rus and (rus.lower() in name.lower()): name = name.replace(rus.lower(), rus).replace(rus.upper(), rus)
			return name
		findfullname = self.filestats[self.index]['Path']
		findname = findfullname
		if '/' in findname:
				findname = findname.split('/')[-1]
		findname = findname[:findname.rfind('.')]
		self.log(findname)
		index = 0
		temp_list = []
		for i in self.filestats:
			name = i['Path']
			if findname in name:
				if index != self.index:
					if '.' in name:
						ext = name.split('.')[-1]
						if ext in ('srt', 'ass', 'ssa', 'smi'):
							fileid = int(i['Id'])
							temp_list.append( (index, fileid, name) )
			index += 1
		self.log(temp_list)
		self.log('---')
		if temp_list !=[]:
			temp_rus = []
			temp_eng = []
			temp_other = []
			for i in temp_list:
				n = i[2].lower()
				if '/rus/' in n:
					if ('.forc' in n) or ('_forc' in n) or ('rus forc' in n):
						temp_rus.insert( 0, (i[0], i[1], cfname(i[2], '.Rus'), i[2] ) )
					else:
						temp_rus.append( (i[0], i[1], cfname(i[2], '.Rus'), i[2] ) )
				elif '/eng/' in n: temp_eng.append( (i[0], i[1], cfname(i[2], '.Eng'), i[2] ) )
				elif ('.rus' in n) or ('_rus' in n):
					if ('.forc' in n) or ('_forc' in n) or ('rus forc' in n):
						temp_rus.insert( 0, (i[0], i[1], cfname(i[2], '.Rus'), i[2] ) )
					else:
						temp_rus.append( (i[0], i[1], cfname(i[2], '.Rus'), i[2] ) )
				elif ('.eng' in n) or ('_eng' in n): temp_eng.append( (i[0], i[1], cfname(i[2], '.Eng'), i[2] ) )
				elif 'rus ' in n:
					if ('.forc' in n) or ('_forc' in n) or ('rus forc' in n):
						temp_rus.insert( 0, (i[0], i[1], cfname(i[2], '.Rus'), i[2] ) )
					else:
						temp_rus.append( (i[0], i[1], cfname(i[2], '.Rus'), i[2] ) )
				elif 'eng ' in n: temp_eng.append( (i[0], i[1], cfname(i[2], '.Eng'), i[2] ) )
				elif temp_rus == []: temp_rus.append( (i[0], i[1], cfname(i[2], '.Rus'), i[2] ) )
				else: temp_other.append( (i[0], i[1], cfname(i[2]), i[2] ) )
			temp_l = []
			temp_l.extend(temp_rus)
			temp_l.extend(temp_eng)
			temp_l.extend(temp_other)
			self.log(temp_l)
			subtitles = []
			for i in temp_l:
					uname = "/torrent/view/"+str(self.hash).lower()+"/"+urllib.quote_plus(i[3].encode('utf8').replace('/','_').replace('(','_').replace(')','_').replace('[','_').replace(']','_').replace(',','_').replace('+','_').replace("'","_").replace('!','_').replace('&','_')).replace('+','_').replace('__','_')
					self.log(uname)
					data = client(uname)
					#self.log(data)
					if data:
						try:
							from xbmcup.app import Handler
						except:
							class Handler:
								@staticmethod
								def path(*path):
									p = [os.path.dirname(__file__)]
									p.extend(path)
									print p
									return os.path.join(*p)
						sdir = Handler().path('subtitles')
						if not os.path.isdir(sdir): os.mkdir(sdir)
						fname = Handler().path('subtitles', i[2])
						file(fname, 'wb').write(data)
						subtitles.append(fname)
					else:
						self.log('error loading subtitles!')
						success = False
						break
			if subtitles !=[]: self.subtitles = subtitles
		else:
			self.log('subtitles not found!')
		self.log('-- loadsubtitles stop --')
                return success
        return False

    def play(self):
        playuri = TORRSERVED_HOST + "/torrent/play?link="+self.magneturi+"&file="+str(self.fileid)
        if self.save: playuri += "&save=true"
        #touch(playuri)
        if self.makePreloadDialog(url=playuri):
            self.log('--play--')
            self.log(playuri)
            if xbmc.Player().isPlaying():
                      xbmc.Player().stop()
                      while xbmc.Player().isPlaying():
                           xbmc.sleep(100)
                      xbmc.sleep(2000)
            from xplayer import xPlayer
            Player = xPlayer(hash=self.hash, index=self.index)
            item = xbmcgui.ListItem(path=playuri)
            if self.subtitles:
                   item.setSubtitles(self.subtitles)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
            while not xbmc.Player().isPlaying() and not xbmc.abortRequested:
               xbmc.sleep(100)
            # Wait until playing finished or abort requested
            while not xbmc.abortRequested and xbmc.Player().isPlaying():
                    xbmc.sleep(500)

            client("/torrent/drop", post_data={"Hash": self.hash})
            return True
        client("/torrent/drop", post_data={"Hash": self.hash})
        return False

    def add(self, title=None, info=None):
        if isinstance(info, dict): info = json.dumps(info)
        res = client('/torrent/add', post_data={'Link':self.magneturi, 'Title':title, 'Info':info})
        return res


def play(path=None, index=None, data=None, subtitles=None, save=None, log=no_log):
    ts = Engine(path=path, data=data, index=index, subtitles=subtitles, save=save, log=log)
    r = ts.gotinfo()
    if r:
       s = ts.loadsubtitles()
    if r:
       r = ts.play()
    return r

def add(path=None, index=None, data=None, subtitles=None, save=None, title=None, info=None, log=no_log):
    ts = Engine(path=path, data=data, index=index, subtitles=subtitles, save=save, log=log)
    r = ts.add(title, info)
    return r


if __name__ == '__main__':

	path = '/home/osmc/.kodi/temp/plugin_rutracker_cache.torrent'
	file_id = 3 #0

	def log(s):
		print(s)

		with open('engine.log', 'a') as f:
			try:
				f.write(unicode(s).encode('utf-8'))
			except:
				f.write(s)
			f.write('\n')


	######
	#
	play(path, file_id, subtitles=True, log=log)
	info = {'originaltitle':u'test 2 первый второй', 'year': 1999}
	#print add(path, title='test tttttttttttttttttttttaaaaaaaaaaaaaaaaaaaa2', info={'poster_path':'/home/osmc/.kodi/addons/plugin.video.rutor.audio/icon.png', 'descript': u'test test1 тест', 'kodi':{'info':info}})

	#e = Engine(path=path, index=file_id, log=log)
        #e.gotinfo()
	#e.play()

	#z = client('/torrent/list', post_data={'Request': 0})
	#for t in z:
	#	if t['Hash'] == e.hash:
	#		print t['Files']
	

