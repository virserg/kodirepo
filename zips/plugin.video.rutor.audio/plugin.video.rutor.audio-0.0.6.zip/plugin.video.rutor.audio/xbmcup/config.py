# -*- coding: utf-8 -*-

REVERSE   = False
SORTFILE  = True
PATHFILE  = False
SORTPATH  = True
ONLYVIDEO = True
ONLYAUDIO = True

def init():
    global REVERSE, SORTFILE, PATHFILE, SORTPATH, ONLYVIDEO, ONLYAUDIO
    try:
        import xbmcaddon
	ADDON = xbmcaddon.Addon()
        def getset(s, p):
            if ADDON.getSetting(s) == 'true': return True
            elif ADDON.getSetting(s) == 'false': return False
            return p

        REVERSE   = getset('torrent_reverse',   REVERSE)
        SORTFILE  = getset('torrent_sortabc',   SORTFILE)
        PATHFILE  = getset('torrent_pathtor',   PATHFILE)
        SORTPATH  = getset('torrent_sortpath',  SORTPATH)
        ONLYVIDEO = getset('torrent_onlyvideo', ONLYVIDEO)
        ONLYAUDIO = getset('torrent_onlyaudio', ONLYAUDIO)

    except: pass


init()
