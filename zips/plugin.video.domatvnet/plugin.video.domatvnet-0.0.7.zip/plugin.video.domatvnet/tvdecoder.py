#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Eviloid

import re, base64

def decode_domatvnet(html):
    result = ''

    def decode(x):
        a = x[2:]

        file3_separator = 'F'

        # bk0, bk1...bk4
        bk = [b'556GG', b'D4FG5F', b'R4RGR3V',
              b'3SFVFF1O', b'2TF5D8X2NQ']

        for k in reversed(bk):
            a = a.replace(file3_separator + base64.standard_b64encode(k).decode('utf-8'), '')

        try:
            template = base64.standard_b64decode(a.encode('utf-8')).decode('utf-8')
        except:
            template = ''

        return template

    v1 = re.search(re.compile(r'var kodk="(.+?)"'), html).group(1)
    v2 = re.search(re.compile(r'var kos="(.+?)"'), html).group(1)
    template = re.search(re.compile(r'Playerjs\(.+file:"(.+?)"'), html).group(1)

    for _ in range(3):
        if template[:2] == '#2':
            template = decode(template)
        if '{v' in template:
            break
    else:
        template = ''

    result = template.replace('{v1}', v1).replace('{v2}', v2)
    return result




if __name__ == '__main__':

    from urllib.request import Request, urlopen
    from urllib.parse import urlencode

    def get_html(url, params=None, headers={}):
        USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'

        headers['User-Agent'] = headers.get('User-Agent') or USER_AGENT
        if params:
            url = '%s?%s' % (url, urlencode(params))
        conn = urlopen(Request(url, headers=headers))
        data = conn.read()
        conn.close()
        if conn.headers.get_content_charset():
            data = data.decode(conn.headers.get_content_charset())
        if isinstance(data, bytes):
            data = data.decode('utf-8')
        return data 


    BASE_URL = 'http://ip.domatv.net'

    html = get_html('{}/56-history.html'.format(BASE_URL))

    url = decode_domatvnet(html)

    if url:
        from subprocess import Popen
        proc = Popen(['vlc', url])
        proc.wait()