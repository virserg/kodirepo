# -*- coding: utf-8 -*-

import sys, os
import re
import socket
import random, time
socket.setdefaulttimeout(20)

site_url = 'http://domatv.net'

try:
	from xbmcup.app import _setting
	_domain_ = _setting['site_domain']
	#_subtitles_ = bool(_setting['view_subtitles'] == 'true')
	_get_domain_ = bool(_setting['get_domain'] == 'true')
	_kodi_ = True
	if _domain_:
		_domain_ = _domain_.replace('https://', '').replace('http://', '').strip('/').strip()
		if _domain_:
			if _setting['use_https'] == 'true': site_url = 'https://' + _domain_
			else: site_url = 'http://' + _domain_
except Exception:
	_get_domain_ = False
	_kodi_ = False
	sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'script.module.beautifulsoup4', 'lib'))


headers = {
	'User-Agent': 'Mozilla/5.0 (Android 8.1.0; Mobile; rv:67.0) Gecko/67.0 Firefox/67.0',
	#'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
	#'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
#	'Accept-Encoding': 'gzip',
	'Cache-Control': 'no-cache',
	'Referer': site_url
	}


class Error(Exception):
    def __init__(self, msg):
	self.msg = msg

    def __str__(self):
	return '{}'.format(self.msg)

def getUrl(url, rurl=False, rheaders=False, referer=None, proxy=None):
	from xbmcup.net import HTTP
	http = HTTP()
	if isinstance(url, unicode):
		url = url.encode('utf8')
	if referer: headers['Referer'] = referer
	if proxy:
		response = http.fetch(url, headers=headers, cookies='cookies.moz', proxy_protocol=url.split(':')[0], proxy_host=proxy.split(':')[0], proxy_port=proxy.split(':')[1])
	else:
		response = http.fetch(url, headers=headers, cookies='cookies.moz')
	if response.code == 200:
		if rurl:
			return response.url , response.body
		elif rheaders:
			return response.headers, response.body
		else:
			return response.body
        else:
		try:
			from xbmcup.errors import message
			message('Ошибка '+str(response.code)+' HTTP:', response.error)
			import xbmc
			xbmc.sleep(3000)
		except: pass
		raise Error(response.error)
		return response.code

def postUrl(url, param):
	from xbmcup.net import HTTP
	http = HTTP()
	if isinstance(url, unicode):
		url = url.encode('utf8')
	response = http.fetch(url, method='POST', params=param, headers=headers, cookies='cookies.moz')
	if response.code == 200:
			return response.url , response.body
        else:
		try:
			from xbmcup.errors import message
			message('Ошибка '+str(response.code)+' HTTP:', response.error)
			import xbmc
			xbmc.sleep(3000)
		except: pass
		raise Error(response.error)
		return response.code

def GetProxyList():
	import httplib
	conn = httplib.HTTPConnection("antizapret.prostovpn.org")
	conn.request("GET", "/proxy.pac", headers={"User-Agent": 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)'})
	r1 = conn.getresponse()
	data = r1.read()
	conn.close()
	proxylist = re.compile('PROXY (.+?); DIRECT').findall(data)
	#print proxylist
	return proxylist

def proxy_update():
	return GetProxyList()[0]
"""
if _get_domain_:
		try: pt=float(_setting['proxy_time'])
		except: pt=0
		if time.time()-pt > 36000:
			proxy1 = proxy_update()
			#proxy1=__setting['proxy_serv']
			#print proxy1
			try:
				_setting['proxy_time'] = str(time.time())
			except: pass
			data = getUrl('https://t.me/s/kinovodnet', proxy=proxy1)
			#file('/home/osmc/tme-kinovodnet.txt', 'wb').write(data)
			r = re.compile('"(http[s]?://kinovod[0-9]*?\.[a-z]*?)/"',re.S|re.U).findall(data)
			#print r
			redirect_url = r[-1]
			if site_url != redirect_url:
				try:
					_setting['site_domain'] = redirect_url.split('/')[2]
					_setting['use_https'] = 'true' if redirect_url.split(':')[0] == 'https' else 'false'
				except: pass
				site_url = redirect_url
				#print redirect_url, site_url
				#print _setting
"""
def r_u(url):
	if url.startswith(site_url): return url.replace(site_url,'')
	else: return url

def n_u(url):
	if ('://' in url) or (url is None) or (url[0] != '/'): return url
	else: return site_url + url

def pars(data):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	c = soup.find('ul', 'side-box side-nav to-mob').findAll('li')
	#print c
	genres = []
	for i in c:
		tu = i.find('a')
		numb = i.find('span').text
		text = tu.text.strip() + '     ' + numb.strip()
		url = r_u(tu['href'])
		if url == '#':
			genres.append( ( u'[COLOR green]'+ text + u'[/COLOR]', 0 ) )
		else:
			genres.append( ( text, url ) )
	return { 'genres': genres }


def pars2(data, is_start=True, is_sort=False):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	i = soup.find('div', id='dle-content')
	v_temp_list = []
	podbor_list = []
	#i = v[0]
	#print i
	#for i in v:
	if i:
		x = i.findAll('a')
		#n = x[0]
		#print n
		for n in x:
			if '/page/' not in n['href']:
				info = {}
				#print n
				text = n.text
				info['title'] = text.strip()
				url = r_u( n['href'] )

				im = n.find('img')
				img = None
				if im:
					if im['src'] != '':
						img = n_u( im['src'] )
				#print info, url, img

				yqt = ''
				#if url != '/':
				if '.html' in url:
					v_temp_list.append( {'url': url, 'thumb': img, 'info': info, 'yq': yqt} )
		#print v_temp_list
	
	category_list = []
	country_list = []
	if is_start:
		ci = soup.find('ul', 'dropdown-menu')
		if ci:
			for j in ci.findAll('a'):
				category_list.append( ( j.text, r_u(j['href']) ) )
		si = ci.findNext('ul', 'dropdown-menu')
		if si:
			for j in si.findAll('a'):
				country_list.append( ( j.text, r_u(j['href']) ) )
	#print category_list
	
	page = {'max': 1, 'current': 1, 'next': None, 'prev': None}
	pg = soup.find('div', 'navigation')
	#print pg
	if pg:
		t = pg.findAll('a')
		cu = pg.findAll('span')
		#print t
		#print cu
		try: page['max'] = int(t[-1]['href'].split('page/')[1].strip('/'))
		except:
			try: page['max'] = int(t[-2]['href'].split('page/')[1].strip('/'))
			except:
				try: page['max'] = int(t[-1].text)
				except: page['max'] = -1
		try: page['current'] = int(cu[0].text)
		except: page['current'] = int(cu[1].text)
		for i in t:
			if str(page['current']+1) == i.text:
				page['next'] = i['href']
				if i['href'] == '#': page['snext'] = int(i.text)
			if str(page['current']-1) == i.text: page['prev'] = i['href']
		#print page

	sort_list = []
	if is_sort and (page['current'] == 1):
		names = []
		n = soup.findAll('span', 'dropdown-u')
		if n:
			for i in n:
				names.append( i.text )
			v = soup.findAll('ul', 'dropdown-menu')
			for i, name in zip(v, names):
				sort_name = name+u': '
				actives_name = []
				a = i.findAll('li', 'active')
				if a:
					for a1 in a:
						a2 = a1.find('a')
						if a2:
							actives_name.append( a2.text)
					sort_param = u', '.join(actives_name)
				else:
					sort_param = u'Все'
					a = i.findAll('a', 'active')
					if a:
						for a2 in a:
							actives_name.append( a2.text)
						sort_param = u', '.join(actives_name)
				sort_name = u''.join([u'[COLOR green]', sort_name, sort_param, u'[/COLOR]'])
				#print sort_name
				all_sort = []
				for j in i.findAll('a'):
					s_name = j.text
					if s_name in actives_name: s_name = u'[COLOR gold]' + s_name + u'[/COLOR]'
					all_sort.append( (s_name, j['href']) )
				#print all_sort
				sort_list.append( {'name': sort_name, 'sort': all_sort} )
	return {'data': v_temp_list, 'page': page, 'podbor': podbor_list, 'filter': sort_list, 'category': category_list, 'country': country_list}


def pars3(data):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	ur= soup.find('meta', property='og:url')
	url = ur['content']
	p = soup.find('div', id='dle-content')
	content_list = []
	podbor_list = []
	if p:
		#print p
		info = {}
		r = p.find('h1')
		if r: info['title'] = r.text.strip()
		t = r.findNext('img')
		if t: img = n_u( t['src'] )
		#print img, info
		"""
		g = p.find('div', 'fright fx-1')
		if g:
			text = ''.join(g.findAll(text=True))
		strana = False
		for j in text.splitlines():
			#print j
			if u'Оригинальное название:' in j: info['originaltitle'] = j.split(':')[1].strip()
			if strana:
				if j.strip() != u'':
					info['studio'] = j.strip()
					strana = False
			if u'Страна:' in j: strana = True
			if u'Категория:' in j: info['genre'] = j.split(':')[1].strip()
			if u'Цикл:' in j: info['tagline'] = j.split(':')[1].strip()
			if u'Автор:' in j:
				info['writer'] = j.split(':')[1].strip()
				#info['album'] = info['writer']
			if u'Читает:' in j:
				info['director'] = j.split(':')[1].strip()
				#info['artist'] = info['director']
			if u'Продолжительность:' in j:
	    				dc = re.compile(u'([\d+]+)',re.S).search(j)
					if dc:
						#ts = dc.group(1).split(':')
						#info['duration'] = int(ts[0])*60*60+int(ts[1])*60+int(ts[2])
						info['duration'] = int(dc.group(1))*60
			if u'Качество:' in j:
				ik = g.find('img', 'po')
				tk = ''
				if ik:
					 tk = u' ' + ik['src'].split('/')[-1].split('.')[0]
				info['plotoutline'] = j + tk
			if u'Озвучка:' in j: info['mpaa'] = j
			if u'Год выпуска:' in j:
					year = j.split(':')[1].strip()
					if year !='':
						info['year'] = int(year)
			if u'Актеры:' in j:
				info['cast'] = [i.strip() for i in j.split(':')[1].split(',') if i]


		o = p.find('div','fdesc full-text video-box clearfix')
		if o:
			r = re.compile(' mp3\:(.+?)$',re.S).search(o.text)
			if r:
				info['plot'] = r.group(1).replace('\t', ' ').strip('\n')
				#info['comment'] = info['plot']
		"""

		screenshot = None
		tempcastfull = None
		content_list.append( {'url': r_u(url), 'thumb': img, 'info': info, 'cast': tempcastfull, 'screenshot': screenshot} )

	page = {'max': 1, 'current': 1, 'next': None, 'prev': None}
	return {'data': content_list, 'page': page, 'podbor2': podbor_list}

def decode_domatv(s):
	import base64
	tokens = ('//MzNmM2I4N2EtMWM3Yy00MDc2LWE2ODktNTVjNTZhNmQwOWQ3',
		  '//OTcwZTYzMmUtMmQ4MC00N2M5LTg1ZTMtMjkxMGM0MmNiOGRm',
		  '//NDRkMWU0NjctZjI0Ni00NjY5LTkyZTEtOGVlNmI2YjNiMzE0',
		  '//Y2UyMTczZjctZjAwNC00Njk5LWFmYmQtYzEwNzQ3MzYyZmQ0',
		  '//M2Q0Nzg4ZjUtZWY1MC00MzI5LWFmYjYtYzQwMGFlMDg5N2Zh' )
	s = s.replace('#2','')
	index = 0
	while index < 100:
		index += 1
		for i in tokens:
			s = s.replace(i,'')
		if '//' not in s:
			return base64.b64decode(s)
	return None

def decode_domatv2(data):
    import string
    import base64
    c_data = data.replace("#2","")
    mlen = 50
    index = 0
    if "//" in c_data:
        while index < 1000:
          index += 1
          Beg = c_data.rfind("//")
          if Beg >= 0:
             c_data=c_data.replace(c_data[Beg:Beg+mlen],"")
          else:
               for i in range(0, len(c_data)):
                  if c_data[i] not in ("=+0123456789/"+string.ascii_letters):
		     #print(i, c_data[i])
                     return None
               return base64.b64decode(c_data)
    return None


def pars_play(data):
#    var firstIpProtect = 'x2.xxxxxx.xxx';
#    var secondIpProtect = 'x1.xxxxx.xxx';
#    var portProtect = '00000';
#    var player = new Playerjs({id:"player", file:"#2aHR0cHM6Ly97djF//NDRkMWU0NjctZjI0Ni00NjY5LTkyZTEtOGVlNmI2Yj//MzNmM2I4N2EtMWM3Yy00MDc2LWE2ODktNTVjNTZhNmQwOWQ3NiMzE09Ont2M30vczRnX3Nob2tpcnV5//Y2UyMTczZjctZjAwNC00Njk5LWFmYmQtYzEwNzQ3MzYyZmQ0dXNjaG//OTcwZTYzMmUtMmQ4MC00N2M5LTg1ZTMtMjkxMGM0MmNiOGRmUvaW5kZXgubTN//M2Q0Nzg4ZjUtZWY1MC00MzI5LWFmYjYtYzQwMGFlMDg5N2Zh1OD93bXNBdXRoU2lnbj0xNTg4NjE3NTIxUzQzNDgyNWJlN2JiZDExMWI0ZTU4Y2JiYTcxZTJjYzc2UzMwMWgzM2gwNjFoNjQ="});</script>
	r = re.compile("var firstIpProtect = '([^']+)';",re.S).search(data)
	if r:
		v1 = r.group(1).strip()
	r = re.compile("var secondIpProtect = '([^']+)';",re.S).search(data)
	if r:
		v2 = r.group(1).strip()
	r = re.compile("var portProtect = '([^']+)';",re.S).search(data)
	if r:
		v3 = r.group(1).strip()
	r = re.compile('Playerjs\(\{id\:"player",\s*file\:"([^"]+)"\}\);',re.S).search(data)
	if r:
		url = r.group(1)
		#print url
		if url.startswith('#2'): url = decode_domatv2(url)
		#print url, v1, v2, v3
		url = url.replace('{v1}',v1).replace('{v2}',v2).replace('{v3}',v3)
		#print url
		if '<br>' in url: url = url.split('<br>')[0]
		return url
	return None

def catalog(url=None):
	fstart = False
	if not url:
		url = site_url
		fstart = True
	data = getUrl(n_u(url))
	#file('/home/osmc/catalog.txt', 'wb').write( data )
	return pars2(data, fstart)

def genres():
	data = getUrl(site_url)
	return pars(data)


def videoinfo(url):
	data = getUrl(n_u(url))
	#file('/home/osmc/videoinfo.txt', 'wb').write( data )
	res = pars3(data)
	res['url'] = pars_play(data)
	return res

def search(text):
	if isinstance(text, unicode): text = text.encode('utf8')
	from urllib import urlencode
	url, data = postUrl(site_url,{'do': 'search', 'subaction':'search', 'story': text, 'submit': r'Найти' } )
	#file('/home/osmc/search.txt', 'wb').write( data )
	if site_url == url:
		return False, pars2(data)
	else:
		return True, pars3(data)

def nextsearch(text, page):
	if isinstance(text, unicode): text = text.encode('utf8')
	from urllib import urlencode
	url, data = postUrl(site_url+'/index.php?do=search',{'do': 'search', 'subaction':'search', 'search_start': str(page), 'result_from': str((page-1)*14+1) ,'story': text, 'submit': r'Найти' } )
	#file('/home/osmc/nextsearch.txt', 'wb').write( data )
	return False, pars2(data)


def play_link(url, index=None):
	try:
		from xbmcup.errors import log
		log(url,'url=')
	except: pass
	#data = file('/home/osmc/domatv_videoinfo.txt', 'rb').read()
	data = getUrl(n_u(url))
	#file('/home/osmc/domatv_videoinfo.txt', 'wb').write(data)
	d_play = pars_play(data)
	try:
		from xbmcup.errors import log
		log(d_play,'d_play=')
	except: pass
	if d_play is None:
		return None, ['Отсутствует ссылка на выбранный канал.','Возможно данный канал не доступен в вашей стране.']
	from urllib import urlencode
	opt = '|'+urlencode({ 'User-Agent': headers['User-Agent'], 'Referer': d_play })
	if index or index == 0:
		return  d_play[index] + opt, None
	else:
		return d_play + opt, None


if __name__ == '__main__':
	#catalog()
	data = file('/home/osmc/catalog.txt', 'rb').read()
	#print	pars2(data)
	#print filter()
	#print pars_topweek(data)

	data = file('/home/osmc/videoinfo.txt', 'rb').read()
	#print  pars3(data)
	#print pars_play(data)
	#print play_link('fff')

	#print search('толстой')
	#print nextsearch('толстой', 2)

	data = file('/home/osmc/search.txt', 'rb').read()
	#print pars2(data)

	pass

