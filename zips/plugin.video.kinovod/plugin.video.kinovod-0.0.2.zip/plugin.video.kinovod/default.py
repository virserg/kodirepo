# -*- encoding: utf-8 -*-

import os, sys

import xbmc, xbmcplugin, xbmcgui

from xbmcup.app import Link, Handler, Plugin, _setting
import kinovod
from history import History, HistoryAdd

_view_ = _setting['view']


class Menu(Handler):
	def handle(self):
		d = kinovod.startpage()
		self.item(Link('catalog',{'search': True}), title='[Поиск]')
		self.item(Link('history'), title='[История поиска]')
		self.item(Link('genre',{'data': d['category']}), title='Раздел')
		self.item(Link('genre',{'data': d['genres']}), title='Жанр')
		self.item(Link('genre',{'data': d['country']}), title='Страна')
		self.item(Link('genre',{'data': d['years']}), title='Год')
		for i in range(len(d['gpt'])):
			title = u'[COLOR green]' + d['gpt'][i][0] + u':[/COLOR]'
			self.item(Link('catalog', {'url': d['gpt'][i][1]}), title=title)
			for j in d['data'][i]:
				popup =  []
				popup.extend(self.popup)
				title = j['info']['title']
				popup.insert(1, (Link('catalog', {'search': True, 'textsearch': title}, True), 'Поиск') )
				if j['info'].get('plotoutline'):
					title = title + u' (' + j['yq'] + u', ' + j['info']['plotoutline'] + u')'
				else:
					title = title + u' (' + j['yq'] + u')'
				self.item(Link('video', {'url': j['url']}), title=title, media='video', info=j['info'], thumb=j['thumb'], popup=popup, popup_replace=True)
		self.render(nextmode=_view_)


class Catalog(Handler):
	def handle(self):
		search = self.argv.get('search')
		url = self.argv.get('url')
		s_kbd = self.argv.get('s_kbd', False)
		sort = self.argv.get('sort')
		if sort:
			index = xbmcgui.Dialog().select('Киновод', [x[0] for x in sort])
			if index < 0:
				return True
			else:
				url = sort[index][1]
		if search:
			if isinstance(search, bool):
				textsearch = self.argv.get('textsearch', '')
				search = self.kbdinput('Поиск', textsearch)
				if search is None: return True
				s_kbd = True
				HistoryAdd(search)
			s1, data = kinovod.search(search)
		elif url == 0:
			return True
		else:
			data = kinovod.catalog(url)
		if (data['data']==[]) and s_kbd and (data['podbor'] ==[]):
			xbmcgui.Dialog().ok('Киновод', 'Ничего не найдено')
		if data.get('filter'):
			for i in data['filter']:
				self.item(Link('catalog', {'sort': i['sort']}), title=i['name'], media='video', popup=self.popup, popup_replace=True)
		for i in data['data']:
			popup = []
			popup.extend(self.popup)
			title = i['info']['title']
			popup.insert(1, (Link('catalog', {'search': True, 'textsearch': title}, True), 'Поиск') )
			if i['info'].get('plotoutline'):
				title = title + u' (' + i['yq'] + u', ' + i['info']['plotoutline'] + u')'
			else:
				title = title + u' (' + i['yq'] + u')'
			self.item(Link('video', {'url': i['url']}), title=title, media='video', info=i['info'], thumb=i['thumb'], popup=popup, popup_replace=True)
		for i in data['podbor']:
			self.item(Link('catalog', {'url': i['url']}), title=i['info']['title'], media='video', info=i['info'], thumb=i['thumb'], popup=self.popup, popup_replace=True)
		if data['page']['next']:
			titlepage = 'Следующая страница '+ str(data['page']['current']+1)+ ' из ' + str(data['page']['max']) + ' >>'
			self.item(Link('catalog',{'url':data['page']['next']}), title=titlepage)
		self.render(nextmode=_view_)


class Genres(Handler):
	def handle(self):
		data = self.argv.get('data')
		for i in data:
			self.item(Link('catalog',{'url': i[1]}), title=i[0])
		self.render(nextmode=_view_)


class VideoInfo(Handler):
	def handle(self):
		url = self.argv.get('url')
		d = kinovod.videoinfo(url)
		data = d['data'][0]
		title = data['info']['title']
		info = data['info']
		if isinstance(d['url'], basestring):
			self.item(Link('play',{'url': data['url']}), title=title, media='video', info=info, thumb=data['thumb'], popup=self.popup, popup_replace=True, property=[('IsPlayable','true')], folder=False)
		else:
			self.item(Link('video', {'url': data['url'] }), title=title, media='video', info=data['info'], thumb=data['thumb'], popup=self.popup, popup_replace=True)
			for name, durl, index in d['url']:
				info['title'] = title + u' / ' + name
				self.item(Link('play',{'url': data['url'], 'index': index }), title=name, media='video', info=info, thumb=data['thumb'], popup=self.popup, popup_replace=True, property=[('IsPlayable','true')], folder=False)
		self.render(nextmode=_view_)


class Play(Handler):
	def handle(self):
		url = self.argv.get('url')
		durl = self.argv.get('durl')
		index = self.argv.get('index')
		if url:
			link, error = kinovod.play_link(url, index)
		elif durl: link = durl
		if link:
			#xbmc.Player().play(link)
			#from urllib import urlencode
			#link = link + '|' + urlencode( {'Referer': link} )
			item = xbmcgui.ListItem(path=link)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]),True, item)
		else:
			xbmcgui.Dialog().ok('Киновод', *error)


def main():
	plugin = Plugin(Menu)
	plugin.route('catalog', Catalog)
	plugin.route('genre', Genres)
	plugin.route('video', VideoInfo)
	plugin.route('play', Play)
	plugin.route('history', History)
	plugin.run()


if __name__ == '__main__':
	try:
                search_vars = sys.argv[2].split('?')
                search_vars = search_vars[-1].split('&')
                if 'usearch=True' in search_vars:
                        from urlparse import parse_qs
                        params = parse_qs(sys.argv[2].replace('?', ''))
                        united_search = {'route': 'catalog', 'argv': { 'search': params['keyword'][0] } }
			from urllib import quote_plus
                        import json
                        sys.argv[2] = '?'+quote_plus(json.dumps(united_search))
	except BaseException as e:
		from xbmcup.errors import log
		log(e)

	main()
