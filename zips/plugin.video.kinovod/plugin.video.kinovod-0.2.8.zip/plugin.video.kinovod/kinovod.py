# -*- coding: utf-8 -*-

import sys, os
import re
import socket
import random, time
from xbmcup.utils23 import PY2, _de, _en, _de3, _en3
if PY2:
	from urllib import urlencode
else:
	from urllib.parse import urlencode, quote
	unicode = str

socket.setdefaulttimeout(10)

site_url = 'https://kinovod.net' #.cc'

randindex = random.randint(0,1)

try:
	from xbmcup.app import _setting
	_quality_ = _setting['quality']
	_video_ = int(_setting['video_license'])
	_domain_ = _setting['site_domain']
	_use_proxy_ = bool(_setting['use_proxy'] == 'true')
	_proxy_ = _setting['proxy_serv']
	_rating_ = int(_setting['rating_type'])
	_subtitles_ = bool(_setting['view_subtitles'] == 'true')
	_is_info_ = bool(_setting['is_full_info'] == 'true')
	_get_domain_ = bool(_setting['get_domain'] == 'true')
	_kodi_ = True
	if _domain_:
		_domain_ = _domain_.replace('https://', '').replace('http://', '').strip('/').strip()
		if _domain_:
			if _setting['use_https'] == 'true': site_url = 'https://' + _domain_
			else: site_url = 'http://' + _domain_
except Exception:
	_is_info_ = False
	_get_domain_ = False
	_use_proxy_ = False
	_proxy_ = None
	_kodi_ = False
	_subtitles_ = True
	_rating_ = 0
	_quality_ = '720'
	_video_ = 0
	sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'script.module.beautifulsoup4', 'lib'))


headers = {
	'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
	'Cache-Control': 'no-cache',
	'Referer': site_url
	}

Quality = (360, 480, 720, 1080)

class Error(Exception):
	def __init__(self, msg):
		self.msg = msg

	def __str__(self):
		return '{}'.format(self.msg)

def getUrl(url, rurl=False, rheaders=False, referer=None, proxy=None):
	from xbmcup.net import HTTP
	http = HTTP()
	if isinstance(url, unicode):
		url = _en(url)
	if not PY2: url = quote(url, ':/&=?%+')
	if referer: headers['Referer'] = referer
	if proxy is None and _use_proxy_ and _proxy_:
		proxy = _proxy_
	if proxy:
		proxy = _de3(proxy)
		response = http.fetch(url, headers=headers, cookies='kinovod.moz', proxy_protocol=url.split(':')[0], proxy_host=proxy.split(':')[0], proxy_port=proxy.split(':')[1])
	else:
		response = http.fetch(url, headers=headers, cookies='kinovod.moz')
	if response.code == 200:
		if rurl:
			return response.url , response.body
		elif rheaders:
			return response.headers, response.body
		else:
			return response.body
	else:
		try:
			from xbmcup.errors import message
			message('Ошибка '+str(response.code)+' HTTP:', response.error)
			import xbmc
			xbmc.sleep(3000)
		except: pass
		raise Error(response.error)
		return response.code

def postUrl(url, param):
	from xbmcup.net import HTTP
	http = HTTP()
	if isinstance(url, unicode):
		url = _en(url)
	if not PY2: url = quote(url, ':/&=?%+')
	response = http.fetch(url, method='POST', params=param, headers=headers, cookies='kinovod.moz')
	if response.code == 200:
			return response.url , response.body
	else:
		try:
			from xbmcup.errors import message
			message('Ошибка '+str(response.code)+' HTTP:', response.error)
			import xbmc
			xbmc.sleep(3000)
		except: pass
		raise Error(response.error)
		return response.code

def GetProxyList():
	if PY2:
		import httplib
	else:
		import http.client as httplib
	conn = httplib.HTTPConnection("antizapret.prostovpn.org")
	conn.request("GET", "/proxy.pac", headers={"User-Agent": 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)'})
	r1 = conn.getresponse()
	data = r1.read()
	conn.close()
	#print data
	proxylist = re.compile(b'PROXY (.+?); DIRECT').findall(data)
	#print proxylist
	return proxylist

def proxy_update():
	plist = GetProxyList()
	return plist[0] if plist else _setting['proxy_serv']


if _get_domain_ or _use_proxy_:
	try: pt=float(_setting['proxy_time'])
	except: pt=0
	if time.time()-pt > 36000:
		proxy1 = proxy_update()
		try:
			_setting['proxy_serv'] = proxy1
		except: pass
		_proxy_ = proxy1
		#print proxy1
		try:
			_setting['proxy_time'] = str(time.time())
		except: pass
		if _get_domain_:
			try:
				data = getUrl('https://t.me/s/kinovod_net', proxy=False)
			except:
				data = getUrl('https://t.me/s/kinovod_net', proxy=proxy1)
			#open('/home/osmc/tme-kinovodnet.txt', 'wb').write(data)
			r = re.compile(b'"(http[s]?://kinovod[0-9]*?\.[a-z]*?)/"',re.S).findall(data)
			if not r: r = re.compile(b'([kK]inovod[ 0-9]+)',re.S).findall(data)
			if r:
				redirect_url = _de3(r[-1]).replace(' ','').lower()
				if '.' not in redirect_url: redirect_url= 'http://'+redirect_url+'.cc'
				#print(redirect_url)
				if site_url != redirect_url:
					try:
						_setting['site_domain'] = redirect_url.split('/')[2]
						_setting['use_https'] = 'true' if redirect_url.split(':')[0] == 'https' else 'false'
					except: pass
					site_url = redirect_url
					#print redirect_url, site_url
					#print _setting

def r_u(url):
	if url.startswith(site_url): return url.replace(site_url,'')
	elif url.startswith('https://'+site_url.split('/')[2]): # из-за путаницы с протоколом при автоопределении url
			return url.replace('https://'+site_url.split('/')[2], '')
	else: return url

def n_u(url):
	if ('://' in url) or (url is None) or (url[0] != '/'): return url
	else: return site_url + url

def pars(data, is_info=_is_info_):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	g_t_list = []
	g = soup.find('div', id='main')
	for i in g.findAll('a', 'h3'):
		#print i.text, i['href']
		g_t_list.append( (i.text, r_u(i['href'])) )
	video_list = []
	v = g.findAll('div', 'row items')
	#i = v[0]
	#print i
	for i in v:
	#if i:
		v_temp_list = []
		x = i.findAll('div', 'col-xs-2')
		#j = x[0]
		for j in x:
		#if j:
			info = {'mediatype': 'movie'}
			img = n_u(j.find('img')['src'])
			tr = j.find('div', 'title').find('a')
			#print j
			info['title'] = tr.text
			url = r_u(tr['href'])
			yq = j.find('div', 'desc')
			yqt = ''
			if yq:
				yqt = yq.text
				yr = re.compile('([1-2]{1}\d{3})',re.S).search(yqt)
				if yr:
					info['year'] = int(yr.group(1))
				if ',' in yqt:
					info['tagline'] = u'Качество: ' + yqt.split(',')[1].strip()
			sr = j.find('span', 'label')
			if sr:
				info['plotoutline'] = sr.text
			v_temp_list.append( {'url': url, 'thumb': img, 'info': info, 'yq': yqt} )
		#print v_temp_list
		video_list.append( v_temp_list )

	s = soup.find('div', id='sidebar')
	l = s.findAll('a', 'sidebar-link')
	start = False
	for i in l:
		#print i.text, i['href']
		if i.text == u'Фильмы':
			start = True
			temp_list = []
		elif i.text == u'Биография':
			category = []
			category.extend(temp_list)
			temp_list = []
		elif i.text == u'Австралия':
			genres = []
			genres.extend(temp_list)
			temp_list = []
			first = True
		elif i.text.isdigit() and first:
			country = []
			country.extend(temp_list)
			first = False
			temp_list = []
		elif i.text == u'Показать все':
			years = []
			years.extend(temp_list)

		if start:
			if i['href'][0] == '/':
				temp_list.append( (i.text, i['href']) )
	#print category
	#print genres
	#print country
	#print years
	if is_info:
		#print video_list
		try:
				from xbmcup.app import Handler
				p = Handler()
				p.show_progress(u'Киновод', 'Загрузка полного описания видео ...')
				k = 0
				klen = len(video_list)*len(video_list[0])
		except: pass
		for i in range(len(video_list)):
			t = video_list[i]
			for j in range(len(t)):
				try:
					k += 1
					p.update_progress(k*100/klen, ['Загружаем описание видео {} из {} :'.format(k, klen), t[j]['info']['title'] ] )
					if p.iscanceled_progress():
						break
				except: pass
				data2 = getUrl(n_u(t[j]['url']))
				pol = t[j]['info'].get('plotoutline', None)
				t[j]['info'] = pars3(data2, is_info=is_info)['data'][0]['info']
				t[j]['info']['plotoutline'] = pol
			video_list[i] = t
		try:
				p.hide_progress()
		except:pass

	return {'gpt': g_t_list, 'data': video_list, 'category': category, 'genres': genres, 'country': country, 'years': years}


def pars2(data, is_sort=True, is_info=_is_info_, rurl=''):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	v = soup.findAll('div', 'row items')
	v_temp_list = []
	podbor_list = []
	navi = soup.find('ul', 'nav nav-tabs')
	if navi:
		navtabs = navi.findAll(text=re.compile('[^\s]'))
	#i = v[0]
	#print i
	inx_nav = 0
	for i in v:
	#if i:
		if navi:
			info = {}
			info['title'] = u'[COLOR green]' + navtabs[inx_nav] + u':[/COLOR]'
			inx_nav += 1
			v_temp_list.append( {'url': 0, 'thumb': None, 'info': info, 'yq': ''} )
		x = i.findAll('div', 'col-xs-2')
		#j = x[0]
		for j in x:
		#if j:
			info = {'mediatype': 'movie'}
			img = n_u(j.find('img')['src'])
			tr = j.find('div', 'title').find('a')
			#print j
			info['title'] = tr.text
			url = r_u(tr['href'])
			yq = j.find('div', 'desc')
			yqt = ''
			if yq:
				yqt = yq.text
				yr = re.compile('([1-2]{1}\d{3})',re.S).search(yqt)
				if yr:
					info['year'] = int(yr.group(1))
				if ',' in yqt:
					info['tagline'] = u'Качество: ' + yqt.split(',')[1].strip()
			sr = j.find('span', 'label')
			if sr:
				info['plotoutline'] = sr.text
			v_temp_list.append( {'url': url, 'thumb': img, 'info': info, 'yq': yqt} )
		#print v_temp_list

		y = i.findAll('div', 'col-xs-3')
		#j = y[0]
		for j in y:
		#if j:
			info = {}
			img = n_u(j.find('img')['src'])
			tr = j.find('div', 'title').find('a')
			info['title'] = tr.text
			url = r_u(tr['href'])
			podbor_list.append( {'url': url, 'thumb': img, 'info': info} )

	v = soup.find('div', style='margin-bottom:30px;')
	if v:
		n = v.findAll('a')
		if n:
			podbor_list.append( {'url': 0, 'thumb': None, 'info': {'title':u'[COLOR green]Найдены имена:[/COLOR]'} } )
			for i in n:
				info = {}
				info['title'] = i.text
				podbor_list.append( {'url': r_u(i['href']), 'thumb': None, 'info':info} )

	page = {'max': 1, 'current': 1, 'next': None, 'prev': None}
	pg = soup.find('ul', 'pagination')
	#print pg
	if pg:
		t = pg.findAll('a')
		cu = pg.findAll('span')
		try: page['max'] = int(t[-1]['href'].split('page=')[1])
		except: page['max'] = -1
		try: page['current'] = int(cu[-1].text)
		except: page['current'] = int(cu[-3].text)
		for i in t:
			if u'Следующая' in i.text: page['next'] = i['href']
			if u'Предыдущая' in i.text: page['prev'] = i['href']
		#print page

	sort_list = []
	if is_sort and (page['current'] == 1):
		names = []
		n = soup.findAll('span', 'dropdown-u')
		if n:
			for i in n:
				names.append( i.text )
			dm = soup.findAll('ul', 'dropdown-menu')
#			print len(dm)
#			print dm
			cd = soup.findAll('div', 'dropdown-menu checkbox-dropdown')
#			print len(cd)
			da = soup.findAll('div', 'dropdown-menu audio-dropdown')
			v = []
			v.extend([dm[0]])
			if cd: v.extend(cd)
			v.extend(dm[1:])
			if da: v.extend(da)
#			print len(names)
#			print len(v)
#			rurl += '/1924_1925'
			paramurl = rurl.split('?')[0].split('/')[-1].split('_')
			dparam = ''
			if '?' in rurl: dparam='?'+rurl.split('?')[1]
#			print rurl
			if rurl.split('?')[0].split('/',3)[-1].count('/') == 0: paramurl[0]=paramurl[0]+'_'
			else: paramurl.insert(0, rurl.split('?')[0].split('/')[-2]+'_')
#			print paramurl
			for i, name in zip(v, names):
				#actives = []
				sort_name = name+u': '
				actives_name = []
#				print i
				a = i.findAll('li', 'active')
				if a:
					for a1 in a:
						a2 = a1.find('a')
						if a2:
							#actives.append( (a2.text , a2['href']) )
							actives_name.append( a2.text)
					sort_param = u', '.join(actives_name)
				else:
					sort_param = u'Все'
					a = i.findAll('a', 'active')
					if a:
						for a2 in a:
							#actives.append( (a2.text , a2['href']) )
							actives_name.append( a2.text)
						sort_param = u', '.join(actives_name)
				#print sort_name
				#print actives
				all_sort = []
				for j in i.findAll('a'):
					s_name = j.text
					if s_name in actives_name: s_name = u'[COLOR gold]' + s_name + u'[/COLOR]'
					all_sort.append( (s_name, j['href']) )
				sort_input = []
				for j in i.findAll('div', 'checkbox'):
					s_name =  j.text.strip()
					i = j.find('input')
					if i.get('checked'): sort_input.append(s_name)
					purl = []
					purl.extend(paramurl)
					if i['value'] in paramurl:
						purl.remove(i['value'])
						s_name = u'[COLOR gold]' + s_name + u'[/COLOR]'
					else: purl.append(i['value'])
					url = '/'+'_'.join(purl).replace('__','/').strip('_')+dparam
					all_sort.append( (s_name, url) )
				#print all_sort
				if len(sort_input) > 0: sort_param = u', '.join(sort_input)
				sort_name = u''.join([u'[COLOR green]', sort_name, sort_param, u'[/COLOR]'])
				sort_list.append( {'name': sort_name, 'sort': all_sort} ) # 'active': actives} )

	if is_info and v_temp_list:
			try:
				from xbmcup.app import Handler
				p = Handler()
				p.show_progress(u'Киновод', 'Загрузка полного описания видео ...')
				k = 0
				klen = len(v_temp_list)
			except: pass
			for j in range(len(v_temp_list)):
				try:
					k += 1
					p.update_progress(k*100/klen, ['Загружаем описание видео {} из {} :'.format(k, klen), v_temp_list[j]['info']['title'] ] )
					if p.iscanceled_progress():
						break
				except: pass
				data2 = getUrl(n_u(v_temp_list[j]['url']))
				pol = v_temp_list[j]['info'].get('plotoutline', None)
				v_temp_list[j]['info'] = pars3(data2, is_info=is_info)['data'][0]['info']
				v_temp_list[j]['info']['plotoutline'] = pol
			try:
				p.hide_progress()
			except: pass

	return {'data': v_temp_list, 'page': page, 'podbor': podbor_list, 'filter': sort_list}


def pars3(data, rating_type=_rating_, is_info=False):
	from bs4 import BeautifulSoup
	soup = BeautifulSoup(data, 'html.parser')

	ur= soup.find('meta', property='og:url')
	url = ur['content']
	p = soup.find('div', id='movie')
	content_list = []
	if p:
		info = {'mediatype': 'movie'}
		r = p.find('h1')
		if r: info['title'] = r.text
		r = p.find('h4', 'alternative_title')
		if r: info['originaltitle'] = r.text
		l = p.find('div', 'poster-data')
		t = l.find('img')
		if t: img = n_u(t['src'])
		if rating_type == 0:
			r = l.find('div', id='rating-votes')
			if not r: r = l.find('div', 'rating-votes') #old
			if r:
				rt = re.compile(u'([\d\.]+) \(([ \d]+)',re.S).search(r.text)
				if rt:
					info['rating'] = float(rt.group(1))
					info['votes'] = rt.group(2).strip().replace(' ','')
		g = p.find('ul')
		if g:
			text = ''.join(g.findAll(text=True))
		for j in text.splitlines():
			#print j
			if u'Страна:' in j: info['studio'] = j.split(':')[1].strip()
			if u'Жанр:' in j: info['genre'] = j.split(':')[1].strip()
			if u'Слоган:' in j: info['tagline'] = j.split(':')[1].strip()
			if u'Сценарий:' in j: info['writer'] = j.split(':')[1].strip()
			if u'Режиссер:' in j: info['director'] = j.split(':')[1].strip()
			if u'Продолжительность:' in j:
				dc = re.compile(u'(\d+:\d+:\d+)',re.S).search(j)
				if dc:
					ts = dc.group(1).split(':')
					info['duration'] = int(ts[0])*60*60+int(ts[1])*60+int(ts[2])
			if u'Качество:' in j: info['plotoutline'] = j
			if u'Перевод:' in j: info['mpaa'] = j
			if u'Год:' in j: info['year'] = int(j.split(':')[1].strip())
			if u'Актеры:' in j:
				info['cast'] = [i.strip() for i in j.split(':')[1].split(',') if i]
			if rating_type == 1:
				if u'Рейтинг Кинопоиска:' in j:
					r = j.split(':')[1]
					info['rating'] = float(r.split('(')[0].strip())
					info['votes'] = r.split('(')[1].replace(' ','').strip(')')
			elif rating_type == 2:
				if u'Рейтинг IMDb:' in j:
					r = j.split(':')[1]
					info['rating'] = float(r.split('(')[0].strip())
					info['votes'] = r.split('(')[1].replace(' ','').strip(')')

		o = p.find('div','body')
		if o:
			info['plot'] = o.text
		r = re.compile(b'var\s*?MOVIE_TRAILER\s*?=\s*?"https://www.youtube.com/embed/([^"]+?)";',re.S).search(data)
		if not r: r = re.compile(b'<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/([^"]+?)" allowfullscreen></iframe>',re.S).search(data)
		if r: info['trailer'] = 'plugin://plugin.video.youtube/play/?video_id=' + _de3(r.group(1))

		content_list.append( {'url': r_u(url), 'thumb': img, 'info': info} )

	podbor_list = []
	comments_list = None
	m_id = None
	count_comments = None
	if not is_info:
		n = p.find('ul', 'list-unstyled related')
		if n:
			numb = 1
			podbor_list.append( {'url': 0, 'thumb': None, 'info': {'title': u'[COLOR green]Порядок просмотра:[/COLOR]'} } )
			for i in n.findAll('a'):
				podbor_list.append( {'url': i['href'], 'thumb': None, 'info': {'title': unicode(numb) + u'. ' + i.text} } )
				numb += 1

		c = p.find('div', id='comments-entries')
		if c:
			from xbmcup.html import Clear
			comments_list = []
			for i in c.findAll('div', 'media')[:-1]:
				comments_list.append( ( i.find('div', 'media-heading').text , Clear().text(i.find('p', 'text').text) ) )

		if not comments_list:
			r = re.compile(b'var MOVIE_ID\s*?=\s*?(\d+?);',re.S).search(data)
			if r: m_id = _de3(r.group(1))
			c = p.find('div', id='comments-count')
			if c:
				count_comments = c.text.split(' ')[0].strip()
				if count_comments == '0': count_comments = None

	page = {'max': 1, 'current': 1, 'next': None, 'prev': None}
	return {'data': content_list, 'page': page, 'podbor2': podbor_list, 'comments': comments_list,
		'movie_id':m_id, 'count_comments':count_comments}

def pars_comments(data):
	from bs4 import BeautifulSoup
#	if not PY2: data = b'<html>' + data + b'</html>'
	soup = BeautifulSoup(data, 'html.parser', from_encoding='utf8')
	from xbmcup.html import Clear
	comments_list = []
	for i in soup.findAll('div', 'media'):
		comments_list.append( ( i.find('div', 'media-heading').text , Clear().text(i.find('p', 'text').text) ) )
	return comments_list

def vtt_to_srt(fileContents):
	replacement = re.sub(b'(\d\d:\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n', b'\\1,\\2 --> \\3,\\4\n', fileContents)
	replacement = re.sub(b'(\d\d:\d\d).(\d\d\d) --> (\d\d:\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n', b'00:\\1,\\2 --> 00:\\3,\\4\n', replacement)
	replacement = re.sub(b'(\d\d).(\d\d\d) --> (\d\d).(\d\d\d)(?:[ \-\w]+:[\w\%\d:]+)*\n', b'00:00:\\1,\\2 --> 00:00:\\3,\\4\n', replacement)
	replacement = re.sub(b'WEBVTT\n', b'', replacement)
	replacement = re.sub(b'Kind:[ \-\w]+\n', b'', replacement)
	replacement = re.sub(b'Language:[ \-\w]+\n', b'', replacement)
	#replacement = re.sub(r'^\d+\n', '', replacement)
	#replacement = re.sub(r'\n\d+\n', '\n', replacement)
	replacement = re.sub(b'<c[.\w\d]*>', b'', replacement)
	replacement = re.sub(b'</c>', b'', replacement)
	replacement = re.sub(b'<\d\d:\d\d:\d\d.\d\d\d>', b'', replacement)
	replacement = re.sub(b'::[\-\w]+\([\-.\w\d]+\)[ ]*{[.,:;\(\) \-\w\d]+\n }\n', b'', replacement)
	replacement = re.sub(b'Style:\n##\n', b'', replacement)
	id = 1
	out = b''
	for i in replacement.splitlines():
		if i == b'':
			if id == 1:
				out = out + _en3(str(id)) + b'\n'
			else:
				out = out + b'\n' + _en3(str(id)) + b'\n'
			id += 1
		else:
			out = out + i + b'\n'
	return out

def qurl(url, quality=_quality_):
			urls = url.split(',[')
			listurls = {}
			gl = []
			for i in urls:
				d = i.replace('[','').split(']')
				if '4K' in d[0]: d[0] = '4000'
				elif 'p' in d[0]: d[0] = d[0].strip('p')
				listurls[str(d[0])] = d[1]
				gl.append( (int(d[0]), d[1]) )
			#print listurls
			gl.sort()
			#print gl
			qprev = 0
			for i in gl:
				if int(i[0]) > int(quality):
					q = qprev
					break
				qprev = i[0]
				q = i[0]
			url = listurls[str(q)]
			return url

def turl(url):
	turls = url.split(';{')
	list_trans = []
	index = 0
	for i in turls:
		url = i.split('}')[1]
		name = i.split('}')[0].strip('{')
		list_trans.append( (name.decode('utf8') if PY2 else name, url, None, index) )
		index += 1
	return list_trans

def surl(url):
	surls = url.split(',[')
	list_subt = []
	for i in surls:
		url = i.split(']')[1]
		list_subt.append( url )
	return list_subt

def ourl(url):
	ourls = url.split(';{')
	dict_trans = {}
	for i in ourls:
		url = i.split('}')[1]
		trans = i.split('}')[0].strip('{').decode('unicode-escape') if PY2 else i.split('}')[0].strip('{')
		dict_trans[trans] = url
	return dict_trans

def pars_seria(data):
	lurls = eval(data)
	list_seria = []
	index = 0
	for i in lurls:
		sezon_name = i.get('comment', i['title'])
		if 'playlist' in i:
			for j in i['playlist']:
				seria_num = j.get('comment', j['title'])
				url = j['file']
				if '[' in url:
					url = qurl(url)
				if ';{' in url:
					url = ourl(url)
				subt = j['subtitle']
				if subt:
					suburl = surl(subt)
				else: suburl = None
				name = sezon_name + ' / ' + seria_num
				list_seria.append( (name.decode('unicode-escape') if PY2 else name, url, suburl, index) )
				index += 1
		else:
			url = i['file']
			if '[' in url:
				url = qurl(url)
			if ';{' in url:
				url = ourl(url)
			subt = i['subtitle']
			if subt:
				suburl = surl(subt)
			else: suburl = None
			list_seria.append( (sezon_name.decode('unicode-escape') if PY2 else sezon_name, url, suburl, index) )
			index += 1
	return list_seria

def pars_play(data, quality=_quality_):
	t = re.compile(b'(<div class="one-video" id="trailer">)',re.S).search(data)
	if t:
		t = re.compile(b'<iframe class="embed-responsive-item" src="https://www.youtube.com/embed/([^"]+?)" allowfullscreen></iframe>',re.S).search(data)
		if t: y_id = _de3(t.group(1))
		return 'plugin://plugin.video.youtube/play/?video_id=' + y_id, None
	r = re.compile(b'var MOVIE_ID\s*?=\s*?(\d+?);',re.S).search(data)
	if r: m_id = _de3(r.group(1))
	#print m_id
#	r = re.compile(b'var VOD_HASH\s*?=\s*?"(.+?)";',re.S).search(data)
#	if r: v_hash = r.group(1)
	#print v_hash
#	r = re.compile(b'var VOD_TIME\s*?=\s*?"(.+?)";',re.S).search(data)
#	if r: v_time = r.group(1)
	#print v_time
	r = re.compile(b'var PLAYER_CUID\s*?=\s*?"(.+?)";',re.S).search(data)
	if r: player_cuid = r.group(1)
	r = re.compile(b'var IDENTIFIER\s*?=\s*?"(.+?)";',re.S).search(data)
	if r: identifier = r.group(1)
	#print identifier
	param = {'page':'movie', 'movie_id':m_id, 'cuid':player_cuid, 'device':'DESKTOP', '_':int(time.time())}
	jsdata = getUrl(site_url+'/user_data''?'+urlencode(param) )
#	open('/home/osmc/kinovod-data3.txt', 'wb').write(jsdata)
#	jsdata= open('/home/osmc/kinovod-data3.txt', 'rb').read()
	v_hash = v_time = None
	jsdata = _de3(jsdata)
#	print(jsdata)
	if jsdata.find('"vod_time":') and jsdata.find('"vod_hash":"'):
		try:
			import json
			jsp = json.loads(jsdata)
			v_time = jsp['vod_time']
			v_hash = jsp['vod_hash']
		except Exception as e:
			if _kodi_:
				from xbmcup.errors import log
				log(jsdata, 'jsdata=')
				log(e, 'Kinovod json error')
			else: raise
	if not v_hash or not v_time:
		try:
			from kdecoder import KinovodDecoder
			kino = KinovodDecoder()
			v_hash, v_time = kino.get_private_data(jsdata)
			del kino
		except Exception as e:
			if _kodi_:
				from xbmcup.errors import log
				log(jsdata, 'jsdata=')
				log(e, 'KinovodDecoder error')
			else: raise
	if not v_hash or not v_time:
		try:
			import js2py
			js = js2py.EvalJs()
			js.eval(jsdata)
			v_hash = js.private_vod_hash
			v_time = js.private_vod_time
		except Exception as e:
			if _kodi_:
				from xbmcup.errors import log
				log(jsdata, 'jsdata=')
				log(e)
			else: raise
	param = {'identifier': identifier, 'st': v_hash, 'e': v_time, 'file_type': 'hls', 'player_type': 'new'}
	#print(param)
	data2 = getUrl(site_url+'/vod/'+m_id+'?'+urlencode(param) )
	#print data2
	#open('/home/osmc/kinovod-data.txt', 'wb').write(data2)
	#data2 = open('/home/osmc/kinovod-data.txt', 'rb').read()
	if data2:
		subtitles = None
		if data2.startswith(b'file|'):
			data3 = data2.split(b'file|')[1].split(b'|')[0]
			url = qurl(_de3(data3))
			if ';{' in url:
				url = turl(url)
			data4 = data2.split(b'|')[2]
			if data4:
				subtitles = surl(_de3(data4))
		elif data2.startswith(b'pl|'):
			data2 = data2.split(b'pl|')[1].split(b'|')[0]
			url = pars_seria(data2.replace(b'\/',b'/'))
	return url , subtitles

def set_url(url):
	if _video_ > 0 and (url.find('/films') == 0 or url.find('/animation') == 0):
		d = '?'
		if url.find('?') > 0: d = '&'
		if not re.compile('[\?&]video=').search(url):
			url = url.replace(d+'video=license','').replace(d+'video=normal','')
			if _video_ == 1: url += d+'video=license'
			if _video_ == 2: url += d+'video=normal'
	return url

def catalog(url=site_url):
	if not url: url = site_url
	url = set_url(url)
	rurl, data = getUrl(n_u(url), rurl=True)
	#open('/home/osmc/catalog.txt', 'wb').write( data )
	return pars2(data, rurl=rurl)

def startpage():
	data = getUrl(site_url)
	return pars(data)

def genre():
	data = getUrl(site_url)
	return pars(data)


def videoinfo(url):
	data = getUrl(n_u(url))
	#open('/home/osmc/kinovod.txt', 'wb').write( data )
	res = pars3(data)
	res['url'] = pars_play(data)[0]
	return res

def search(text):
	if isinstance(text, unicode): text = _en(text)
	url, data = getUrl(site_url+'/search?'+urlencode({'query': text}), rurl=True)
	#open('/home/osmc/search.txt', 'wb').write( data )
	urlc = url[url.find('://'):]
	#if urlc.startswith((site_url[site_url.find('://'):]+'/search?').lower()):
	if '/search?' in urlc:
		return False, pars2(data, False)
	else:
		return True, pars3(data)

def comments(movie_id, page=1):
	data = getUrl(site_url+'/comments?'+urlencode({'movie_id':movie_id, 'page':page}))
	return pars_comments(data)

def subt_convert(subtlist, subtitleson=_subtitles_):
	if subtitleson and subtlist:
		subt_list = []
		for i in subtlist:
				if '.vtt' in i:
					name = i.split('/')[-1].replace('.vtt','.srt')
					isu = i
					if ' or ' in i: isu = i.split(' or ')[randindex]
					data_vtt = getUrl(isu)
					data_srt = vtt_to_srt(data_vtt)
					if _kodi_:
						from xbmcup.app import Handler
						sdir = Handler().path('srt')
						if not os.path.isdir(sdir): os.mkdir(sdir)
						f_name = Handler().path('srt', name)
					else:
						f_name = name
					open(f_name, 'wb').write(data_srt)
					subt_list.append( f_name )
				else:
					subt_list.append( i )
		return subt_list
	else:
		return None

def play_link2(url, index=None):
	try:
		from xbmcup.errors import log
		log(url,'url=')
	except: pass
	data = getUrl(n_u(url))
	#open('/home/osmc/z2-kinovod.net.txt', 'wb').write(data)
	d_play = pars_play(data)
	try:
		from xbmcup.errors import log
		log(d_play,'d_play=')
	except: pass
	if index or index == 0:
		if d_play[1]:
			return [ d_play[0][index][1], subt_convert( d_play[1] ) ], None
		return [ d_play[0][index][1], subt_convert( d_play[0][index][2] ) ], None
	else:
		if d_play[1]:
			return [d_play[0], subt_convert(d_play[1]) ], None
		return d_play, None


def play_link(url, index=None, perevod=None):
	d = play_link2(url, index)
	if perevod:
		if ' or ' in d[0][0][perevod]:
			return ( d[0][0][perevod].split(' or ')[randindex], d[0][1] ), d[1]
		return ( d[0][0][perevod], d[0][1] ), d[1]
	if ' or ' in d[0][0]:
		return ( d[0][0].split(' or ')[randindex], d[0][1] ), d[1]
	return d

if __name__ == '__main__':

	data = open('/home/osmc/kinovod.txt', 'rb').read()
	#print pars_play(data)
	#print(play_link('/film/43176-tihoe-mesto-2'))

	#print(videoinfo('/film/43176-tihoe-mesto-2'))
	#print(videoinfo('/serial/158246-igra-prestolov'))
	#print(videoinfo('/serial/40265-rik-i-morti'))
	#print(len(videoinfo('/film/518-terminator-2-sudnyj-den')))
	print(pars_play(data))
	#print(search('место'))
	#print(search('побег из шоушенка'))
	#print((comments(194107)))
	#print(catalog('/films')['filter'])
	pass

