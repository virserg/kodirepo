# -*- coding: utf-8 -*-
# Eviloid

import re

class KinovodDecoder():
    @staticmethod
    def __decode_hunter(h, u, n, t, e, r):
        def decode(d, e, f):
            g = list('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/')
            h = g[:e]
            i = g[:f]
            j = list(d)
            j.reverse()

            a = 0
            for c, b in enumerate(j):
                if b in h:
                    a = a + h.index(b) * pow(e, c) 

            j = a
        
            k = ''
            while j > 0:
                k = i[j % f] + k
                j = (j - (j % f)) // f

            return int(k or 0)

        r = ''
        s = ''
        for i in list(h):
            if i != n[e]:
                s = s + i
            else:
                for j, m in enumerate(list(n)):
                    s = s.replace(m, str(j))
                r = r + chr(decode(s, e, 10) - t)
                s = ''

        return r

    @classmethod
    def get_private_data(cls, html):
        vod_hash = ''
        vod_time = ''

        p = re.search(r'escape\(r\)\)}\("(.+?)",(\d+),"(.+?)",(\d+),(\d+),(\d+)\)\)', html)
        if p:
            text = cls.__decode_hunter(p.group(1), int(p.group(2)), p.group(3), int(p.group(4)), int(p.group(5)), p.group(6))
            vod_hash   = re.search(r'_vod_hash = "(.+)";', text).group(1)
            vod_time   = re.search(r'_vod_time = "(\d+)";', text).group(1)

        return vod_hash, vod_time


if __name__ == '__main__':

    from urllib.request import Request, urlopen
    from urllib.parse import urlencode

    def get_html(url, params=None, headers={}):
        USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36'

        headers['User-Agent'] = headers.get('User-Agent') or USER_AGENT
        if params:
            url = '%s?%s' % (url, urlencode(params))
        conn = urlopen(Request(url, headers=headers))
        data = conn.read()
        conn.close()
        if conn.headers.get_content_charset():
            data = data.decode(conn.headers.get_content_charset())
        if isinstance(data, bytes):
            data = data.decode('utf-8')
        return data 


    BASE_URL = 'https://kinovod.net'

    html = get_html('{}/film/143864-betmen'.format(BASE_URL))

    movie_id    = re.search(r'var MOVIE_ID = (\d+);', html).group(1)
    cuid        = re.search(r'var PLAYER_CUID = "(.+)";', html).group(1)
    identifier  = re.search(r'var IDENTIFIER = "(.+)";', html).group(1)

    params = {'page'        :'movie',
              'movie_id'    :movie_id,
              'cuid'        :cuid,
              'device'      :'DESKTOP'
             }

    html = get_html('{}/user_data'.format(BASE_URL), params=params)

    kino = KinovodDecoder()
    user_vod_hash, user_vod_time = kino.get_private_data(html)

    params = {'identifier'  :identifier,
              'player_type' :'new',
              'file_type'   :'hls',
              'st'          :user_vod_hash,
              'e'           :user_vod_time
             }

    html = get_html('{0}/vod/{1}'.format(BASE_URL, movie_id), params=params)

    files = re.findall(r'(\[\w+\])(.*?\.m3u8)[,\|]', html)

    uri = ''

    for p in ['1080', '720', '360']:
        for f in files:
            if p in f[0]:
                uri = f[1].split(' or ')[0]
                break
        else:
            continue
        break 

    if uri:
        from subprocess import Popen
        proc = Popen([r'C:/ProgramData/VLC/vlc.exe', uri.replace(r'\/', '/')])
        proc.wait()
