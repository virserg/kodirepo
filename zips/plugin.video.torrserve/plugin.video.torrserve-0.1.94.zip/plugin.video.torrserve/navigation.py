pf = False
if pf:
   import cProfile
   pr = cProfile.Profile()
   pr.enable()

import os
import sys
import gc
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'site-packages', 'torrserve'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'site-packages', 'searcher'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'site-packages'))
from torrserve import navigation

navigation.run()

if pf:
   pr.disable()
   pr.dump_stats('/home/osmc/torrserver_client_stats')

gc.collect()
try: sys.modules.clear()
except: pass
