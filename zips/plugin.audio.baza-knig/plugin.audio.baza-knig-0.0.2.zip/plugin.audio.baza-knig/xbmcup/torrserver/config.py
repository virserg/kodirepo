import os
import sys

TORRSERVED_HOST = "http://127.0.0.1:8090"

def init():
    global TORRSERVED_HOST

    try:
        import xbmcaddon
        ADDON = xbmcaddon.Addon()

        if ADDON.getSetting("torrserver_host") and ADDON.getSetting("torrserver_port"):
           TORRSERVED_HOST = "http://"+ADDON.getSetting("torrserver_host")+":"+ADDON.getSetting("torrserver_port")
    except:
        pass


init()
