#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib,urllib2,re,sys,os,random
import xbmcplugin,xbmcgui,xbmcaddon
import time
import kvu

addon = xbmcaddon.Addon(id='plugin.audio.knigavuhe')
pluginhandle = int(sys.argv[1])
thumb = os.path.join( addon.getAddonInfo('path'), 'icon.png')
xbmcplugin.setContent(int(sys.argv[1]), 'artists')
__settings__ = xbmcaddon.Addon(id='plugin.audio.knigavuhe')

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""

def showMessage(heading, message, times = 3000):
	heading = heading.encode('utf-8')
	message = message.encode('utf-8')
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, thumb))


def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param



def getURL(url,Referer = 'http://www.mds-fm.ru/'):
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
	req.add_header('Accept', 'text/html, application/xml, application/xhtml+xml, */*')
	req.add_header('Accept-Language', 'ru,en;q=0.9')
	req.add_header('Referer', Referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link


def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2


def Format(t):
	try:
		author, title = eval("('"+t.replace(". ","','")+"')")
		title = "[COLOR F050F050]"+t.replace(". ","[/COLOR]  ")
	except:
		print t
		try: 
			t=t.replace("-","— ")
			t=t.replace("«","— «")
			author, title = eval("('"+t.replace("— ","','")+"')")
			title = "[COLOR F050F050]"+t.replace("— ","[/COLOR]  ")
		except: 
			title =t

	#nt= "[COLOR F050F050]"+"[--------------  «Fileek.com»  "+qury+" --------------]"+"[/COLOR]"
	return title

def Root():
				title="Найти книгу"
				url=""
				img=thumb
				uri = sys.argv[0] + '?mode=seach_books'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
				
				title="Найти автора"
				url=""
				img=thumb
				uri = sys.argv[0] + '?mode=seach_authors'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
				
				title="Авторы"
				url=""
				img=thumb
				uri = sys.argv[0] + '?mode=authors'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
				
				title="Жанры"
				url=""
				img=thumb
				uri = sys.argv[0] + '?mode=genres'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
				
				title="Исполнители"
				url=""
				img=thumb
				uri = sys.argv[0] + '?mode=plot'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
				'''
				title="Место действия"
				url=""
				img=thumb
				uri = sys.argv[0] + '?mode=scene'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
				
				title="Время действия"
				url=""
				img=thumb
				uri = sys.argv[0] + '?mode=time'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
				'''
				xbmcplugin.endOfDirectory(pluginhandle)

def Authors(p=1):
	try: pn=p+1
	except: pn=2
	L=kvu.get_autors(p)
	#{'author_id': author_id, 'author': author, 'book_count': book_count}
	for i in L:
				id=i['author_id']
				author=i['author']
				count=i['book_count']
				url="https://m.knigavuhe.org/author/"+id
				title = author+' ['+count+']'
				img=thumb
				uri = sys.argv[0] + '?mode=books'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title, 'author': author})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)

	uri = sys.argv[0] + '?mode=authors'
	uri += '&url='  + urllib.quote_plus(str(pn))
	uri += '&name='  + urllib.quote_plus('далее >')
	uri += '&img='  + urllib.quote_plus(thumb)
	item = xbmcgui.ListItem('далее >', iconImage = thumb, thumbnailImage = thumb)
	item.setInfo(type="Music", infoLabels={"Title": 'далее >'})
	xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
	
	xbmcplugin.endOfDirectory(pluginhandle)

def Title():
	q=inputbox().replace(" ","%20")
	Lt=[]
	for n in range (1,5):
		url='http://mds-fm.ru/search/node/'+q
		if n>0: url=url+"?page="+str(n)
		http=getURL(url)
		ss='<li class="search-result">'
		es='</ol>'
		try:
			c1=mfindal(http, ss, es)[0]
			ss='<a href="'
			es='</a>'
			L=mfindal(c1, ss, es)
		except:
			L=[]
		for i in L:
				url, title = eval(i.replace('<a href="','("').replace('">','", "')+'")')
				img=thumb
				uri = sys.argv[0] + '?mode=serch'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(Format(title), iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title})
				if url not in Lt:
					xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
					Lt.append(url)
				
	xbmcplugin.endOfDirectory(pluginhandle)



def Genres():
		L=kvu.get_genres()
		#{'genre_id': genre_id, 'genre': genre, 'book_count': book_count}
		for i in L:
				id=i['genre_id']
				genre=i['genre']
				count=i['book_count']
				url="https://m.knigavuhe.org/genre/"+id
				title = genre+' ['+count+']'
				img=thumb
				uri = sys.argv[0] + '?mode=books'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title, 'genre': genre})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
		xbmcplugin.endOfDirectory(pluginhandle)

def Books(url):
	if '/?pn=1' not in url: 
		p=1
		url=url+'/1/?pn=1'
	else:
		try:
			tmp=url.replace('/?pn=1','')
			p=int(tmp[tmp.rfind('/')+1:])
		except:
			p=1
	tmp=url.replace('/?pn=1','')
	next=tmp[:tmp.rfind('/')+1]+str(p+1)+'/?pn=1'
	L=kvu.get_books(url)
	#{'book_id':book_id, 'cover': cover, 'title': title, 'duration': duration, 'genre_id': genre_id, 'genre': genre, 'author_id': author_id, 'author': author, 'reader_id': reader_id, 'reader': reader}
	for i in L:
				if '">' not in i['author']:
					title = i['title']+' ( '+i['author']+' )'
				else: 
					title = i['title']
				uri = sys.argv[0] + '?mode=chapters'
				uri += '&url='  + urllib.quote_plus(i['book_id'])
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(i['cover'])
				item = xbmcgui.ListItem(title, iconImage = i['cover'], thumbnailImage = i['cover'])
				item.setInfo(type="Music", infoLabels={"Title": title, 'genre': "i['genre']", 'artist':i['author'], 'comment':'plot'})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
	
	uri = sys.argv[0] + '?mode=books'
	uri += '&url='  + urllib.quote_plus(next)
	uri += '&name='  + urllib.quote_plus('далее >')
	uri += '&img='  + urllib.quote_plus(thumb)
	item = xbmcgui.ListItem('далее >', iconImage = thumb, thumbnailImage = thumb)
	item.setInfo(type="Music", infoLabels={"Title": 'далее >'})
	xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
	
	xbmcplugin.endOfDirectory(pluginhandle)


def Chapters(id):
	L=kvu.get_chapters(id)
	for i in L:
		title = i['title']#+' ( '+str(i['duration'])+' )'
		item = xbmcgui.ListItem(title, iconImage = i['cover'], thumbnailImage = i['cover'])
		item.setInfo(type="Music", infoLabels={"Title": title, 'duration':i['duration']})
		xbmcplugin.addDirectoryItem(pluginhandle, i['url']+'?f=1', item, False)
	
	xbmcplugin.endOfDirectory(pluginhandle)


def Serch_B():
	q=inputbox()
	if q!='':
		L=kvu.seach_books(q)
		
		for i in L:
				if '">' not in i['author']:
					title = i['title']+' ( '+i['author']+' )'
				else: 
					title = i['title']
				uri = sys.argv[0] + '?mode=chapters'
				uri += '&url='  + urllib.quote_plus(i['book_id'])
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(i['cover'])
				item = xbmcgui.ListItem(title, iconImage = i['cover'], thumbnailImage = i['cover'])
				item.setInfo(type="Music", infoLabels={"Title": title, 'genre': "i['genre']", 'artist':i['author'], 'comment':'plot'})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
	
	xbmcplugin.endOfDirectory(pluginhandle)



def Serch_A():
	q=inputbox()
	if q!='':
		L=kvu.seach_authors(q)
		for i in L:
				id=i['author_id']
				author=i['author']
				count=i['book_count']
				url="https://m.knigavuhe.org/author/"+id
				title = author+' ['+count+']'
				img=thumb
				uri = sys.argv[0] + '?mode=books'
				uri += '&url='  + urllib.quote_plus(url)
				uri += '&name='  + urllib.quote_plus(title)
				uri += '&img='  + urllib.quote_plus(img)
				item = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
				item.setInfo(type="Music", infoLabels={"Title": title, 'author': author})
				xbmcplugin.addDirectoryItem(pluginhandle, uri, item, True)
				
	xbmcplugin.endOfDirectory(pluginhandle)




params = get_params()
url  =	''
mode =	None
name =	''
img =	' '

try: url = urllib.unquote_plus(params["url"])
except: pass
try: mode = urllib.unquote_plus(params["mode"])
except: pass
try: name = urllib.unquote_plus(params["name"])
except: pass
try: img = urllib.unquote_plus(params["img"])
except: pass



if   mode == None:				Root()
elif mode == 'seach_books':		Serch_B()
elif mode == 'seach_authors':	Serch_A()
elif mode == 'genres':			Genres()
elif mode == 'chapters':		Chapters(url)
elif mode == 'books':			Books(url)
elif mode == 'authors':			Authors(url)

