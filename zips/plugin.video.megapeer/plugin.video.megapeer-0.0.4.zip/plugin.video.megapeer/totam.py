# -*- coding: utf-8 -*-
import urllib

import xbmc

from xbmcup.errors import log

def opentam(uri):
        log('start - opentam')
        fanart = xbmc.getInfoLabel('ListItem.Art(fanart)').decode('utf8')
        if 'http://' in fanart: pass
        elif 'https://' in fanart: pass
        else: fanart = None
        info = { 'cover': xbmc.getInfoLabel('ListItem.Art(thumb)').decode('utf8'),
        'fanart': fanart,
        'icon': None,
        'title': xbmc.getInfoLabel('ListItem.Title').decode('utf8'),
        'originaltitle': xbmc.getInfoLabel('ListItem.OriginalTitle').decode('utf8'),
        'year': xbmc.getInfoLabel('ListItem.Year').decode('utf8'),
        'premiered': xbmc.getInfoLabel('ListItem.Premiered').decode('utf8').replace(u'.',u'-'),
        'genre': xbmc.getInfoLabel('ListItem.Genre').decode('utf8'),
        'director': xbmc.getInfoLabel('ListItem.Director').decode('utf8'),
        'rating': xbmc.getInfoLabel('ListItem.Rating').decode('utf8'),
        'votes': xbmc.getInfoLabel('ListItem.Votes').decode('utf8').replace(u',',u''),
        'mpaa': xbmc.getInfoLabel('ListItem.Mpaa').decode('utf8'),
        'cast': xbmc.getInfoLabel('ListItem.Cast').decode('utf8').split(u'\n'),
        'castandrole': [(i.split(u' в роли ')) for i in xbmc.getInfoLabel('ListItem.CastAndRole').decode('utf8').split(u'\n') if i],
        'studio': xbmc.getInfoLabel('ListItem.Studio').decode('utf8'),
        'trailer': xbmc.getInfoLabel('ListItem.Trailer').decode('utf8'),
        'writer': xbmc.getInfoLabel('ListItem.Writer').decode('utf8'),
        'tagline': xbmc.getInfoLabel('ListItem.Tagline').decode('utf8'),
        'plot': xbmc.getInfoLabel('ListItem.Plot').decode('utf8'),
        'code': xbmc.getInfoLabel('ListItem.IMDBNumber').decode('utf8'),
        'plotoutline': xbmc.getInfoLabel('ListItem.PlotOutline').decode('utf8'),
        'mediatype': 'movie' # fix android info
        }
        log(info)
        infoout = {}
        for i in info:
              if info[i] and info[i] != ['']:
                  if not (i == 'votes' and info[i] == u'0'):
                        if isinstance(info[i], basestring):
                             infoout[i] = info[i].replace('|', '#') #fix bug in TAM
                        else:
                             infoout[i] = info[i]
        purl = "?mode=open&url="+ urllib.quote_plus(uri)+"&info="+ urllib.quote_plus(repr(infoout))
        log('try - xbmc.executebuiltin("Container.Update(plugin://plugin.video.tam/%s"))' %purl)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.tam/%s)' %purl)
        log('end - opentam')
        return True
