# -*- coding: utf-8 -*-

# SPDX-License-Identifier: GPL-2.0-or-later

import sys
PY2 = sys.version_info.major == 2
import xbmc
import xbmcaddon
import xbmcgui
import json
if PY2:
    from xbmc import translatePath
else:
    from xbmcvfs import translatePath

__author__ = 'AlexELEC, virserg'
__scriptid__ = 'script.key.layout.osmc'
__addon__ = xbmcaddon.Addon(id=__scriptid__)
__cwd__ = __addon__.getAddonInfo('path')

def notify(message):
    xbmcgui.Dialog().notification("Клавиатура", message, "%s/icon.png" % __cwd__, 3000, False)

def installkey():
    is_install = bool(__addon__.getSetting('is_install') == 'false')
    if is_install:
         import os
         f_xml = translatePath('special://home/userdata/keymaps/keyboard.xml')
         if not os.path.isfile(f_xml): f_xml2='/usr/share/kodi/system/keymaps/keyboard.xml'
         else: f_xml2 = f_xml
         data = open(f_xml2, 'r').read()
         d = data.splitlines()
         ins_line = '<space mod="ctrl">RunAddon(script.key.layout.osmc)</space>'
         for i in range(len(d)):
             if '<global>' in d[i] and '<keyboard>' in d[i+1]:
                if ins_line not in d[i+2]:
                        space_symb = d[i+2][:d[i+2].find('<')]
                        d.insert(i+2, space_symb+ins_line)
                        data2 = '\n'.join(d)
                        open(f_xml, 'w').write(data2+'\n')
                break
         __addon__.setSetting('is_install', 'true')
         xbmcgui.Dialog().ok('Аппаратная раскладка клавиатуры', 'Для переключения языка нажмите клавиши <ctrl>+<space>.\nПожалуйста, перезагрузите Kodi для применения клавиш.')
         return False
    return True

def jsonrpc(kodi_json):
    xbmc.sleep(200)
    request = xbmc.executeJSONRPC(json.dumps(kodi_json).encode("utf-8") if PY2 else json.dumps(kodi_json))
    return json.loads(request.decode('utf-8', 'replace') if PY2 else request)

def main():
    kodi_json = {}
    params = {}
    params["setting"] = "input.libinputkeyboardlayout"
    kodi_json["jsonrpc"] = "2.0"
    kodi_json["method"] = "Settings.GetSettingValue"
    kodi_json["params"] = params
    kodi_json["id"] = 1

    response = jsonrpc(kodi_json)

    if 'result' in response:
        kodi_json["method"] = "Settings.SetSettingValue"
        if response['result']['value'] == 'us':
            params["value"] = "ru"
            response = jsonrpc(kodi_json)
            if response['result']:
                notify("раскладка: Русская (RU)")
            else:
                notify("Ошибка установки раскладки!")
        else:
            params["value"] = "us"
            response = jsonrpc(kodi_json)
            if response['result']:
                notify("раскладка: English (US)")
            else:
                notify("Ошибка установки раскладки!")

if (__name__ == '__main__'):
   if installkey() and xbmcgui.Window(10000).getProperty('keyrun') != 'true':
       xbmcgui.Window(10000).setProperty('keyrun', 'true')
       main()
       xbmcgui.Window(10000).clearProperty('keyrun')
