# -*- coding: utf-8 -*-

# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2011-present Alex@ELEC (http://alexelec.in.ua)

import xbmc
import xbmcaddon
import json

__author__ = 'AlexELEC, virserg'
__scriptid__ = 'script.key.layout.osmc'
__addon__ = xbmcaddon.Addon(id=__scriptid__)
__cwd__ = __addon__.getAddonInfo('path')

def notify(message):
    xbmc.executebuiltin('Notification("Keybord", "%s", 5000, "%s/icon.png")' % (message, __cwd__))

def installkey():
    is_install = bool(__addon__.getSetting('is_install') == 'false')
    if is_install:
         import xbmcgui
         import os
         f_xml = xbmc.translatePath('special://home/userdata/keymaps/keyboard.xml')
         if not os.path.isfile(f_xml): f_xml2='/usr/share/kodi/system/keymaps/keyboard.xml'
         else: f_xml2 = f_xml
         data = file(f_xml2, 'rb').read()
         d = data.splitlines()
         ins_line = '<space mod="ctrl">RunAddon(script.key.layout.osmc)</space>'
         for i in range(len(d)):
             if '<global>' in d[i] and '<keyboard>' in d[i+1]:
		if ins_line not in d[i+2]:
			space_symb = d[i+2][:d[i+2].find('<')]
			d.insert(i+2, space_symb+ins_line)
			data2 = '\n'.join(d)
			file(f_xml, 'wb').write(data2+'\n')
		break
         __addon__.setSetting('is_install', 'true')
         xbmcgui.Dialog().ok('Hardware Keyboard Layout', 'To switch language press <ctrl>+<space> keys.', 'Please reboot Kodi for apply keys.')
         return False
    return True

def main():
    kodi_json = {}
    params = {}
    params["setting"] = "input.libinputkeyboardlayout"
    kodi_json["jsonrpc"] = "2.0"
    kodi_json["method"] = "Settings.GetSettingValue"
    kodi_json["params"] = params
    kodi_json["id"] = 1

    request = xbmc.executeJSONRPC(json.dumps(kodi_json).encode("utf-8"))
    response = json.loads(request.decode('utf-8', 'replace'))

    if 'result' in response:
        kodi_json["method"] = "Settings.SetSettingValue"
        if response['result']['value'] == 'us':
            params["value"] = "ru"
            request = xbmc.executeJSONRPC(json.dumps(kodi_json).encode("utf-8"))
            response = json.loads(request.decode('utf-8', 'replace'))
            if response['result']:
                notify("set keyboard layout: Russian (RU)")
            else:
                notify("Error set keyboard layout!")
        else:
            params["value"] = "us"
            request = xbmc.executeJSONRPC(json.dumps(kodi_json).encode("utf-8"))
            response = json.loads(request.decode('utf-8', 'replace'))
            if response['result']:
                notify("set keyboard layout: English (US)")
            else:
                notify("Error set keyboard layout!")

if (__name__ == '__main__'):
   if installkey():
       main()
