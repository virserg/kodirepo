# -*- coding: utf-8 -*-

import os, sys

import xbmc, xbmcplugin, xbmcgui

from xbmcup.app import Link, Handler, Plugin, _setting
import knizhkin
from history import History, HistoryAdd

_view_ = _setting['view']

plugin = Plugin()

@plugin.radd()
class Menu(Handler):
	def handle(self):
		self.item(Link('catalog',{'search': True}), title='[Поиск]')
		self.item(Link('history'), title='[История поиска]')
		self.item(Link(Catalog), title='Каталог книг')
		self.item(Link(Authors), title='Авторы')
		self.item(Link(Readers), title='Исполнители')
		self.item(Link(Genres), title='Жанры')
		self.render(nextmode=_view_)

@plugin.radd()
class Authors(Handler):
	def handle(self):
		data = knizhkin.authors()
		for i in data['data']:
			self.item(Link(ARrezult,{'url': i[1]}), title=i[0])
		self.render(nextmode=_view_)

@plugin.radd()
class Readers(Handler):
	def handle(self):
		data = knizhkin.readers()
		for i in data['data']:
			self.item(Link(ARrezult,{'url': i[1]}), title=i[0])
		self.render(nextmode=_view_)

@plugin.radd()
class ARrezult(Handler):
	def handle(self):
		url = self.argv.get('url')
		data = knizhkin.ar_rezult(url)
		for i in data['data']:
			self.item(Link(Catalog,{'url': i[1]}), title=i[0])
		self.render(nextmode=_view_)

@plugin.radd()
class Genres(Handler):
	def handle(self):
		data = knizhkin.genres()
		for i in data['genres']:
			self.item(Link('catalog',{'url': i[1]}), title=i[0])
		self.render(nextmode=_view_)

@plugin.radd()
class Catalog(Handler):
	def handle(self):
		search = self.argv.get('search')
		url = self.argv.get('url')
		s_kbd = self.argv.get('s_kbd', False)
		sort = self.argv.get('sort')
		data = self.argv.get('data', None)
		page = self.argv.get('page')
		if sort:
			index = xbmcgui.Dialog().select(self.nameaddon, [x[0] for x in sort])
			if index < 0:
				return True
			else:
				url = sort[index][1]
		if page and search:
			s1, data = knizhkin.nextsearch(search, page)
		elif search:
			if isinstance(search, bool):
				textsearch = self.argv.get('textsearch', '')
				search = self.kbdinput('Поиск', textsearch)
				if search is None: return True
				s_kbd = True
				HistoryAdd(search)
			s1, data = knizhkin.search(search)
		elif url == 0:
			return True
		elif data is None:
			data = knizhkin.catalog(url)
		if (data['data']==[]) and s_kbd and (data['podbor'] ==[]):
			xbmcgui.Dialog().ok(self.nameaddon, 'Ничего не найдено')
		if data.get('filter'):
			for i in data['filter']:
				self.item(Link('catalog', {'sort': i['sort']}), title=i['name'], media='video', popup=self.popup, popup_replace=True)
		for i in data['data']:
			popup = []
			popup.extend(self.popup)
			title = i['info']['title']
			popup.insert(1, (Link('catalog', {'search': True, 'textsearch': title}, True), 'Поиск') )
			if i['info'].get('plotoutline'):
				title = title + u' (' + i['yq'] + u', ' + i['info']['plotoutline'] + u')'
			else:
				title = title + u' (' + i['yq'] + u')'
			if i['info'].get('rating'):
				title = title + u' [' + unicode(i['info']['rating']) + u']'
			self.item(Link('video', {'url': i['url']}), title=title, media='music', info=i['info'], thumb=i['thumb'], popup=popup, popup_replace=True)
		for i in data['podbor']:
			self.item(Link('catalog', {'url': i['url']}), title=i['info']['title'], media='music', info=i['info'], thumb=i['thumb'], popup=self.popup, popup_replace=True)
		if data['page']['next']:
			titlepage = 'Следующая страница '+ str(data['page']['current']+1)+ ' из ' + str(data['page']['max']) + ' >>'
			if data['page']['next'] == '#':
				self.item(Link('catalog',{'page':data['page']['snext'], 'search': search}), title=titlepage)
			else:
				self.item(Link('catalog',{'url':data['page']['next']}), title=titlepage)
		self.render(nextmode=_view_)


@plugin.radd()
class Video(Handler):
	def handle(self):
		url = self.argv.get('url')
		if url == 0:
			return True
		d = knizhkin.videoinfo(url)
		data = d['data'][0]
		title = data['info']['title']
		info = data['info']
		if data.get('screenshot'): self.popupadd(Link('screenshot', data['screenshot']), 'Скриншоты' + ' (' + str(len(data['screenshot'])) + ')')
		self.popupadd(Link('catalog', {'search': True, 'textsearch': title}, True), 'Поиск')
		if isinstance(d['url'], basestring):
			self.item(Link('play',{'url': data['url']}), title=title, media='music', info=info, thumb=data['thumb'], popup=True, popup_replace=True, property=[('IsPlayable','true')], cast=data['cast'], folder=False)
		else:
			self.item(Link('video', {'url': data['url'] }), title=title, media='music', info=data['info'], thumb=data['thumb'], popup=True, popup_replace=True, cast=data['cast'])
			for i in d['url']:
				info['title'] = title + u' / ' + i['title']
				info['tracknumber'] = i['index'] + 1
				self.item(Link('play',{'url': data['url'], 'index': i['index'] }), title=i['title'], media='music', info=info, thumb=data['thumb'], popup=True, popup_replace=True, property=[('IsPlayable','true')], cast=data['cast'], folder=False)
		for i in d['podbor2']:
			self.item(Link('video', {'url': i['url']}), title=i['info']['title'], media='music', info=i['info'], thumb=i['thumb'], popup=self.popup, popup_replace=True)
		self.render(nextmode=_view_)

@plugin.radd()
class Play(Handler):
	def handle(self):
		url = self.argv.get('url')
		durl = self.argv.get('durl')
		index = self.argv.get('index')
		if url:
			link, error = knizhkin.play_link(url, index)
		elif durl: link = durl
		if link and link == '': error = ['Нет ссылки на аудио.']
		if link:
			#xbmc.Player().play(link)
			item = xbmcgui.ListItem(path=link)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]),True, item)
		else:
			xbmcgui.Dialog().ok(self.nameaddon, *error)

@plugin.radd()
class ScreenShot(Handler):
	def handle(self):
		from xbmcup import slideshow
		slideshow.open(self.argv, 0)
		return True


def main():
	plugin.route('history', History)
	plugin.run(setcontent='songs')


if __name__ == '__main__':
	try:
                search_vars = sys.argv[2].split('?')
                search_vars = search_vars[-1].split('&')
                if 'usearch=True' in search_vars:
                        from urlparse import parse_qs
                        params = parse_qs(sys.argv[2].replace('?', ''))
                        united_search = {'route': 'catalog', 'argv': { 'search': params['keyword'][0] } }
			from urllib import quote_plus
                        import json
                        sys.argv[2] = '?'+quote_plus(json.dumps(united_search))
	except BaseException as e:
		from xbmcup.errors import log
		log(e)

	main()
