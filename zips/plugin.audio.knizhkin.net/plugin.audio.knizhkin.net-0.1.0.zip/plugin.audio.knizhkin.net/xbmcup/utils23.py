# -*- coding: utf-8 -*-
import sys
PY2 = sys.version_info.major == 2

def _de(s):
    return s.decode('utf8') if PY2 else s

def _en(s):
    return s.encode('utf8') if PY2 else s

