# -*- coding: utf-8 -*-

import sys, urllib, urlparse, xbmc

ID = 'plugin.rutracker'
try:
	uri = "plugin://{0}/?%7B%22route%22%3A+%22rutracker-search%22%2C+%22argv%22%3A+%7B%22content%22%3A+%22global%22%2C+%22textsearch%22%3A+%22{1}%22%7D%7D".format(ID, urllib.quote_plus(''))
	xbmc.executebuiltin("Container.Update({0})".format(uri))
except:
	pass


