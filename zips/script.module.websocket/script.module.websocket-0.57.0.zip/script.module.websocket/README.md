script.module.websocket
=======================

websocket-client library repacked for Kodi

- https://github.com/pkscout/script.module.websocket


Based on websocket-client library for Python.

- https://github.com/websocket-client/websocket-client
- https://pypi.org/project/websocket-client/#files

License
-------

LGPL
