# -*- coding: utf-8 -*-
#from __future__ import unicode_literals

def quote_unicode(s):
	from urllib import quote_plus
	if isinstance(s, unicode): s = s.encode('utf8')
	return quote_plus(s)

def add(id, scraper='tmdb_global_movie'):
	import json
	from urllib import quote_plus
#	if not scraper: scraper = 'tmdb_global_movie'
	s = json.dumps({'route': 'bookmark-add', 'argv': {'scrapper': scraper, 'id': id, 'datascraper': {} } })
	return 'plugin://plugin.rutracker/?' + quote_plus(s)

def addtv(id):
	return add(id, 'tmdb_global_tv')

if __name__ == '__main__':
	print(add('123444'))
