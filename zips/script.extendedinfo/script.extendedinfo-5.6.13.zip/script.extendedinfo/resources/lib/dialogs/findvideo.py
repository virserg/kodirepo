# -*- coding: utf-8 -*-

from __future__ import unicode_literals

import xbmc
import xbmcgui

from resources.lib.WindowManager import wm

from kodi65 import addon


def find_video(title, originaltitle="", year=None, item_id="", media_type=""):
    findnames = [title]
    if title!=originaltitle: findnames += [originaltitle]
    if year: findnames += ['%s (%s)' % (title, year)]
    if title!=originaltitle and year: findnames += ['%s (%s)' % (originaltitle, year)]
    index = xbmcgui.Dialog().select(heading=addon.LANG(16017),
                                            list=findnames)
    if index == -1:
                   return None
    findname = findnames[index]
    addonlist= [(addon.LANG(32174), 'plugin://plugin.video.united.search/?action=search&keyword='),
               ('TorrServer Client', 'plugin://plugin.video.torrserve/?action=search&mod=torrent&title=true&qs=true&id=%s&type=%s&query=' % (item_id, media_type)),
               ('RuTracker', 'plugin://plugin.rutracker/?route=rutracker-search&content=global&search='),
               ('Filmix', 'plugin://plugin.video.filmix/search?keyword='),
               ('Hdrezka.tv', 'plugin://plugin.video.hdrezka.tv/?mode=search&usearch=True&keyword='),
               ('kino-live.org', 'plugin://plugin.video.kino-live.org/?mode=usearch&keyword='),
               ('Киновод', 'plugin://plugin.video.kinovod/?route=catalog&s_kbd=True&search='),
               ('HD KinoTeatr', 'plugin://plugin.video.evld.hdkinoteatr.com/?mode=search&query='),
               ('Filmix.Net', 'plugin://plugin.video.filmix.net.dev/?mode=search&usearch=True&keyword='),
               ('RuTor', 'plugin://plugin.video.RuTor/?mode=US&text='),
               ('MegaPeer', 'plugin://plugin.video.megapeer/?route=catalog&s_kbd=True&search='),
               ('Rutor Аудиокниги', 'plugin://plugin.video.rutor.audio/?route=catalog&s_kbd=True&search='),
               ('Fast-Torrent.org', 'plugin://plugin.video.fasttorrent.org/?mode=US&title=')]
    findlist = [i for i in addonlist if xbmc.getCondVisibility("System.HasAddon(%s)" % i[1].split('/')[2]) == 1]
    index = xbmcgui.Dialog().select(heading=addon.LANG(32151),
                                            list=[i[0] for i in findlist])
    if index == -1:
                   return None
    purl = findlist[index][1]
    from urllib import quote_plus
    purl += quote_plus(findname.encode('utf8'))
#    xbmcgui.Dialog().ok('Поиск тест', findname, str(index), purl)
    wm.find_video(purl=purl, us=True if '//plugin.video.united.search/' in purl else False)
